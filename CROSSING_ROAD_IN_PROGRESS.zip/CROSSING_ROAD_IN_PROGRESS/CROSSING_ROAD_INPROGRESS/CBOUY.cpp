﻿#include "CBOUY.h"

CBOUY::CBOUY()
{
	objectKind = 2;
	pos.X = 0;
	pos.Y = 0;
	setWidth(13);
	setHeight(6);
}

CBOUY::CBOUY(int x, int y)
{
	objectKind = 2;
	pos.X = x;
	pos.Y = y;
	setWidth(13);
	setHeight(6);
}

void CBOUY::draw()

{

	int fromX = pos.X;
	int fromY = pos.Y;
	int nScreenWidth = NSCREENWIDTH;
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = (pColor[(fromY)*nScreenWidth + (fromX + 2)] / 16) * 16 + 11;
		}
		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + 11;
		}

		for (int i = fromX + 4; i <= fromX + 8; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY)*nScreenWidth + (i)] = L'▀';
				pColor[(fromY)*nScreenWidth + (i)] = 12 * 16 + 11;
			}
		}

		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = (pColor[(fromY)*nScreenWidth + (fromX + 9)] / 16) * 16 + 11;
		}
		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = (pColor[(fromY)*nScreenWidth + (fromX + 10)] / 16) * 16 + 11;
		}
	}
	//row 2
	if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
	{
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 11 * 16 + 11;
		}
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 12 * 16 + 12;
		}
		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 12 * 16 + 10;
		}

		for (int i = fromX + 4; i <= fromX + 9; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 1) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 1) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}
		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 10 * 16 + 11;
		}
		if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] / 16) * 16 + 11;
		}

	}
	//row 3
	if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = 11 * 16 + 11;
		}
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 10 * 16 + 12;
		}
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 10 * 16 + 10;
		}

		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 10 * 16 + 10;
		}

		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
		}

		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
		}

		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;
		}

		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
		}

		if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = 10 * 16 + 11;
		}

		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = 11 * 16 + 11;
		}

		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] / 16) * 16 + 11;
		}

		if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] / 16) * 16 + 11;
		}
	}
	//row 4
	if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 11 * 16 + 11;
		}

		for (int i = fromX + 1; i <= fromX + 4; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 3) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 3) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}

		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
		}

		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 10 * 16 + 11;
		}

		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 10 * 16 + 11;
		}


		for (int i = fromX + 8; i <= fromX + 11; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 3) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 3) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}

		if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
		}
	}
	//row5
	if (fromY + 4 >= 0 && fromY + 4 < NSCREENWIDTH)
	{
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = 11 * 16 + 11;
		}


		for (int i = fromX + 2; i <= fromX + 8; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 4) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 4) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}

		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
		}

		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = 10 * 16 + 12;
		}

		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = 12 * 16 + 12;
		}

		if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
		}
	}
	//row 6
	if (fromY + 5 >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] / 16) * 16 + 11;
		}


		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] / 16) * 16 + 11;
		}

		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
		}


		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
		}


		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = 12 * 16 + 11;
		}


		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = 12 * 16 + 11;
		}


		if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = 12 * 16 + 11;
		}


		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] / 16) * 16 + 11;
		}

		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] / 16) * 16 + 11;
		}
	}
	
}

void CBOUY::saveObject(ofstream &f)
{
	f.write((char*)&objectKind, sizeof(objectKind));
	f.write((char*)&pos.X, sizeof(pos.X));
	f.write((char*)&pos.Y, sizeof(pos.Y));
	f.write((char*)&width, sizeof(width));
	f.write((char*)&height, sizeof(height));
}

void CBOUY::loadBouy(ifstream& f)
{
	f.read((char*)&pos.X, sizeof(pos.X));
	f.read((char*)&pos.Y, sizeof(pos.Y));
	f.read((char*)&width, sizeof(width));
	f.read((char*)&height, sizeof(height));
}
