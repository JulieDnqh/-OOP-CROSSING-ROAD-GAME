#pragma once
#include "CGRAPHIC.h"
#include "COBJECT.h"
class CBOUY:public COBJECT
{
public:
	CBOUY();
	CBOUY(int x, int y);
	
	void draw();
	void saveObject(ofstream &f);
	void loadBouy(ifstream& f);
};

