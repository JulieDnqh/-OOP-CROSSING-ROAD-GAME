﻿#include "CGAME.h"

bool sortNameByScore(RankData a, RankData b)
{
    return a.score > b.score;
}

bool CGAME::checkNameFile(string name)
{
    for (int i = 0; i < menu.getVectorFileName().size(); i++) {
        if (name == menu.getVectorFileName()[i]) {
            return true;
        }
    }
    return false;
}

CGAME::CGAME()
{
    isPause = false;
    isEnd = false;
    level = 0;
    trafficLightCoef = 50;
    sleepSpeed = 100;
    minNumObs = 1;
    maxNumObs = 1;
    minNumItems = 1;
    maxNumItems = 5;
    posYLaneCur = NSCREENHEIGHT - 8;
    indexYCur = 0;
    map.resize(24);
    map.clear();
    menu.setGame(this);
    
}

void CGAME::setNumOfPlayers(int num)
{
    numOfPlayers = num;
    if (numOfPlayers == 1)
    {
        player.push_back(CPLAYER());
    }
    else
    {
        for (int i = 0; i < numOfPlayers; i++)
        {
            int x = (NSCREENWIDTH / (numOfPlayers + 1)) * (i + 1) - WIDTH_PIKACHU / 2;
            player.push_back(CPLAYER(i + 1, x));
        }
    }
    
    for (int i = 0; i < player.size(); i++)
    {
        player[i].setY(NSCREENHEIGHT - player[i].getHeight() * 2);
    }
    
}

void CGAME::setMode(bool mode)
{
    this->mode = mode;
    if (mode == 0)
    {
        setMap();
        sleepSpeed = 100;
    }
    else
    {
        minNumObs = 1;
        maxNumObs = 2;
        setDefaultMap();
        sleepSpeed = 120;
    }
}

void CGAME::setMainChar(int i, int selectMain, bool switches)//1 la pikachu;  2 la kirby;  3 la mario;
{
    if (i == 1) {
        player[0].setKindChar(selectMain);
    }
    else {
        int selectMain1{}, selectMain2{};

        if (selectMain == 1) {
            selectMain1 = 1;
            selectMain2 = 2;

        }
        else if (selectMain == 2) {
            selectMain1 = 1;
            selectMain2 = 3;
        }
        else if (selectMain == 3) {
            selectMain1 = 2;
            selectMain2 = 3;
        }

        if (switches == true) {
            swap(selectMain1, selectMain2);
        }

        player[1].setKindChar(selectMain1);
        player[0].setKindChar(selectMain2);

    }
}
void CGAME::setNameForPlayer(int index, string name)
{
    player[index].setName(name);
}
void CGAME::setKindCharForPlayer(int index, int kindCharacter)
{
    player[index].setKindChar(kindCharacter);
}
int CGAME::getMode()
{
    return mode;
}

int CGAME::getNumOfPlayers()
{
    return numOfPlayers;
}

int CGAME::getLevel()
{
    return level;
}


string CGAME::getPlayerName(int index)
{
    return player[index].getName();
}

int CGAME::getPlayerKindChar(int index)
{
    return player[index].getKindChar();
}
void CGAME::startApp()
{
    menu.control();
}

void CGAME::reset()
{
    isPause = false;
    isEnd = false;
    level = 0;
    trafficLightCoef = 50;
    sleepSpeed = 100;
    minNumObs = 1;
    maxNumObs = 1;
    cleanMap();
    player.erase(player.begin(), player.end());
}

bool CGAME::loadGame(string fileName)
{
    ifstream f;
    for (int i = 0; i < map.size(); i++)
    {
        delete map[i];
    }
    map.erase(map.begin(), map.end());
    f.open(fileName, ios::binary);
    if (f.is_open())
    {
        f.read((char*)&posYLaneCur, sizeof(indexYCur));

        f.read((char*)&indexYCur, sizeof(indexYCur));

        f.read((char*)&isEnd, sizeof(isEnd));

        f.read((char*)&numOfPlayers, sizeof(numOfPlayers));
        setNumOfPlayers(numOfPlayers);

        f.read((char*)&mode, sizeof(mode));

        f.read((char*)&level, sizeof(level));

        f.read((char*)&sleepSpeed, sizeof(sleepSpeed));

        f.read((char*)&trafficLightCoef, sizeof(trafficLightCoef));

        f.read((char*)&minNumObs, sizeof(minNumObs));

        f.read((char*)&maxNumObs, sizeof(maxNumObs));

        int numOfLanes;

        f.read((char*)&numOfLanes, sizeof(numOfLanes));

        player.resize(numOfPlayers);
        for (int i = 0; i < numOfPlayers; i++)
        {

            player[i].loadPlayer(f);
        }

        for (int i = 0; i < numOfLanes; i++)
        {

            int laneKind;
            f.read((char*)&laneKind, sizeof(laneKind));

            if (laneKind == 0)
            {
                CLANE* newLane = new CLANE;
                newLane->loadLane(f);
                map.push_back(newLane);
            }
            else if (laneKind == 1)
            {
                CLANE* newLane = new CROAD;
                newLane->loadLane(f);
                map.push_back(newLane);
            }
            else if (laneKind == 2)
            {
                CLANE* newLane = new CRIVER;
                newLane->loadLane(f);
                map.push_back(newLane);
            }
        }
        f.close();
        return play();

    }
}

void CGAME::drawInforBoard()
{
    CLETTER word{};
    string namePlayer{}, namePlayer1{};

    int x = 60;
    int y{};
    int color = 1;
    int colorbg = 0;//vien
    y = 4;

    if (numOfPlayers > 1) {

        word.setLetter(namePlayer, 10, y, color, colorbg);
        word.drawWord();

        word.setLetter(namePlayer1, 10, map[0]->getPos(), color, colorbg);
        word.drawWord();

        int fromX = NSCREENWIDTH / 2 - 70, fromY = NSCREENHEIGHT / 2 - 25;
        menu.drawTitleFrame(fromX, fromY, 140, 21, 15);

        word.setLetter("PLAYER 1", fromX + 6, 9, 1, 0);
        word.drawWord();

        namePlayer = "NAME: " + player[0].getName();
        word.setLetter(namePlayer, fromX + 6, 15, 1, 0);
        word.drawWord();

        string score = "SCORE: " + to_string(player[0].getScore());
        word.setLetter(score, fromX + 6, 21, 1, 0);
        word.drawWord();

        menu.drawTitleFrame(fromX, 31, 140, 21, 15);

        word.setLetter("PLAYER 2", fromX + 6, 33, 1, 0);
        word.drawWord();

        namePlayer1 = "NAME: " + player[1].getName();
        word.setLetter(namePlayer1, fromX + 6, 39, 1, 0);
        word.drawWord();

        string score1 = "SCORE: " + to_string(player[1].getScore());
        word.setLetter(score1, fromX + 6, 45, 1, 0);
        word.drawWord();

    }
    else {

        int fromX = NSCREENWIDTH / 2 - 70, fromY = NSCREENHEIGHT / 2 - 25;
        menu.drawTitleFrame(fromX, fromY, 140, 30, 15);

        word.setLetter("PLAYER", fromX + 6, 13, 1, 0);
        word.drawWord();

        namePlayer = "NAME: " + player[0].getName();
        word.setLetter(namePlayer, fromX + 6, 19, 1, 0);
        word.drawWord();

        string score = "SCORE: " + to_string(player[0].getScore());
        word.setLetter(score, fromX + 6, 25, 1, 0);
        word.drawWord();
    }

    //hien level
    int fromX = NSCREENWIDTH / 2 - 10 * 3, fromY = (numOfPlayers > 1) ? NSCREENHEIGHT - 10 : NSCREENHEIGHT - 8 * 2;
    //do dai chu + 10
    string levelTemp = "LEVEL " + to_string(level + 1);
    menu.drawTitleFrame(fromX, fromY, 4 + (levelTemp.length() - 1) * 8 + 10, 9, 15);
    word.setLetter(levelTemp, fromX + 6, fromY + 2, 1, 0);
    word.drawWord();
    //Sleep(700);
}

bool CGAME::play()
{
    for (int i = 0; i < map.size(); i++)
        map[i]->draw();
    for (int i = 0; i < player.size(); i++)
        player[i].draw();

    drawInforBoard();

    graphic->display();
    Sleep(700);

    firstMove();

    for (int i = 0; i < map.size(); i++)
        map[i]->draw();
    for (int i = 0; i < player.size(); i++)
        player[i].draw();

    int x = 10;
    int y = 4;
    CLETTER word;
    string score = "SCORE: " + to_string(player[0].getScore());
    word.setLetter(score, 10, y);
    word.drawWord();

    if (numOfPlayers > 1) {
        score = "SCORE: " + to_string(player[1].getScore());
        word.setLetter(score, NSCREENWIDTH - 7 * 10, y);
        word.drawWord();
    }
    graphic->display();

    thread Motion(&CGAME::motion, this);
    while (1)
    {

        isPause = pauseCheck();
        if (isPause == true)
        {
            bool continuePause;
            int option = 0;
            do
            {   
                pair<bool, int> check = pauseGameConTrol(Motion, option);
                continuePause= check.first;
                option = check.second;
            } while (continuePause == true);


            if (option == 1)
                return 1;
            else if (option == -1)
                return 0;
        }

        if (isEnd == true)
        {
            Motion.join();
            if (menu.sound)
                menu.playSound(6);
            bool restart = menu.askForRestart();
            if (restart == false)
            {
                for (int i = 0; i < numOfPlayers; i++) {
                    menu.addFileRank(player[i].getName(), player[i].getScore(), player[i].getKindChar());
                }
                reset();
            }
            return restart;
        }

        if (isPause == false)
            for (int i = 0; i < player.size(); i++)
            {
                player[i].move(mode, menu.sound);
            }

    }
}

int CGAME::pauseGameSelect(int firstOption)
{
    //graphic->setTmp();
    
    pauseOptionBoard(firstOption);
    graphic->display();

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    int nSelect = firstOption;
    while (1)
    {
        int move = toupper(_getch());

        if (move == 'S' || move == 80)
        {
            if (menu.sound)
                menu.playSound(1);
            nSelect++;
            if (nSelect > 5)
                nSelect = 0;
        }
        if (move == 'W' || move == 72)
        {
            if (menu.sound)
                menu.playSound(1);
            nSelect--;
            if (nSelect < 0)
                nSelect = 5;
        }
        if (move == 13 || move == 32)
        {
            if (menu.sound)
                menu.playSound(0);
            return nSelect;
        }

        pauseOptionBoard(nSelect);
       // Hiển thị
        graphic->display();
    }
}

void CGAME::pauseOptionBoard(int nSelect)
{
    int c0 = 2, c1 = c0, c2 = c0, c3 = c0, c4 = c0, c5 = c0;
    if (nSelect == 0)
        c0 = 7;
    else if (nSelect == 1)
        c1 = 7;
    else if (nSelect == 2)
        c2 = 7;
    else if (nSelect == 3)
        c3 = 7;
    else if (nSelect == 4)
        c4 = 7;
    else if (nSelect == 5)
        c5 = 7;
    int fromX = NSCREENWIDTH / 2 - 55, fromY = NSCREENHEIGHT / 2 - 20;
    menu.drawTitleFrame(fromX, fromY, 115, 45, 15);
    vector<int> color = { 4,13,7,5,8,10,4,13,8,10 };
    CLETTER word;
    word.setLetter("PAUSE GAME", NSCREENWIDTH / 2 - 35, 10, color, 0);
    word.drawWord();
    menu.drawStar(69, 9);
    menu.drawStar(161, 9);
    word.setLetter("RESUME", NSCREENWIDTH / 2 - 22, 17, c0, 0);
    word.drawWord();
    word.setLetter("RESTART", NSCREENWIDTH / 2 - 26, 23, c1, 0);
    word.drawWord();
    word.setLetter("SAVE", NSCREENWIDTH / 2 - 14, 29, c2, 0);
    word.drawWord();
    word.setLetter("SETTING", NSCREENWIDTH / 2 - 26, 35, c3, 0);
    word.drawWord();
    word.setLetter("HELP", NSCREENWIDTH / 2 - 14, 41, c4, 0);
    word.drawWord();
    word.setLetter("QUIT", NSCREENWIDTH / 2 - 14, 47, c5, 0);
    word.drawWord();
}


pair<bool,int> CGAME::pauseGameConTrol(thread& Motion, int firstOption)//bool return co tiep tuc pause hay k, neu bool = false thi n Select cuoi cung la gi;
{
    graphic->setTmp();
    int nSelect = pauseGameSelect(firstOption);
    switch (nSelect)
    {
    case 0:
    {
        isPause = false;
        return {0, 0};
        break;
    }
    case 1:
    {
        isPause = false;
        isEnd = true;
        Motion.join();
        return { 0,1 };//ko show pause nua va restart
        break;
    }
    case 2:
    {
        graphic->getTmp();
        FileData* fd = saveGame();
        if (fd!=NULL)
            menu.addGameFile(fd);
        bool resume = menu.askForResume();
        if (resume == true)
        {
            isPause = false;
            return { 0, 2 };
        }
        else
        {
            for (int i = 0; i < numOfPlayers; i++) {
                menu.addFileRank(player[i].getName(), player[i].getScore(), player[i].getKindChar());
            }
            isEnd = true;
            isPause = false;
            Motion.join();
            reset();
            return { 0,-1 };// ko show pause nua va ket thuc game
           

            //return 0;*/
        }
        break;
    }
    case 3:
    {
        graphic->setTmp();
        menu.settingPage();
        graphic->getTmp();
        //isPause = false;
        return { 1,3 };//tiep tuc show pause
        break;
    }
    case 4:
    {
        graphic->setTmp();
        menu.helpPage();
        graphic->getTmp();
        //isPause = false;
        return { 1,4 };//tiep tuc show pause
        break;
    }
    case 5:
    {
        isEnd = true;
        isPause = false;
        Motion.join();
        reset();
        return { 0, -1 };
        break;
    }
    }
}
void CGAME::addNewGrass(int y, int numOfItems, int numObs)
{
    CLANE* newlane = new CLANE(y);

    //set item
    if (numOfItems > 0) {
        newlane->setNumOfItems(numOfItems);
        int firstPos = rand() % (NSCREENWIDTH - 10 + 1) + 2;
        newlane->setFirstItemsPos(firstPos);
        newlane->setDistanceBetItems(NSCREENWIDTH / (numOfItems + 1));
        for (int j = 0; j < newlane->getNumOfItems(); j++) {
            COBJECT* obj = new CITEM;
            newlane->addItems(obj);
        }
    }
    
    map.push_back(newlane);
}

void CGAME::addNewRoad(int y, int numOfItems, int direction, int numObs, int firstPos)
{
    CLANE* newlane = new CROAD(y);

    //set obs
    if (numObs == -1)
        numObs = rand() % (maxNumObs - minNumObs + 1) + minNumObs;

    if (direction == -1)
        direction = rand() % 2;
    newlane->setDirection(direction);
    newlane->setNumOfObs(numObs);
    if (firstPos == -1)
        firstPos = rand() % 150 + 100;
    newlane->setFirstObsPos(firstPos);
    newlane->setDistanceBetObs(NSCREENWIDTH / (numObs + 1));

    for (int i = 0; i < numObs; i++)
    {
        COBJECT* obj1 = new CVEHICLE;
        CVEHICLE* car = dynamic_cast<CVEHICLE*>(obj1);
        car->setVehicleKind(rand() % 4, newlane->getDirection());
        newlane->addObstacle(obj1);
    }

    //set item
   

    map.push_back(newlane);

    //map[map.size() - 1]->obstacleMotion();
    if (numOfItems > 0) {
        newlane->setNumOfItems(numOfItems);
        firstPos = rand() % (NSCREENWIDTH - 10 + 1) + 2;
        newlane->setFirstItemsPos(firstPos);
        newlane->setDistanceBetItems(NSCREENWIDTH / (numOfItems + 1));
        for (int j = 0; j < newlane->getNumOfItems(); j++) {
            COBJECT* obj = new CITEM;
            newlane->addItems(obj);
        }
    }
}

void CGAME::addNewRiver(int y, int numOfItems, int direction, int numObs, int firstPos)
{
    CLANE* newlane = new CRIVER(y);

    //set obs
    if (direction == -1)
        direction = rand() % 2;
    newlane->setDirection(direction);
    if (numObs == -1)
        numObs = 7;
    newlane->setNumOfObs(numObs);
    if (firstPos == -1)
    { // = NSCREENWIDTH - 8;
        if (direction == 1)
        {
            firstPos = rand() % 5 + 4;
        }
        else
        {
            firstPos = NSCREENWIDTH - rand() % 5 - 4;
        }
    }
      
    newlane->setFirstObsPos(firstPos);
    newlane->setDistanceBetObs(NSCREENWIDTH / (8));
    for (int i = 0; i < 7; i++)
    {
        COBJECT* obj = new CBOUY;
        newlane->addObstacle(obj);
    }

    if (numOfItems > 0) {
        newlane->setNumOfItems(numOfItems);
        newlane->setFirstItemsPos(firstPos);
        newlane->setDistanceBetItems(NSCREENWIDTH / (8));
        for (int j = 0; j < newlane->getNumOfItems(); j++) {
            COBJECT* obj = new CITEM;
            newlane->addItems(obj);
        }
    }

    map.push_back(newlane);
}

void CGAME::generateNewLane()
{
    int kind;
    if (map.size() >= 2)
    {
        if (map[map.size() - 1]->getKind() != 0 && map[map.size() - 1]->getKind() != 0)
            kind = rand() % 2 + 1;
        else
            kind = rand() % 3;
 
    }
    else
        kind = rand() % 3;

    if (map.size() >= 1)
        if (map[map.size() - 1]->getKind() == 2)
            kind = 0;

    int width = 8;
    int y = map[map.size() - 1]->getPos() - width;
    
   /* if (indexYCur-1 >= 0 && indexYCur-1 < map.size())
    {
        indexYCur--;
        posYLaneCur = map[indexYCur]->getPos();
    }*/
   

    //random vat pham
    int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

    if (kind == 0)
    {
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);  
    }
    else if (kind == 1)
    {
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y);
    }
    else if (kind == 2)
    {
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane);  
    }
   
}

void CGAME::setDefaultMap()
{
    //random vat pham
    int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;
    int y = NSCREENHEIGHT - 8;
    int numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 0, 3, 190);
    CROAD* newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 0, 4, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 1, 5, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(2, 0, 13, map[map.size() - 1]->getPos() + 2);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 1, 3, 50);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 1, 8, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 3, 0, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(2, 2, 4, map[map.size() - 1]->getPos() + 1);
    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRiver(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 1, 3, 110);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 2, 13, map[map.size() - 1]->getPos() + 1);
    newroad->setVehicleAttribute(1, 1, 8, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(2, 0, 11, map[map.size() - 1]->getPos() + 2);


    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRiver(y, numItemsEachLane, 1);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 0, 3, 100);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 0, 13, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 3, 0, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(2, 1, 5, map[map.size() - 1]->getPos() + 2);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 0, 3, 30);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 3, 0, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 2, 4, map[map.size() - 1]->getPos() + 1);
    newroad->setVehicleAttribute(2, 1, 12, map[map.size() - 1]->getPos() + 2);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 0, 3, 190);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 3, 0, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 0, 12, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(2, 2, 4, map[map.size() - 1]->getPos() + 2);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRiver(y, numItemsEachLane, 1);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 1, 3, 60);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 1, 8, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 2, 13, map[map.size() - 1]->getPos() + 1);
    newroad->setVehicleAttribute(2, 1, 5, map[map.size() - 1]->getPos() + 2);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewGrass(y, numItemsEachLane);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 0, 3, 170);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 0, 13, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 3, 0, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(0, 0, 4, map[map.size() - 1]->getPos() + 2);

    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRoad(y, numItemsEachLane, 0, 2, 90);
    newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
    newroad->setVehicleAttribute(0, 1, 15, map[map.size() - 1]->getPos() + 2);
    newroad->setVehicleAttribute(1, 2, 8, map[map.size() - 1]->getPos() + 1);


    y -= 8;
    numItemsEachLane = rand() % (numOfItems + 1);
    addNewRiver(y, numItemsEachLane, 0);
}

void CGAME::setMap()
{
    if (level == 0)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);
        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y);
        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3, 190);
        CROAD* newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 0, 4, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 1, 5, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(2, 0, 13, map[map.size() - 1]->getPos() + 2);
       
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y,numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 50);
        newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 1, 8, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 3, 0, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(2, 2, 4, map[map.size() - 1]->getPos() + 1);
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y,numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y,numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y,numItemsEachLane);

        

        setMotionSpeed(3);
    }
    else if (level == 1)
    {
       
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 110);
        CROAD* newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 2, 13, map[map.size() - 1]->getPos() + 1);
        newroad->setVehicleAttribute(1, 1, 8, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(2, 0, 11, map[map.size() - 1]->getPos() + 2);

        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1);
        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);
        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3, 100);
        newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 0, 13, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 3, 0, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(2, 1, 5, map[map.size() - 1]->getPos() + 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);
        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3, 30);
        newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 3, 0, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 2, 4, map[map.size() - 1]->getPos() + 1);
        newroad->setVehicleAttribute(2, 1, 12, map[map.size() - 1]->getPos() + 2);
        
        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        setMotionSpeed(4);
    }
    else if (level == 2)
    { 
       
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        setMotionSpeed(4);
    }
    else if (level == 3)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3, 190);
        CROAD* newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 3, 0, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 0, 12, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(2, 2, 4, map[map.size() - 1]->getPos() + 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 60);
        newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 1, 8, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 2, 13, map[map.size() - 1]->getPos() + 1);
        newroad->setVehicleAttribute(2, 1, 5, map[map.size() - 1]->getPos() + 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3, 170);
        newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 0, 13, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 3, 0, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(0, 0, 4, map[map.size() - 1]->getPos() + 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 2, 90);
        newroad = dynamic_cast<CROAD*>(map[map.size() - 1]);
        newroad->setVehicleAttribute(0, 1, 15, map[map.size() - 1]->getPos() + 2);
        newroad->setVehicleAttribute(1, 2, 8, map[map.size() - 1]->getPos() + 1);
     

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0);

        setMotionSpeed(4);
    }

    else if (level == 4)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 2);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 4);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        setMotionSpeed(5);
    }
    else if (level == 5)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 120);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 4, 80);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 4, 50);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 4, 180);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        setMotionSpeed(5);
    }
    else if (level == 6)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0, 5);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 150);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 4, 50);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1, 5);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 5);

        setMotionSpeed(5);
    }
    else if (level == 7)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0, 5);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 150);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 3, 60);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 160);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0, 8,220);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1, 8, 15);

        setMotionSpeed(5);
    }
    else if (level == 8)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 4, 70);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 90);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0, 7);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 3, 160);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0, 6);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 4);

        setMotionSpeed(6);
    }
    else if (level == 9)
    {
        //set toa do lane hien tai
        posYLaneCur = NSCREENHEIGHT - 8;
        indexYCur = 0;
        cleanMap();
        //random vat pham
        int numOfItems = rand() % (maxNumItems - minNumItems + 1) + minNumItems;

        int y = NSCREENHEIGHT - 8;
        int numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 4, 70);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, 1, 1, 8);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 0, 7);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewGrass(y, numItemsEachLane);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 1, 4, 210);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRoad(y, numItemsEachLane, 0, 4);

        y -= 8;
        numItemsEachLane = rand() % (numOfItems + 1);
        addNewRiver(y, numItemsEachLane, 1, 8);

        setMotionSpeed(7);
    }

}

void CGAME::setMotionSpeed(int speed)
{
    for (int i = 0; i < map.size(); i++)
    {
        map[i]->setMotionSpeed(speed);
    }
}

void CGAME::mapMotion()
{
    for (int i = 0; i < map.size(); i++)
    {
        if (map[i] == NULL)
            continue;
        map[i]->setPos(map[i]->getPos() + 1);
        if (map[i]->getKind() == 1)
        {
            CROAD* roadLane = dynamic_cast<CROAD*>(map[i]);
            if (roadLane->getWaitTime() == 0)
            {
                map[i]->obstacleMotion();
                if (map[i]->getPos() < NSCREENHEIGHT && map[i]->getPos() + map[i]->getWidth() - 1 >= 0)
                    map[i]->draw();
                roadLane->generateTraffictLight(trafficLightCoef);
            }
            else
            {
                roadLane->decreaseWaitTime();
                if (map[i]->getPos() < NSCREENHEIGHT && map[i]->getPos() + map[i]->getWidth()-1 >= 0)
                    map[i]->draw();
            }
        }
        else
        {
            map[i]->obstacleMotion();
            if (map[i]->getKind() == 2 && map[i]->getNumOfItems()) {
                map[i]->itemsMotion();
            }
            if (map[i]->getPos() < NSCREENHEIGHT && map[i]->getPos() + map[i]->getWidth() - 1 >= 0)
                map[i]->draw();
        }
    }
    for (int i = 0; i < player.size(); i++)
    {
        player[i].setY(player[i].getY() + 1);
        player[i].draw();
    }
}

void CGAME::motion()
{
    int count = 0;
    if (mode == 0)
    {
        while (1)
        {
            if (isPause == true)
                continue;
             
            if (isEnd == true)
            {
                return;
            }

            for (int i = 0; i < map.size(); i++)
            {
                if (map[i] == NULL)
                    continue;
                if (map[i]->getKind() == 1)
                {
                    CROAD* roadLane = dynamic_cast<CROAD*>(map[i]);
                    if (roadLane->getWaitTime() == 0)
                    {
                        map[i]->obstacleMotion();
                        map[i]->draw();
                        roadLane->generateTraffictLight(trafficLightCoef);
                    }
                    else
                    {
                        roadLane->decreaseWaitTime();
                        map[i]->draw();
                    }
                }
                else
                {
                    map[i]->obstacleMotion();
                    if (map[i]->getKind() == 2 && map[i]->getNumOfItems()) {
                        map[i]->itemsMotion();
                    }

                    map[i]->draw();
                }
            }

            for (int i = 0; i < player.size(); i++)
            {
                player[i].draw();
            }

            //ve lai score
            if (posYLaneCur <= map[map.size() - 2]->getPos()) {
                for (int i = 0; i < map.size(); i++)
                    map[i]->draw();
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();

                int y = NSCREENHEIGHT - 8;//map[0]->getPos();
                int x = 10;
                string score = "SCORE: " + to_string(player[0].getScore());
                CLETTER word{};
                word.setLetter(score, 10, y);
                word.drawWord();

                if (numOfPlayers > 1) {
                    score = "SCORE: " + to_string(player[1].getScore());
                    word.setLetter(score, NSCREENWIDTH - 10 * 10, y);
                    word.drawWord();
                }
            }
            else{
                for (int i = 0; i < map.size(); i++)
                    map[i]->draw();
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();

                int y = map[map.size() - 1]->getPos();
                int x = 10;
                string score = "SCORE: " + to_string(player[0].getScore());
                CLETTER word{};
                word.setLetter(score, 10, y);
                word.drawWord();

                if (numOfPlayers > 1) {
                    score = "SCORE: " + to_string(player[1].getScore());
                    word.setLetter(score, NSCREENWIDTH - 7 * 10, y);
                    word.drawWord();
                }
            }

            graphic->display();

            //check move qua mot lane
            for (int i = 0; i < player.size(); i++) {
                if (player[i].getY() < posYLaneCur && player[i].getY() + player[i].getHeight() - 1 < posYLaneCur) {
                    indexYCur++;
                    if (indexYCur >= 0 && indexYCur < map.size()) {
                        posYLaneCur = map[indexYCur]->getPos();
                    }
                    player[i].plusScore(5);
                }
            }

            //check dung items
            for (int i = 0; i < map.size() - 1; i++) {
                if (map[i]->getNumOfItems()) {
                    if (numOfPlayers > 1) {
                        if (map[i]->checkCollisionItems(&player[0])) {
                            if (menu.sound)
                                menu.playSound(3);
                            if (map[i + 1]->getKind() == 0) {
                                player[0].plusScore(1);
                            }
                            else if (map[i + 1]->getKind() == 1) {
                                map[i + 1]->delAllObs();
                            }
                            else if (map[i + 1]->getKind() == 2) {
                                map[i + 1]->setRunObs(false);
                            }
                            map[i]->delAllItems();
                        }
                        if (map[i]->checkCollisionItems(&player[1])) {
                            if (menu.sound)
                                menu.playSound(3);
                            if (map[i + 1]->getKind() == 0) {
                                player[1].plusScore(1);
                            }
                            else if (map[i + 1]->getKind() == 1) {
                                map[i + 1]->delAllObs();
                            }
                            else if (map[i + 1]->getKind() == 2) {
                                map[i + 1]->setRunObs(false);
                            }
                            map[i]->delAllItems();
                        }
                    }
                    else {
                        if (map[i]->checkCollisionItems(&player[0])) {
                            if (menu.sound)
                                menu.playSound(3);
                            if (map[i + 1]->getKind() == 0) {
                                player[0].plusScore(1);
                            }
                            else if (map[i + 1]->getKind() == 1) {
                                map[i + 1]->delAllObs();
                            }
                            else if (map[i + 1]->getKind() == 2) {
                                map[i + 1]->setRunObs(false);
                            }
                            map[i]->delAllItems();
                        }
                    }
                }
            }
            if (map[map.size() - 1]->getNumOfItems()) {
                if (numOfPlayers > 1) {
                    if (map[map.size() - 1]->checkCollisionItems(&player[0])) {
                        if (menu.sound)
                            menu.playSound(3);
                        player[0].plusScore(2);
                        map[map.size() - 1]->delAllItems();
                    }
                    if (map[map.size() - 1]->checkCollisionItems(&player[1])) {
                        if (menu.sound)
                            menu.playSound(3);
                        player[1].plusScore(2);
                        map[map.size() - 1]->delAllItems();
                    }
                }
                else {
                    if (map[map.size() - 1]->checkCollisionItems(&player[0])) {
                        if (menu.sound)
                            menu.playSound(3);
                        player[0].plusScore(2);
                        map[map.size() - 1]->delAllItems();
                    }
                }
                
            }

            //check thang thua
            int check = checkEndGame();
            if (check != 0)
            {
                if (check == 3)
                {
                    
                    isEnd = true;
                    return;
                }
                else
                {
                    if (numOfPlayers == 1)
                    {
                        if (check == 2)
                        {
                            isEnd = true;
                            return;
                        }
                        else if (check == 1)
                        {
                            if (level == MAX_LEVEL)
                            {

                               
                                isEnd = true;
                                return;
                            }
                            else
                            {
                                Sleep(300);
                                levelUp();
                            }
                        }
                    }
                    else
                    {
                        if (level == MAX_LEVEL)
                        {
                       
                            isEnd = true;
                            return;
                        }
                        else
                        {
                            Sleep(300);
                            levelUp();
                        }
                    }
                }
            }

            Sleep(sleepSpeed);
        }
    }
    else
    {
        while (1)
        {
            if (isPause == true)
                continue;
            if (isEnd == true)
            {
                return;
            }
            mapMotion();
            if (map.size()>0 && map[0]->getPos() >= NSCREENHEIGHT)
            {
                count++;
                if (map[0]->getNumOfObs()) {
                    map[0]->delAllObs();
                }
                if (map[0]->getNumOfItems()) {
                    map[0]->delAllItems();
                }
                delete map[0];
                map[0] = NULL;
                map.erase(map.begin());
                if (indexYCur - 1 >= 0 && indexYCur - 1 < map.size())
                {
                    indexYCur--;
                    posYLaneCur = map[indexYCur]->getPos();
                }
                if (count == 15)
                {
                    levelUp();
                    count = 0;
                }
            }
            while (map.size() > 0 && map[map.size() - 1]->getPos() >=0)
            {
                generateNewLane();
            }

            //ve lai score
            if (posYLaneCur <= map[map.size() - 3]->getPos()) {
                for (int i = 0; i < map.size(); i++)
                    map[i]->draw();
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();

                int y = NSCREENHEIGHT - 10;//map[0]->getPos();
                int x = 10;
                string score = "SCORE: " + to_string(player[0].getScore());
                CLETTER word{};
                word.setLetter(score, 10, y);
                word.drawWord();

                if (numOfPlayers > 1) {
                    score = "SCORE: " + to_string(player[1].getScore());
                    word.setLetter(score, NSCREENWIDTH - 7 * 10, y);
                    word.drawWord();
                }
            }
            else {
                for (int i = 0; i < map.size(); i++)
                    map[i]->draw();
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();

                int y = 4;// map[map.size() - 2]->getPos();
                int x = 10;
                string score = "SCORE: " + to_string(player[0].getScore());
                CLETTER word{};
                word.setLetter(score, 10, y);
                word.drawWord();

                if (numOfPlayers > 1) {
                    score = "SCORE: " + to_string(player[1].getScore());
                    word.setLetter(score, NSCREENWIDTH - 7 * 10, y);
                    word.drawWord();
                }
            }

            graphic->display();

            //check move qua mot lane
            for (int i = 0; i < player.size(); i++) {
                if (player[i].getY() < posYLaneCur && player[i].getY() + player[i].getHeight() - 1 < posYLaneCur) {
                    indexYCur++;
                    if (indexYCur >= 0 && indexYCur < map.size()) {
                        posYLaneCur = map[indexYCur]->getPos();
                    }
                    player[i].plusScore(5);
                }
            }

            //check dung items
            for (int i = 0; i < map.size() - 1; i++) {
                if (map[i]->getNumOfItems()) {
                    if (numOfPlayers > 1) {
                        if (map[i]->checkCollisionItems(&player[0])) {
                            if (menu.sound)
                                menu.playSound(3);
                            if (map[i + 1]->getKind() == 0) {
                                player[0].plusScore(1);
                            }
                            else if (map[i + 1]->getKind() == 1) {
                                map[i + 1]->delAllObs();
                            }
                            else if (map[i + 1]->getKind() == 2) {
                                map[i + 1]->setRunObs(false);
                            }
                            map[i]->delAllItems();
                        }
                        if (map[i]->checkCollisionItems(&player[1])) {
                            if (menu.sound)
                                menu.playSound(3);
                            if (map[i + 1]->getKind() == 0) {
                                player[1].plusScore(1);
                            }
                            else if (map[i + 1]->getKind() == 1) {
                                map[i + 1]->delAllObs();
                            }
                            else if (map[i + 1]->getKind() == 2) {
                                map[i + 1]->setRunObs(false);
                            }
                            map[i]->delAllItems();
                        }
                    }
                    else {
                        if (map[i]->checkCollisionItems(&player[0])) {
                            if (menu.sound)
                                menu.playSound(3);
                            if (map[i + 1]->getKind() == 0) {
                                player[0].plusScore(1);
                            }
                            else if (map[i + 1]->getKind() == 1) {
                                map[i + 1]->delAllObs();
                            }
                            else if (map[i + 1]->getKind() == 2) {
                                map[i + 1]->setRunObs(false);
                            }
                            map[i]->delAllItems();
                        }
                    }
                }
            }
            if (map[map.size() - 1]->getNumOfItems()) {
                if (numOfPlayers > 1) {
                    if (map[map.size() - 1]->checkCollisionItems(&player[0])) {
                        if (menu.sound)
                            menu.playSound(3);
                        map[map.size() - 1]->delAllItems();
                        player[0].plusScore(2);
                    }
                    if (map[map.size() - 1]->checkCollisionItems(&player[1])) {
                        if (menu.sound)
                            menu.playSound(3);
                        map[map.size() - 1]->delAllItems();
                        player[1].plusScore(2);
                    }
                }
                else {
                    if (map[map.size() - 1]->checkCollisionItems(&player[0])) {
                        if (menu.sound)
                            menu.playSound(3);
                        map[map.size() - 1]->delAllItems();
                        player[0].plusScore(2);
                    }
                }
                
            }

            //check thang thua
            int check = checkEndGame();
            if (check != 0)
            {
                if (check == 3)
                {
                    isEnd = true;
                    return;
                }
                else
                {
                    isEnd = true;
                }

                return;
            }

            Sleep(sleepSpeed);
        }
    }
}

void CGAME::levelUp()
{
    if (mode == 0 && menu.sound)
        menu.playSound(2);
    level++;
    if (mode == 0)
    {
        if (trafficLightCoef - 5 > MIN_TRAFFICLIGHT_COEF)
        {
            trafficLightCoef -= 5;
        }
        else
        {
            trafficLightCoef = MIN_TRAFFICLIGHT_COEF;
        }
        while (map.size() != 0)
        {
            delete map[map.size() - 1];
            map.pop_back();
        }
        setMap();
        for (int i = 0; i < map.size(); i++)
            map[i]->draw();
        for (int i = 0; i < player.size(); i++)
        {
            player[i].setDrawMain(&CPLAYER::drawRight);
            player[i].setX((NSCREENWIDTH / (player.size() + 1)) * (i + 1) - player[i].getWidth() / 2);
            player[i].setY(NSCREENHEIGHT - player[i].getHeight() * 2);
        }

        //hien level
        int fromX = NSCREENWIDTH / 2 - 10 * 3, fromY = NSCREENHEIGHT / 2 - 8 * 3;
        //do dai chu + 10
        string levelTemp = "LEVEL " + to_string(level + 1);
        menu.drawTitleFrame(fromX, fromY, 4 + (levelTemp.length() - 1) * 8 + 10, 9, 15);
        CLETTER word;
        word.setLetter(levelTemp, fromX + 6, fromY + 2, 1, 0);
        word.drawWord();

        graphic->display();

        Sleep(700);
    }
    else
    {
        if (trafficLightCoef - 5 > MIN_TRAFFICLIGHT_COEF)
        {
            trafficLightCoef -= 5;
        }
        else
        {
            trafficLightCoef = MIN_TRAFFICLIGHT_COEF;
        }
        int a = 30 - 5 * level;
        if (sleepSpeed - a >= MIN_SLEEP_SPEED)
        {
            sleepSpeed -= a;
        }
        else
            sleepSpeed = MIN_SLEEP_SPEED;
        if (level % 3 == 0)
        {
            if (player[0].getJumpUnit() < MAX_JUMPUNIT)
            {
                for (int i = 0; i < player.size(); i++)
                {
                    player[i].setJumpUnit(player[i].getJumpUnit() + 1);
                }
            }
            if (maxNumObs < MAX_NUM_OF_OBS)
            {
                minNumObs++;
                maxNumObs++;
            }
        }
    }
}

int CGAME::checkEndGame()//0 chua ai thang, 1 la player 1 thang, 2 la player thang hoac mode basic ng choi thua, 3 la hai nguoi choi cung thua
{
    if (map.size() == 0)
        return 0;
    if (numOfPlayers == 1)
    {
        int ended = -1;
        vector<int> index = findMainInMap(0);
        for (int i = 0; i < index.size(); i++)
        {
            ended = map[index[i]]->checkCollision(&player[0]);
            if (ended !=-1)
            {
                for (int i = 0; i < map.size(); i++)
                {
                    map[i]->draw();
                }
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();
                graphic->display();
                if (map[index[i]]->getKind() == 1 && menu.sound)
                    menu.playSound(4);
                else if (map[index[i]]->getKind() == 2 && menu.sound)
                    menu.playSound(5);
                Sleep(300);
                return 2;
            }
        }
        if (mode == 1)
            return 0;
        else
        {
            if (player[0].getY() < 0)
            {
                if (level == MAX_LEVEL)
                {
                    isEnd = true;
                }
                return 1;
            }
            else
                return 0;
        }  
    }
    else
    {
        int deadLane1 = -1, deadLane2 = -1;
        int ended1 = -1, ended2 = -1;
        vector<int> index = findMainInMap(0);
        for (int i = 0; i < index.size(); i++)
        {
            ended1 = map[index[i]]->checkCollision(&player[0]);
            if (ended1 != -1)
            {
                for (int i = 0; i < map.size(); i++)
                {
                    map[i]->draw();
                }
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();
                graphic->display();
                if (map[index[i]]->getKind() == 1 && menu.sound)
                    menu.playSound(4);
                else if (map[index[i]]->getKind() == 2 && menu.sound)
                    menu.playSound(5);
                Sleep(300);
                deadLane1 = index[i];
                break;
            }
        }

      
        index = findMainInMap(1);
        for (int i = 0; i < index.size(); i++)
        {
            ended2 = map[index[i]]->checkCollision(&player[1]);
            if (ended2 != -1)
            {
                for (int i = 0; i < map.size(); i++)
                {
                    map[i]->draw();
                }
                for (int i = 0; i < player.size(); i++)
                    player[i].draw();
                graphic->display();
                if (map[index[i]]->getKind() == 1 && menu.sound)
                    menu.playSound(4);
                else if (map[index[i]]->getKind() == 2 && menu.sound)
                    menu.playSound(5);
                Sleep(300);
                deadLane2 = index[i];
                break;
            }
        }
     

        if (ended1 !=-1 && ended2 !=-1)
        {
            isEnd = true;
            return 3;//ca hai thua
        }
        else if (ended1 !=-1 && ended2 ==-1)
        {
            if (mode == 1)
                isEnd = true;
            else
            {
                if (level == MAX_LEVEL)
                    isEnd = true;
            }
            return 2;
        }
        else if (ended1 == -1 && ended2 !=-1)
        {
            if (mode == 1)
                isEnd = true;
            else
            {
                if (level == MAX_LEVEL)
                    isEnd = true;
            }
            return 1;
        }
        else
        {
            if (mode == 1)
                return 0;
            else
            {
                if (player[0].getY() < 0)
                {
                    if (level == MAX_LEVEL)
                        isEnd = true;
                    return 1;
                }
                if (player[1].getY() < 0)
                {
                    if (level == MAX_LEVEL)
                        isEnd = true;
                    return 2;
                }
                return 0;
            }
        }
    }
}

vector<int> CGAME::findMainInMap(int i)
{
    vector<int> index;
    for (int j = 0; j < map.size(); j++)
    {
        if (!(player[i].getY() > map[j]->getPos() + map[j]->getWidth() - 1 || player[i].getY() + player[i].getHeight() - 1 < map[j]->getPos()))
        {
            index.push_back(j);
        }
    }
    return index;
}



void CGAME::firstMove()
{
    while (1)
    {
        for (int i = 0; i < player.size(); i++)
            if (player[i].move(mode, menu.sound) == true)
                return;
    }
}

bool CGAME::pauseCheck()
{

    bool isPressed;
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));

    if (isPressed = GetAsyncKeyState(27) < 0)
    {

        while (isPressed)
        {

            isPressed = GetAsyncKeyState(27) < 0;
        }
        isPressed = true;
    }


    return isPressed;
}

void CGAME::cleanMap()
{
    for (int i = 0; i < map.size(); i++)
    {
        delete map[i];
        map[i] = NULL;
    }
    map.erase(map.begin(), map.end());
}

void CGAME::collisionEffect(int lane, int index)
{
    if (map[lane]->getKind() == 1)
    {
        bool d = map[lane]->getDirection();
        CVEHICLE policeCar;
        policeCar.setVehicleKind(3, !d);
        policeCar.setY(map[lane]->getPos() + 2);
        if (d == 0)
        {
            policeCar.setX(NSCREENWIDTH);
            while (policeCar.getX() - player[index].getX() > 10)
            {
                policeCar.setX(policeCar.getX() - 3);
                map[lane]->draw();
                policeCar.draw();
                player[index].draw();
                Sleep(100);
                graphic->display();
            }
        }
        else
        {
            policeCar.setX(-20);
        }
    }
}
FileData* CGAME::saveGame()
{
    string name;
    do
    {
        name = string{};
        if (menu.enterNewFileName(name) == false)
            return (FileData*)NULL;
    } while (menu.checkNameFile(name)!=0);
    name = name + ".bin";
    ofstream f;
    f.open(name, ios::binary);
    if (f.is_open())
    {
        FileData* newFile = new FileData;
        newFile->fileName = name;

        f.write((char*)&posYLaneCur, sizeof(indexYCur));

        f.write((char*)&indexYCur, sizeof(indexYCur));

        f.write((char*)&isEnd, sizeof(isEnd));

        f.write((char*)&numOfPlayers, sizeof(numOfPlayers));
        newFile->numOfPlayers = this->numOfPlayers;

        f.write((char*)&mode, sizeof(mode));
        newFile->mode = this->mode;

        f.write((char*)&level, sizeof(level));
        newFile->level = this->level;

        f.write((char*)&sleepSpeed, sizeof(sleepSpeed));
        f.write((char*)&trafficLightCoef, sizeof(trafficLightCoef));
        f.write((char*)&minNumObs, sizeof(minNumObs));
        f.write((char*)&maxNumObs, sizeof(maxNumObs));

        int numOfLanes = map.size();
        f.write((char*)&numOfLanes, sizeof(numOfLanes));

        newFile->namePlayer.resize(newFile->numOfPlayers);
        newFile->scorePlayer.resize(newFile->numOfPlayers);
        newFile->kindCharPlayer.resize(newFile->numOfPlayers);
        for (int i = 0; i < player.size(); i++) {
            newFile->namePlayer[i] = player[i].getName();
            newFile->scorePlayer[i] = player[i].getScore();
            newFile->kindCharPlayer[i] = player[i].getKindChar();
            player[i].saveObject(f);
        }
        for (int i = 0; i < map.size(); i++)
            map[i]->saveLane(f);
        f.close();
        return newFile;
    }
    f.close();
    return NULL;
}
CGAME::~CGAME()
{
    for (int i = 0; i < map.size(); i++)
    {
        if (map[i] != NULL)
        {
            delete map[i];
            map[i] = NULL;
        }
    }
}
