#pragma once
#include <fstream>

#include "CGRAPHIC.h"
#include <thread>
#include "CPLAYER.h"
#include "CLANE.h"
#include "CROAD.h"
#include "CRIVER.h"
#include "CMENU.h"
#include "CLETTER.h"
#include "CITEM.h"

const int MAX_LEVEL = 9;//0 1 2 doi voi classic mode
const int MAX_NUM_OF_OBS = 7;
const int MIN_TRAFFICLIGHT_COEF = 5;
const int MIN_SLEEP_SPEED = 70;
const int WAIT_TIMME = 10;
const int MAX_JUMPUNIT = 7;

extern bool sortNameByScore(RankData a, RankData b);


struct FileData;
class CGAME
{
	bool isEnd;
	int numOfPlayers;
	bool mode; //0 la basic, 1 la endless
	int level; //0 1 2 doi voi mode 1, 0 1 2 3 4 ...  doi voi mode 2
	int sleepSpeed;
	int trafficLightCoef;
	int minNumObs;
	int maxNumObs;
	int minNumItems;
	int maxNumItems;
	int posYLaneCur, indexYCur;
	bool isPause;

	CMENU menu;
	vector<CPLAYER> player;
	vector<CLANE*> map;

	
	void addNewGrass(int y, int numOfItems = 0, int numObs = -1);
	void addNewRoad(int y, int numOfItems = 0, int direction = -1, int numObs = -1, int firstPos = -1);
	void addNewRiver(int y, int numOfItems = 0, int direction = -1, int numObs = -1, int firstPos = -1);
	void generateNewLane();// mode 1
	void setDefaultMap();//mode 1
	void setMap();//mode 0
	void setMotionSpeed(int speed);//mode 0
	void mapMotion();//mode 1
	void motion();//mode 0 va mode 1
	
	void levelUp();//mode 0 va mode 1
	int checkEndGame();//mode 0 va 1
	vector<int> findMainInMap(int i);
	void firstMove();//mode 0 va mode 1
	bool pauseCheck();
	void pauseOptionBoard(int nSelect);

	
	void cleanMap();
	FileData* saveGame();

	bool checkNameFile(string name);
public:
	CGAME();

	void setNumOfPlayers(int num);
	void setMode(bool mode);
	void setMainChar(int i, int selectMain = 0, bool switches = false);//1 la pikachu;  2 la kirby;  3 la mario;
	void setNameForPlayer(int index, string name);
	void setKindCharForPlayer(int index, int kindCharacter);
	int getMode();
	int getNumOfPlayers();
	int getLevel();
	string getPlayerName(int index);
	int getPlayerKindChar(int index);

	void startApp();
	void reset();
	bool loadGame(string fileName); //0 la ko restart, 1 la co restart
	void drawInforBoard();
	bool play(); //0 la ko restart, 1 la co co restart
	int pauseGameSelect(int firstOption);
	pair<bool, int> pauseGameConTrol(thread& Motion, int firstOption);
	void collisionEffect(int lane, int i = 0);
	

	~CGAME();
};

