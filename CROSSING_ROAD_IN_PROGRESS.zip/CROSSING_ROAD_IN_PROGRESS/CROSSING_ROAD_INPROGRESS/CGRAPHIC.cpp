﻿#include "CGRAPHIC.h"

vector<vector<COLORREF>> colorBoard;
wchar_t* pBuffer;
WORD* pColor;
wchar_t* pTmpBuffer;
WORD* pTmpColor;

HANDLE (CGRAPHIC::hStdout) = GetStdHandle(STD_OUTPUT_HANDLE);
DWORD (CGRAPHIC::dwBytesWritten) = 0;

CGRAPHIC* CGRAPHIC::graphic = NULL;

CGRAPHIC* graphic = CGRAPHIC::getGraphic();

CGRAPHIC::CGRAPHIC()
{
	pBuffer = new wchar_t[NSCREENWIDTH * NSCREENHEIGHT];
	pColor = new WORD[NSCREENWIDTH * NSCREENHEIGHT];
	pTmpBuffer = new wchar_t[NSCREENWIDTH * NSCREENHEIGHT];
	pTmpColor = new WORD[NSCREENWIDTH * NSCREENHEIGHT];

	colorBoard.resize(numOfColorBoard);
	for (int i = 0; i < numOfColorBoard; i++) {
		colorBoard[i].resize(16);
	}

	//theme bien
	colorBoard[0][0] = RGB(0, 0, 0);		//black
	colorBoard[0][1] = RGB(255, 255, 255);	//white
	colorBoard[0][2] = RGB(135, 206, 250);	//light sky blue
	colorBoard[0][3] = RGB(70, 130, 180);	//steel blue
	colorBoard[0][4] = RGB(25, 25, 112);	//midnight blue
	colorBoard[0][5] = RGB(255, 127, 80);	//coral
	colorBoard[0][6] = RGB(255, 69, 0);		//orange red
	colorBoard[0][7] = RGB(178, 34, 34);	//firebrick 
	colorBoard[0][8] = RGB(128, 128, 128);	//grey
	colorBoard[0][9] = RGB(192, 192, 192);	//silver
	colorBoard[0][10] = RGB(50, 205, 50);	//lime green
	colorBoard[0][11] = RGB(127, 255, 212);	//aqua marine
	colorBoard[0][12] = RGB(72, 209, 204);	//medium turquoise
	colorBoard[0][13] = RGB(255, 215, 0);	//gold
	colorBoard[0][14] = RGB(0, 139, 139);	//dark cyan
	colorBoard[0][15] = RGB(255, 182, 193);	//light pink

	//theme duong
	colorBoard[1][0] = RGB(0, 0, 0);		//black
	colorBoard[1][1] = RGB(255, 255, 255);	//white
	colorBoard[1][2] = RGB(105, 105, 105);	//dim grey
	colorBoard[1][3] = RGB(160, 82, 45);	//sienna
	colorBoard[1][4] = RGB(220, 20, 60);	//crimson
	colorBoard[1][5] = RGB(135, 206, 250);	//light sky blue
	colorBoard[1][6] = RGB(255, 255, 0);	//yellow
	colorBoard[1][7] = RGB(255, 215, 0);	//gold
	colorBoard[1][8] = RGB(255, 182, 193);	//light pink
	colorBoard[1][9] = RGB(165, 42, 42);	//brown 
	colorBoard[1][10] = RGB(178, 255, 102);	//xanh la 
	colorBoard[1][11] = RGB(0, 153, 76);	//xanh la dam
	colorBoard[1][12] = RGB(204, 255, 204);	//xanh la nhat
	colorBoard[1][13] = RGB(255, 127, 80);	//coral
	colorBoard[1][14] = RGB(220, 220, 220);	//gainsboro (xam nhat)
	colorBoard[1][15] = RGB(255, 228, 181);	//moccasin

}

CGRAPHIC* CGRAPHIC::getGraphic()
{
	if (graphic == NULL) {
		graphic = new CGRAPHIC();
	}
	return graphic;
}

void CGRAPHIC::disableResizeWindow()
{
	HWND hWnd = GetConsoleWindow();
	SetWindowLong(hWnd, GWL_STYLE, GetWindowLong(hWnd, GWL_STYLE) & ~WS_SIZEBOX);
}

void CGRAPHIC::showScrollbar(BOOL Show)
{
	HWND hWnd = GetConsoleWindow();
	ShowScrollBar(hWnd, SB_BOTH, Show);
}

void CGRAPHIC::showCur(bool CursorVisibility)
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO ConCurInf;

	ConCurInf.dwSize = 10;
	ConCurInf.bVisible = CursorVisibility;

	SetConsoleCursorInfo(handle, &ConCurInf);
}

void CGRAPHIC::disableSelection()
{
	HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);

	SetConsoleMode(hStdin, ~ENABLE_QUICK_EDIT_MODE);
}

void CGRAPHIC::setColor(vector<COLORREF>& color)
{
	CONSOLE_SCREEN_BUFFER_INFOEX csbiex;
	csbiex.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

	GetConsoleScreenBufferInfoEx(hStdout, &csbiex);

	for (int i = 0; i < 16; i++) {
		csbiex.ColorTable[i] = color[i];
	}

	SetConsoleScreenBufferInfoEx(hStdout, &csbiex);

	string s = "mode " + to_string(NSCREENWIDTH) + ", " + to_string(NSCREENHEIGHT);
	const char* sizeScreen = s.c_str();
	system(sizeScreen);
}

void CGRAPHIC::configure()
{
	//Disable Button
	HWND hWnd = GetConsoleWindow();
	HMENU hMenu = GetSystemMenu(hWnd, false);
	DeleteMenu(hMenu, SC_MAXIMIZE, MF_BYCOMMAND);
	showScrollbar(0);
	disableResizeWindow();
	SetConsoleTitle(L"CROSSING GAME Project _ Group 06_ 22CLC01 _ HCMUS");

	showCur(0);
	disableSelection();

	//Setup zoom
	CONSOLE_FONT_INFOEX cfiex;
	cfiex.cbSize = sizeof(CONSOLE_FONT_INFOEX);

	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	GetCurrentConsoleFontEx(hConsoleOutput, 0, &cfiex);
	cfiex.dwFontSize.Y = FONT_SIZE;
	SetCurrentConsoleFontEx(hConsoleOutput, 0, &cfiex);
	//

	//Setup WindowSize & ScreenBufferSize
	RECT rectClient, rectWindow;
	GetClientRect(hWnd, &rectClient);
	GetWindowRect(hWnd, &rectWindow);

	MoveWindow(hWnd, X_CONSOLE, Y_CONSOLE, NSCREENWIDTH, NSCREENHEIGHT, TRUE);

	string s = "mode " + to_string(NSCREENWIDTH) + ", " + to_string(NSCREENHEIGHT);
	const char* sizeScreen = s.c_str();
	system(sizeScreen);
	system("color 10");
	//

	//srand(time(0));
}

void CGRAPHIC::clearScreen(int background, int text, int fromX, int fromY, int toX, int toY)
{
	if (fromX >= NSCREENWIDTH)
		return;
	if (toX < 0)
		return;
	if (fromY >= NSCREENHEIGHT)
		return;
	if (toY < 0)
		return;
	if (fromX < 0)
		fromX = 0;
	if (toX >= NSCREENWIDTH)
		toX = NSCREENWIDTH - 1;
	if (fromY < 0)
		fromY = 0;
	if (toY >= NSCREENHEIGHT)
		toY = NSCREENHEIGHT - 1;
	for (int i = fromX; i <= toX; i++)
	{
		for (int j = fromY; j <= toY; j++)
		{
			pBuffer[j * NSCREENWIDTH + i] = L' ';
			pColor[j * NSCREENWIDTH + i] = background * 16 + text;
		}
	}
}

void CGRAPHIC::display(int fromX, int fromY, int toX, int toY)
{
	if (fromX >= NSCREENWIDTH)
		return;
	if (toX < 0)
		return;
	if (fromY >= NSCREENHEIGHT)
		return;
	if (toY < 0)
		return;
	if (fromX < 0)
		fromX = 0;
	if (toX >= NSCREENWIDTH)
		toX = NSCREENWIDTH - 1;
	if (fromY < 0)
		fromY = 0;
	if (toY >= NSCREENHEIGHT)
		toY = NSCREENHEIGHT - 1;
	
	COORD cPos{};
	cPos.X = 0;
	cPos.Y = fromY;
	//int width = toX - fromX + 1, height = toY - fromY + 1;
	int width = NSCREENWIDTH, height = toY - fromY + 1;
	WORD* pCopiedColor = new WORD[width * height];
	wchar_t* pCopiedBuffer = new wchar_t[width * height];

	//int index = 0;
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			pCopiedColor[i * width + j] = pColor[(fromY + i) * NSCREENWIDTH + j];
			pCopiedBuffer[i * width + j] = pBuffer[(fromY + i) * NSCREENWIDTH + j];
		}
	}
	

	const WORD* color = pCopiedColor;
	WriteConsoleOutputAttribute(hStdout, color, width * height, cPos, &dwBytesWritten);
	const wchar_t* wchArr = pCopiedBuffer;
	WriteConsoleOutputCharacter(hStdout, wchArr, width * height, cPos, &dwBytesWritten);

}



void CGRAPHIC::drawObject(vector<std::wstring> wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.size(); i++)
	{
		text(wsContent.at(i), wColor, nPosX, nPosY + i);
	}
}

void CGRAPHIC::text(std::wstring wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.length(); i++, nPosX++)
	{
		pBuffer[nPosY * NSCREENWIDTH + nPosX] = wsContent.at(i);
		if (pBuffer[nPosY * NSCREENWIDTH + nPosX] != ' ') {
			pColor[nPosY * NSCREENWIDTH + nPosX] = wColor;
		}
	}
}

void CGRAPHIC::setTmp(int fromX, int fromY, int toX, int toY)
{
	if (fromX >= NSCREENWIDTH)
		return;
	if (toX < 0)
		return;
	if (fromY >= NSCREENHEIGHT)
		return;
	if (toY < 0)
		return;
	if (fromX < 0)
		fromX = 0;
	if (toX >= NSCREENWIDTH)
		toX = NSCREENWIDTH - 1;
	if (fromY < 0)
		fromY = 0;
	if (toY >= NSCREENHEIGHT)
		toY = NSCREENHEIGHT - 1;
	for (int i = fromY; i <= toY; i++)
		for (int j = fromX; j <= toX; j++)
		{
			pTmpBuffer[i * NSCREENWIDTH + j] = pBuffer[i * NSCREENWIDTH + j];
			pTmpColor[i * NSCREENWIDTH + j] = pColor[i * NSCREENWIDTH + j];
		}
}

void CGRAPHIC::getTmp(int fromX, int fromY, int toX, int toY)
{
	if (fromX >= NSCREENWIDTH)
		return;
	if (toX < 0)
		return;
	if (fromY >= NSCREENHEIGHT)
		return;
	if (toY < 0)
		return;
	if (fromX < 0)
		fromX = 0;
	if (toX >= NSCREENWIDTH)
		toX = NSCREENWIDTH - 1;
	if (fromY < 0)
		fromY = 0;
	if (toY >= NSCREENHEIGHT)
		toY = NSCREENHEIGHT - 1;
	for (int i = fromY; i <= toY; i++)
		for (int j = fromX; j <= toX; j++)
		{
			pBuffer[i * NSCREENWIDTH + j] = pTmpBuffer[i * NSCREENWIDTH + j];
			pColor[i * NSCREENWIDTH + j] = pTmpColor[i * NSCREENWIDTH + j];
		}
}

void CGRAPHIC::gotoXY(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

CGRAPHIC::~CGRAPHIC()
{
	if (graphic != NULL) {
		delete graphic;
		graphic = NULL;
	}

	if (pBuffer != NULL)
	{
		delete[] pBuffer;
		pBuffer = NULL;
	}

	if (pColor != NULL)
	{
		delete[] pColor;
		pColor = NULL;
	}

	if (pTmpBuffer != NULL)
	{
		delete[] pTmpBuffer;
		pTmpBuffer = NULL;
	}

	if (pTmpColor != NULL)
	{
		delete[] pTmpColor;
		pTmpColor = NULL;
	}
}
