#pragma once
#ifndef _CGRAPHIC_H
#define _CGRAPHIC_H
#include <iostream>
#include <Windows.h>
#include <vector>
#include <string>
#include <conio.h>
#include <time.h>
#define NSCREENWIDTH 232
#define NSCREENHEIGHT 64
#define X_CONSOLE 30
#define Y_CONSOLE 1
#define FONT_SIZE 12
#define BACKGROUND1 4
#define BACKGROUND2 10

using namespace std;

extern vector<vector<COLORREF>> colorBoard;//set moi trang mot bang mau hoac set theo theme
extern wchar_t* pBuffer;
extern WORD* pColor;
extern wchar_t* pTmpBuffer;
extern WORD* pTmpColor;

//Singleton
//boi vi graphic can khoi tao ban dau nen phai xai Singleton thay vi static
class CGRAPHIC
{
	static CGRAPHIC* graphic;
	static HANDLE hStdout;
	static DWORD dwBytesWritten;

	const int numOfColorBoard = 2;

	CGRAPHIC();
public:
	static CGRAPHIC* getGraphic();
	static void disableResizeWindow();
	static void showScrollbar(BOOL Show);
	static void showCur(bool CursorVisibility);
	static void disableSelection();
	static void setColor(vector<COLORREF>& color);
	static void configure();
	static void clearScreen(int background, int text, int fromX = 0, int fromY = 0, int toX = NSCREENWIDTH - 1, int toY = NSCREENHEIGHT - 1);
	static void display(int fromX = 0, int fromY = 0, int toX = NSCREENWIDTH - 1, int toY = NSCREENHEIGHT - 1);
	static void drawObject(vector<std::wstring> wsContent, WORD wColor, int nPosX, int nPosY);
	static void text(std::wstring wsContent, WORD wColor, int nPosX, int nPosY);
	static void setTmp(int fromX = 0, int fromY = 0, int toX = NSCREENWIDTH - 1, int toY = NSCREENHEIGHT - 1);
	static void getTmp(int fromX = 0, int fromY = 0, int toX = NSCREENWIDTH - 1, int toY = NSCREENHEIGHT - 1);
	static void drawNotiBoard2(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, int height);

	static void gotoXY(int x, int y);
	
	~CGRAPHIC();

};

extern CGRAPHIC* graphic;

#endif // !_CGRAPHIC_H



