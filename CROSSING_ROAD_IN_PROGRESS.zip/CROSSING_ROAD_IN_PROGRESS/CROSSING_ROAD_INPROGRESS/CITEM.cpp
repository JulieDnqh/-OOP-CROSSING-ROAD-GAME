﻿#include "CITEM.h"

CITEM::CITEM()
{
	setWidth(7);
	setHeight(4);
}

CITEM::CITEM(int x, int y)
{
	pos.X = x;
	pos.Y = y;
	setWidth(7);
	setHeight(4);
}

void CITEM::draw()
{
	//row 1
	int fromY = pos.Y, fromX = pos.X, nScreenWidth = NSCREENWIDTH;

	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	for (int i = 1; i <= 5; i++) {
		if (fromX + i >= 0 && fromX + i < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + i)] = (pColor[(fromY)*nScreenWidth + (fromX + i)] / 16) * 16 + 13;
		}
	}

	//row 2
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = 3 * 16 + 13;
		}

		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 13 * 16 + 13;
		}
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 13 * 16 + 11;
		}
		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 11 * 16 + 13;
		}
		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 13 * 16 + 11;
		}
		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 13 * 16 + 13;
		}
		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 13 * 16 + 13;
		}
	}

	//row 3
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = 3 * 16 + 13;
		}

		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 13 * 16 + 13;
		}

		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 13 * 16 + 13;
		}

		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 13 * 16 + 11;
		}
		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 13 * 16 + 15;
		}
		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 13 * 16 + 15;
		}
		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 13 * 16 + 13;
		}
	}

	//row 4
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 3;
		}
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 3 * 16 + 13;
		}
		for (int i = 2; i <= 5; i++) {
			if (fromX + i >= 0 && fromX + i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'▄';
				pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = 13 * 16 + 3;
			}
		}
		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 13;
		}
	}
}

void CITEM::loadItems(ifstream& f)
{
	f.read((char*)&pos.X, sizeof(pos.X));
	f.read((char*)&pos.Y, sizeof(pos.Y));
}

void CITEM::saveObject(ofstream& f)
{
	f.write((char*)&pos.X, sizeof(pos.X));
	f.write((char*)&pos.Y, sizeof(pos.Y));
}