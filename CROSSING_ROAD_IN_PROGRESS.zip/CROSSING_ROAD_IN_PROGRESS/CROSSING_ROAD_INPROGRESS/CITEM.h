#pragma once
#include "COBJECT.h"

class CITEM :public COBJECT
{
public:
	CITEM();
	CITEM(int x, int y);
	void draw();
	virtual void saveObject(ofstream& f);
	void loadItems(ifstream& f);
};

