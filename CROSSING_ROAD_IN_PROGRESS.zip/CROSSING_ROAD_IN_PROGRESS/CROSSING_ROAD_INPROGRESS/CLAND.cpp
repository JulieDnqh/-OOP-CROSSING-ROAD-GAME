﻿#include "CLAND.h"

CLAND::CLAND()
{
	kind = 3;
	pos = 0;
	width = 8;
	numOfObs = 0;
	distanceBetObs = 50;
	motionSpeed = 3;
	
}

CLAND::CLAND(int y)
{
	kind = 3;
	pos = y;
	width = 8;
	numOfObs = 0;
	distanceBetObs = 50;
	motionSpeed = 3;
}

CLAND::CLAND(int y, int numObs)
{
	kind = 1;
	pos = y;
	width = 8;
	numOfObs = numObs;
	firstObsPos = 5;
	distanceBetObs = NSCREENWIDTH / numOfObs;
	motionSpeed = 3;
}

CLAND::CLAND(int y, int numObs, int distance)
{
	kind = 1;
	pos = y;
	width = 8;
	numOfObs = numObs;
	firstObsPos = 5;
	this->distanceBetObs = distanceBetObs;
	motionSpeed = 3;
}

void CLAND::draw()
{
	for (int i = pos; i < pos + width; i++)
	{
		if (i >= 0 && i < NSCREENHEIGHT)
			for (int j = 0; j < NSCREENWIDTH; j++)
			{
				pBuffer[(i) * NSCREENWIDTH + j] = L'█';
				pColor[(i) * NSCREENWIDTH + j] = 3 * 16 + 3;
			}
	}

	for (int i = 0; i < item.size(); i++) {
		item[i]->draw();
	}
}
