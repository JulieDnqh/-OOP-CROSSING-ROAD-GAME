#pragma once
#include "CGRAPHIC.h"
#include "CLANE.h"
class CLAND:public CLANE
{
public:
	CLAND();
	CLAND(int y);
	CLAND(int y, int numObs);
	CLAND(int y, int numObs, int distance);
	void draw();
};

