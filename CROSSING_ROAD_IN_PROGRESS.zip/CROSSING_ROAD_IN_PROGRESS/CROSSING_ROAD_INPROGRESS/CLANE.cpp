﻿#include "CLANE.h"

CLANE::CLANE()
{
	pos = 0;
	firstObsPos = 0;
	width = 8;
	distanceBetObs = 0;
	numOfObs = 0;
	numOfItems = 0;
	motionSpeed = 0;
	kind = 0;//0 la ClANE, 1 LA CROAD, 
	direction = 0;
	runObs = true;
	obstacle.resize(0);
	
}

CLANE::CLANE(int y)	
{
	pos = y;
	firstObsPos = 0;
	width = 8;
	distanceBetObs = 0;
	numOfObs = 0;
	numOfItems = 0;
	motionSpeed = 0;
	kind = 0;//0 la ClANE, 1 LA CROAD, 
	direction = 0;
	runObs = true;
	obstacle.resize(0);
}

int CLANE::getKind()
{
	return kind;
}

void CLANE::drawGrass(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	if (fromY >= 0 && fromY < NSCREENHEIGHT && fromX >= 0 && fromX < NSCREENWIDTH)
	{
		pBuffer[(fromY)*nScreenWidth + (fromX)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX)] = (pColor[(fromY)*nScreenWidth + (fromX)] / 16) * 16 + 11;
	}

	if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT && fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + 11;
	}

	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 10 * 16 + 11;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 10 * 16 + 11;
		}

	}

	if (fromY >= 0 && fromY < NSCREENHEIGHT && fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
	}

	if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT && fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
	}

	if (fromY >= 0 && fromY < NSCREENHEIGHT && fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + 6)] = 10 * 16 + 11;
	}
}

int CLANE::getPos()
{
	return pos;
}

void CLANE::setPos(int y)
{
	int gap = y - pos;
	pos = y;
	for (int i = 0; i < obstacle.size(); i++)
		obstacle[i]->setY(obstacle[i]->getY() + gap);
	for (int i = 0; i < item.size(); i++) {
		item[i]->setY(item[i]->getY() + gap);
	}
}

void CLANE::setFirstObsPos(int pos)
{
	firstObsPos = pos;
}

void CLANE::setFirstItemsPos(int pos)
{
	firstItemsPos = pos;
}

void CLANE::setWidth(int width)
{
	this->width = width;
}

void CLANE::setDistanceBetObs(int distance)
{
	distanceBetObs = distance;
	if (direction == 1)
	{
		if (distanceBetObs > 0)
			distanceBetObs *= -1;
	}
	else
	{
		if (distanceBetObs < 0)
			distanceBetObs *= -1;
	}
}

void CLANE::setDistanceBetItems(int distance)
{
	distanceBetItems = distance;
	/*if (direction == 1)
	{
		if (distanceBetObs > 0)
			distanceBetObs *= -1;
	}
	else
	{
		if (distanceBetObs < 0)
			distanceBetObs *= -1;
	}*/
}

void CLANE::setNumOfObs(int num)
{
	numOfObs = num;
}

void CLANE::setNumOfItems(int num)
{
	numOfItems = num;
}

void CLANE::setMotionSpeed(int speed)
{
	motionSpeed = speed;
	if (direction == 1)
	{
		if (motionSpeed > 0)
			motionSpeed *= -1;
	}
	else
	{
		if (motionSpeed < 0)
			motionSpeed *= -1;
	}
		
}

void CLANE::setDirection(bool direction)
{
	this->direction = direction;
	if (direction == 1)
	{
		if (motionSpeed > 0)
			motionSpeed *= -1;
		if (distanceBetObs > 0)
			distanceBetObs *= -1;
	}
	else
	{
		if (motionSpeed < 0)
			motionSpeed *= -1;
		if (distanceBetObs < 0)
			distanceBetObs *= -1;
	}
}

void CLANE::setRunObs(bool runObs)
{
	this->runObs = runObs;
}

int CLANE::getWidth()
{
	return width;
}

int CLANE::getDistanceBetObs()
{
	return distanceBetObs;
}

int CLANE::getDistanceBetItems()
{
	return distanceBetItems;
}

void CLANE::addObstacle(COBJECT* obstacle)
{
	if (this->obstacle.size() == 0)
	{
		obstacle->setX(firstObsPos);
	}
	else
	{
		if (direction == 0)
		{
			obstacle->setX(this->obstacle[this->obstacle.size() - 1]->getX() - obstacle->getWidth() - distanceBetObs + 1);
		}
		else
		{
			obstacle->setX(this->obstacle[this->obstacle.size() - 1]->getX() + this->obstacle[this->obstacle.size() - 1]->getWidth() - 1 - distanceBetObs);
		}
	}
	obstacle->setY(pos + width / 2 - obstacle->getHeight() / 2);
	this->obstacle.push_back(obstacle);
	numOfObs = this->obstacle.size();
}

void CLANE::addItems(COBJECT* item)
{
	if (this->item.size() == 0) {
		item->setX(firstItemsPos);
	}
	else {
		item->setX(this->item[this->item.size() - 1]->getX() - obstacle[obstacle.size() - 1]->getWidth() - distanceBetItems + 1);
	}
	item->setY(pos + width / 2 - item->getHeight() / 2);
	this->item.push_back(item);
	numOfItems = this->item.size();
}

void CLANE::delAllObs()
{
	for (int i = 0; i < obstacle.size(); i++) {
		if (obstacle[i] != NULL) {
			delete obstacle[i];
			obstacle[i] = NULL;
		}
	}
	obstacle.erase(obstacle.begin(),obstacle.end());
	this->numOfObs = 0;
}

void CLANE::delAllItems()
{
	for (int i = 0; i < item.size(); i++) {
		if (item[i] != NULL) {
			delete item[i];
			item[i] = NULL;
		}
	}
	item.clear();
	this->numOfItems = 0;
}

int CLANE::getNumOfObs()
{
	return obstacle.size() > 0 ? obstacle.size() : numOfObs;
}

int CLANE::getNumOfItems()
{
	return item.size() > 0 ? item.size() : numOfItems;
}

int CLANE::getMotionSpeed()
{
	return motionSpeed;
}

void CLANE::generateNewObstacle()
{
	if (obstacle.size() <= 0)
		return;
	int pre = obstacle.size() - 1;
	COBJECT* obstacle = new CBOUY;
	if (this->obstacle[pre]->getX() > distanceBetObs)
		obstacle->setX(-obstacle->getWidth());
	else
		obstacle->setX(this->obstacle[pre]->getX() - obstacle->getWidth() - distanceBetObs + 1);
	obstacle->setY(pos + width / 2 - obstacle->getHeight() / 2);
	
	this->obstacle.push_back(obstacle);
	numOfObs = this->obstacle.size();
}

int CLANE::getDirection()
{
	return direction;
}
COBJECT* CLANE::getObstacle(int index)
{
	if (index > 0 && index < obstacle.size())
		return obstacle[index];
	else
		return NULL;
}

void CLANE::obstacleMotion()
{
	int maxwidth = 19;
	if (kind == 2)
		maxwidth = 12;
	if (runObs) {
		for (int i = 0; i < obstacle.size(); i++)
		{
			if (obstacle[i]->getX() + motionSpeed < NSCREENWIDTH && obstacle[i]->getX() + obstacle[i]->getWidth() - 1 + motionSpeed >= 0)
				obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
			else
			{
				if (direction == 0)
				{
					if (obstacle[i]->getX() + motionSpeed >= NSCREENWIDTH)
					{
						/*if (obstacle[i]->getObjectKind() == 1)
						{
							CVEHICLE* vehicle = dynamic_cast<CVEHICLE*>(obstacle[i]);
							vehicle->setVehicleKind(rand() % 4, direction);
						}*/
						obstacle[i]->setY(pos + width / 2 - obstacle[i]->getHeight() / 2);
						int pre;
						if (i == 0)
							pre = obstacle.size() - 1;
						else
							pre = i - 1;
						if (obstacle[pre]->getX() > distanceBetObs)
						{
							obstacle[i]->setX(-obstacle[i]->getWidth() + 1);
							if (i == 0)
								obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
						}
						else
						{
							obstacle[i]->setX(obstacle[pre]->getX() - obstacle[i]->getWidth() - distanceBetObs + 1);
							if (i == 0)
								obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
						}

					}
					else
					{
						obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
					}
				}
				else
				{
					if (obstacle[i]->getX() + obstacle[i]->getWidth() - 1 + motionSpeed < 0)
					{
						/*if (obstacle[i]->getObjectKind() == 1)
						{
							CVEHICLE* vehicle = dynamic_cast<CVEHICLE*>(obstacle[i]);
							vehicle->setVehicleKind(rand() % 4, direction);
						}*/
						obstacle[i]->setY(pos + width / 2 - obstacle[i]->getHeight() / 2);
						int pre;
						if (i == 0)
							pre = obstacle.size() - 1;
						else
							pre = i - 1;
						if (obstacle[pre]->getX() + obstacle[i]->getWidth() - 1 < NSCREENWIDTH + distanceBetObs)
						{
							obstacle[i]->setX(NSCREENWIDTH);
							if (i == 0)
								obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
						}
						else
						{
							obstacle[i]->setX(obstacle[pre]->getX() + obstacle[pre]->getWidth() - 1 - distanceBetObs);
							if (i == 0)
								obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
						}
					}
					else
					{
						obstacle[i]->setX(obstacle[i]->getX() + motionSpeed);
					}
				}

			}

		}
	}
	
}

void CLANE::itemsMotion()
{
	for (int i = 0; i < item.size(); i++)
	{
		//if (item[i]->getX() + motionSpeed < NSCREENWIDTH)
			item[i]->setX(obstacle[i]->getX() + obstacle[i]->getWidth()/2 - item[i]->getWidth()/2);
		//else
		//{
		//	int pre;
		//	if (i == 0)
		//		pre = item.size() - 1;//cuoi
		//	else
		//		pre = i - 1;

		//	if (item[pre]->getX() > distanceBetItems)
		//	{
		//		item[i]->setX(-obstacle[i]->getWidth() + 1);
		//		if (i == 0)
		//			item[i]->setX(obstacle[i]->getX() + motionSpeed);
		//	}
		//	else
		//	{
		//		item[i]->setX(obstacle[pre]->getX() - obstacle[i]->getWidth() - distanceBetItems + 1);
		//		if (i == 0)
		//			item[i]->setX(obstacle[i]->getX() + motionSpeed);
		//	}
		//}
	}
}

int CLANE::checkCollision(CPLAYER* player)
{
	COORD point1, point2, point3, point4;
	point1.X = player->getX();
	point1.Y = player->getY();
	point2.X = point1.X + short(player->getWidth()) - 1;
	point2.Y = point1.Y;
	point3.X = point2.X;
	point3.Y = point1.Y + short(player->getHeight()) - 1;
	point4.X = point1.X;
	point4.Y = point3.Y;
	int check = -1;
	for (int i = 0; i < obstacle.size(); i++)
	{
		int x1 = obstacle[i]->getX(), x2 = x1 + obstacle[i]->getWidth() - 1;
		int y1 = obstacle[i]->getY(), y2 = y1 + obstacle[i]->getHeight() - 1;
		if (point1.X >= x1 && point1.X <= x2 && point1.Y >= y1 && point1.Y <= y2)
		{
			check = i;
			break;
		}
		else if (point2.X >= x1 && point2.X <= x2 && point2.Y >= y1 && point2.Y <= y2)
		{
			check = i;
			break;
		}
		else if (point3.X >= x1 && point3.X <= x2 && point3.Y >= y1 && point3.Y <= y2)
		{
			check = i;
			break;
		}
		else if (point4.X >= x1 && point4.X <= x2 && point4.Y >= y1 && point4.Y <= y2)
		{
			check = i;
			break;
		}
	}

	if (check !=-1)
	{
		if (player->getKindChar() == 1)
		{
			player->setDrawMain(&CPLAYER::drawDead);
			draw();
			player->draw();
			graphic->display();
		}
	}

	return check;
}

bool CLANE::checkCollisionItems(CPLAYER* player)
{
	int x1 = player->getX(), x2 = x1 + player->getWidth() - 1;
	int y1 = player->getY(), y2 = y1 + player->getHeight() - 1;

	for (int i = 0; i < item.size(); i++) {
		COORD point1, point2, point3, point4;
		point1.X = item[i]->getX();
		point1.Y = item[i]->getY();

		point2.X = point1.X + short(item[i]->getWidth()) - 1;
		point2.Y = point1.Y;

		point3.X = point2.X;
		point3.Y = point1.Y + short(item[i]->getHeight()) - 1;

		point4.X = point1.X;
		point4.Y = point3.Y;

		if (point1.X >= x1 && point1.X <= x2 && point1.Y >= y1 && point1.Y <= y2)
		{

			return true;
		}
		else if (point2.X >= x1 && point2.X <= x2 && point2.Y >= y1 && point2.Y <= y2)
		{
			return true;
		}
		else if (point3.X >= x1 && point3.X <= x2 && point3.Y >= y1 && point3.Y <= y2)
		{
			return true;
		}
		else if (point4.X >= x1 && point4.X <= x2 && point4.Y >= y1 && point4.Y <= y2)
		{
			return true;
		}

	}

	return false;
}

void CLANE::draw()
{

	for (int i = pos; i < pos + width; i++)
	{
		if (i >= 0 && i < NSCREENHEIGHT)
			for (int j = 0; j < NSCREENWIDTH; j++)
			{
				pBuffer[(i)*NSCREENWIDTH + j] = L'█';
				pColor[(i)*NSCREENWIDTH + j] = 10 * 16 + 10;
			}
	}

	for (int i = 25; i < 232; i = i + 30) {
		drawGrass(i, pos + 2);
	}
	for (int i = 10; i < 232; i = i + 30) {
		drawGrass(i, pos + 5);
	}

	for (int i = 0; i < item.size(); i++) {
		item[i]->draw();
	}
	
	
}

void CLANE::saveLane(ofstream& f)
{
	
	f.write((char*)&kind, sizeof(kind));
	f.write((char*)&pos, sizeof(pos));
	f.write((char*)&width, sizeof(width));
	f.write((char*)&firstObsPos, sizeof(firstObsPos));
	f.write((char*)&firstItemsPos, sizeof(firstItemsPos));
	f.write((char*)&distanceBetObs, sizeof(distanceBetObs));
	f.write((char*)&distanceBetItems, sizeof(distanceBetItems));
	f.write((char*)&motionSpeed, sizeof(motionSpeed));
	f.write((char*)&direction, sizeof(direction));
	f.write((char*)&numOfObs, sizeof(numOfObs));
	f.write((char*)&numOfItems, sizeof(numOfItems));

	for (int i = 0; i < numOfObs; i++)
	{
		obstacle[i]->saveObject(f);
	}
	for (int i = 0; i < numOfItems; i++) {
		item[i]->saveObject(f);
	}
}

void CLANE::loadLane(ifstream& f)
{
	
	f.read((char*)&pos, sizeof(pos));
	f.read((char*)&width, sizeof(width));
	f.read((char*)&firstObsPos, sizeof(firstObsPos));
	f.read((char*)&firstItemsPos, sizeof(firstItemsPos));
	f.read((char*)&distanceBetObs, sizeof(distanceBetObs));
	f.read((char*)&distanceBetItems, sizeof(distanceBetItems));
	f.read((char*)&motionSpeed, sizeof(motionSpeed));
	f.read((char*)&direction, sizeof(direction));
	f.read((char*)&numOfObs, sizeof(numOfObs));
	f.read((char*)&numOfItems, sizeof(numOfItems));
	for (int i = 0; i < numOfObs; i++)
	{
		int objKind;
		f.read((char*)&objKind, sizeof(objKind));
		if (objKind == 1)
		{
			COBJECT* obj = new CVEHICLE;
			CVEHICLE* vehicle = dynamic_cast<CVEHICLE*>(obj);
			vehicle->loadVehicle(f, direction);
			this->obstacle.push_back(obj);
		}
		else if (objKind == 2)
		{

			COBJECT* obj = new CBOUY;
			CBOUY* bouy = dynamic_cast<CBOUY*>(obj);
			bouy->loadBouy(f);
			this->obstacle.push_back(obj);
		}
	}
	for (int i = 0; i < numOfItems; i++) {
		CITEM* item = new CITEM;
		item->loadItems(f);
		this->item.push_back(item);
	}
}

void CLANE::collisionEffect()
{
	
}

CLANE:: ~CLANE()
{
	for (int i = 0; i < obstacle.size(); i++)
	{
		if (obstacle[i] != NULL)
		{
			delete obstacle[i];
			obstacle[i] = NULL;
		}
	}

	for (int i = 0; i < item.size(); i++) {
		if (item[i] != NULL) {
			delete item[i];
			item[i] = NULL;
		}
	}
}
