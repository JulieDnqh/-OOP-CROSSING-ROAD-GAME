#pragma once
#ifndef _CLANE_H
#define _CLANE_H

#include"COBJECT.h"
#include "CITEM.h"
#include "CBOUY.h"
#include "CVEHICLE.h"
#include "CPLAYER.h"
class CLANE
{
protected:
	int pos;
	int firstObsPos;
	int firstItemsPos;
	int width;
	int distanceBetObs;
	int distanceBetItems;
	int numOfObs;
	int numOfItems;
	int motionSpeed;
	int kind;//0 la ClANE, 1 LA CROAD, 
	bool direction;
	bool runObs;
	vector<COBJECT*> obstacle;
	vector<COBJECT*> item;
	void drawGrass(int fromX, int fromY);

	
public:
	CLANE();
	CLANE(int y);

	int getKind();

	void setPos(int y);
	void setFirstObsPos(int pos);
	void setFirstItemsPos(int pos);
	void setWidth(int width);
	void setDistanceBetObs(int distance);
	void setDistanceBetItems(int distance);
	void setNumOfObs(int num);
	void setNumOfItems(int num);
	void setMotionSpeed(int speed);
	void setDirection(bool direction);
	void setRunObs(bool runObs);

	int getPos();
	int getNumOfObs();
	int getNumOfItems();
	int getWidth();
	int getDistanceBetObs();
	int getDistanceBetItems();
	int getMotionSpeed();
	int getDirection();
	COBJECT* getObstacle(int index);

	void addObstacle(COBJECT* obstacle);
	void addItems(COBJECT* item);
	
	void delAllObs();
	void delAllItems();

	virtual void generateNewObstacle();
	virtual void obstacleMotion();
	virtual void itemsMotion();
	virtual int checkCollision(CPLAYER* player);
	virtual bool checkCollisionItems(CPLAYER* player);
	virtual void draw();
	virtual void saveLane(ofstream& f);
	virtual void loadLane(ifstream& f);

	virtual void collisionEffect();
	virtual ~CLANE();
};
#endif


