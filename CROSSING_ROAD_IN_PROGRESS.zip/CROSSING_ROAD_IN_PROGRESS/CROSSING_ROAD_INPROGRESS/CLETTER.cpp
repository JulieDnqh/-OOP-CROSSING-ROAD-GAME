﻿#include "CLETTER.h"

CLETTER::CLETTER()
{
	this->width = 7;
	this->height = 4;
	this->x = 10;
	this->y = 2;
	this->color = { 1 };
	this->colorbg = 0;
	this->colorSpace = 10;
}

int CLETTER::getWidh()
{
	return width;
}

int CLETTER::getHeight()
{
	return height;
}

int CLETTER::getX()
{
	return x;
}

void CLETTER::setX(int x)
{
	this->x = x;
}

void CLETTER::setLetter(string name, int x, int y, vector<int>& color, int colorbg, int colorSpace)
{
	Draw.clear();
	posX.clear();
	posSpace.clear();

	this->x = x;
	this->y = y;
	this->color = color;
	this->colorbg = colorbg;
	this->colorSpace = colorSpace;
	this->width = 7;

	int posXTemp = x;

	//void(CLETTER:: * draw)(int, int, int, int);

	for (int i = 0; i < name.length(); i++) {

		if (name[i] == 'A') {
			//draw = &CLETTER::A;
			Draw.push_back(&CLETTER::A);
		}
		if (name[i] == 'B') {
			//draw = &CLETTER::B;
			Draw.push_back(&CLETTER::B);
		}
		if (name[i] == 'C') {
			//draw = &CLETTER::C;
			Draw.push_back(&CLETTER::C);
		}
		if (name[i] == 'D') {
			//draw = &CLETTER::D;
			Draw.push_back(&CLETTER::D);
		}
		if (name[i] == 'E') {
			//draw = &CLETTER::E;
			Draw.push_back(&CLETTER::E);
		}
		if (name[i] == 'F') {
			//draw = &CLETTER::F;
			Draw.push_back(&CLETTER::F);
		}
		if (name[i] == 'G') {
			//draw = &CLETTER::G;
			Draw.push_back(&CLETTER::G);
		}
		if (name[i] == 'H') {
			//draw = &CLETTER::H;
			Draw.push_back(&CLETTER::H);
		}
		if (name[i] == 'I' || name[i] == '1') {
			//draw = &CLETTER::I;
			Draw.push_back(&CLETTER::I);
			this->width = 4;
		}
		if (name[i] == 'J') {
			//draw = &CLETTER::J;
			Draw.push_back(&CLETTER::J);
		}
		if (name[i] == 'K') {
			//draw = &CLETTER::K;
			Draw.push_back(&CLETTER::K);
		}
		if (name[i] == 'L') {
			//draw = &CLETTER::L;
			Draw.push_back(&CLETTER::L);
		}
		if (name[i] == 'M') {
			//draw = &CLETTER::M;
			Draw.push_back(&CLETTER::M);
			width = 9;
		}
		if (name[i] == 'N') {
			//draw = &CLETTER::N;
			Draw.push_back(&CLETTER::N);
			width = 8;
		}
		if (name[i] == 'O') {
			//draw = &CLETTER::O;
			Draw.push_back(&CLETTER::O);
		}
		if (name[i] == 'P') {
			//draw = &CLETTER::P;
			Draw.push_back(&CLETTER::P);
		}
		if (name[i] == 'Q') {
			//draw = &CLETTER::Q;
			Draw.push_back(&CLETTER::Q);
			this->width = 8;
		}
		if (name[i] == 'R') {
			//draw = &CLETTER::R;
			Draw.push_back(&CLETTER::R);
		}
		if (name[i] == 'S') {
			//draw = &CLETTER::S;
			Draw.push_back(&CLETTER::S);
		}
		if (name[i] == 'T') {
			//draw = &CLETTER::T;
			Draw.push_back(&CLETTER::T);
			width = 8;
		}
		if (name[i] == 'U') {
			//draw = &CLETTER::U;
			Draw.push_back(&CLETTER::U);
		}
		if (name[i] == 'V') {
			//draw = &CLETTER::V;
			Draw.push_back(&CLETTER::V);
		}
		if (name[i] == 'W') {
			//draw = &CLETTER::W;
			Draw.push_back(&CLETTER::W);
			this->width = 9;
		}
		if (name[i] == 'X') {
			//draw = &CLETTER::X;
			Draw.push_back(&CLETTER::X);
		}
		if (name[i] == 'Y') {
			//draw = &CLETTER::Y;
			Draw.push_back(&CLETTER::Y);
			this->width = 8;
		}
		if (name[i] == 'Z') {
			//draw = &CLETTER::Z;
			Draw.push_back(&CLETTER::Z);
		}
		if (name[i] == ' ') {
			posSpace.push_back(i);

			//draw = &CLETTER::space;
			Draw.push_back(&CLETTER::space);
			this->width = (this->width + 1) / 2;
		}
		if (name[i] == '0') {
			//draw = &CLETTER::num0;
			Draw.push_back(&CLETTER::num0);
		}
		if (name[i] == '2') {
			//draw = &CLETTER::num2;
			Draw.push_back(&CLETTER::num2);
		}
		if (name[i] == '3') {
			//draw = &CLETTER::num3;
			Draw.push_back(&CLETTER::num3);
		}
		if (name[i] == '4') {
			//draw = &CLETTER::num4;
			Draw.push_back(&CLETTER::num4);
		}
		if (name[i] == '5') {
			//draw = &CLETTER::num5;
			Draw.push_back(&CLETTER::num5);
		}
		if (name[i] == '6') {
			//draw = &CLETTER::num6;
			Draw.push_back(&CLETTER::num6);
		}
		if (name[i] == '7') {
			//draw = &CLETTER::num7;
			Draw.push_back(&CLETTER::num7);
		}
		if (name[i] == '8') {
			//draw = &CLETTER::num8;
			Draw.push_back(&CLETTER::num8);
		}
		if (name[i] == '9') {
			//draw = &CLETTER::num9;
			Draw.push_back(&CLETTER::num9);
		}
		if (name[i] == ':') {
			//draw = &CLETTER::colon;
			Draw.push_back(&CLETTER::colon);
			this->width = 3;
		}
		if (name[i] == '.') {
			//draw = &CLETTER::fullstop;
			Draw.push_back(&CLETTER::fullstop);
			this->width = 3;
		}
		if (name[i] == '-') {
			//draw = &CLETTER::dash;
			Draw.push_back(&CLETTER::dash);
			this->width = 3;
		}

		if (name[i] >= 'A' && name[i] <= 'Z' || name[i] >= '0' && name[i] <= '9' || name[i] == ':' || name[i] == '.' || name[i] == ' ' || name[i] == '-') {
			posX.push_back(posXTemp);
			posXTemp += this->width + 1;

			//Draw.push_back(draw);

			this->width = 7;
		}

	}

	if (posX.size() > 0) {
		this->widthWord = posX[posX.size() - 1] - posX[0];
	}

}

void CLETTER::setLetter(char name, int x, int y, int color, int colorbg)
{
	this->width = 7;
	this->color.clear();

	if (name == 'A') {
		draw = &CLETTER::A;
	}
	if (name == 'B') {
		draw = &CLETTER::B;
	}
	if (name == 'C') {
		draw = &CLETTER::C;
	}
	if (name == 'D') {
		draw = &CLETTER::D;
	}
	if (name == 'E') {
		draw = &CLETTER::E;
	}
	if (name == 'F') {
		draw = &CLETTER::F;
	}
	if (name == 'G') {
		draw = &CLETTER::G;
	}
	if (name == 'H') {
		draw = &CLETTER::H;
	}
	if (name == 'I' || name == '1') {
		draw = &CLETTER::I;
		this->width = 4;
	}
	if (name == 'J') {
		draw = &CLETTER::J;
	}
	if (name == 'K') {
		draw = &CLETTER::K;
	}
	if (name == 'L') {
		draw = &CLETTER::L;
	}
	if (name == 'M') {
		draw = &CLETTER::M;
		this->width = 9;
	}
	if (name == 'N') {
		draw = &CLETTER::N;
		this->width = 8;
	}
	if (name == 'O') {
		draw = &CLETTER::O;
	}
	if (name == 'P') {
		draw = &CLETTER::P;
	}
	if (name == 'Q') {
		draw = &CLETTER::Q;
		this->width = 8;
	}
	if (name == 'R') {
		draw = &CLETTER::R;
	}
	if (name == 'S') {
		draw = &CLETTER::S;
	}
	if (name == 'T') {
		draw = &CLETTER::T;
		this->width = 8;
	}
	if (name == 'U') {
		draw = &CLETTER::U;
	}
	if (name == 'V') {
		draw = &CLETTER::V;
	}
	if (name == 'W') {
		draw = &CLETTER::W;
		this->width = 9;
	}
	if (name == 'X') {
		draw = &CLETTER::X;
	}
	if (name == 'Y') {
		draw = &CLETTER::Y;
		this->width = 8;
	}
	if (name == 'Z') {
		draw = &CLETTER::Z;
	}
	if (name == ' ') {
		draw = &CLETTER::space;
	}
	if (name == '0') {
		draw = &CLETTER::num0;
	}
	if (name == '2') {
		draw = &CLETTER::num2;
	}
	if (name == '3') {
		draw = &CLETTER::num3;
	}
	if (name == '4') {
		draw = &CLETTER::num4;
	}
	if (name == '5') {
		draw = &CLETTER::num5;
	}
	if (name == '6') {
		draw = &CLETTER::num6;
	}
	if (name == '7') {
		draw = &CLETTER::num7;
	}
	if (name == '8') {
		draw = &CLETTER::num8;
	}
	if (name == '9') {
		draw = &CLETTER::num9;
	}
	if (name == ':') {
		draw = &CLETTER::colon;
		this->width = 3;
	}
	if (name == '.') {
		draw = &CLETTER::fullstop;
		this->width = 3;
	}
	if (name == '-') {
		draw = &CLETTER::dash;
		this->width = 3;
	}

	this->x = x;
	this->y = y;
	this->color.push_back(color);
	this->colorbg = colorbg;
	this->widthSpace = (this->width + 1) / 2;
}

void CLETTER::setLetter(string name, int x, int y, int color, int colorbg, int colorSpace)
{
	Draw.clear();
	posX.clear();
	posSpace.clear();
	this->color.clear();

	this->x = x;
	this->y = y;
	this->color.push_back(color);
	this->colorbg = colorbg;
	this->colorSpace = colorSpace;
	this->width = 7;

	int posXTemp = x;

	//void(CLETTER:: * draw)(int, int, int, int);

	for (int i = 0; i < name.length(); i++) {

		if (name[i] == 'A') {
			//draw = &CLETTER::A;
			Draw.push_back(&CLETTER::A);
		}
		if (name[i] == 'B') {
			//draw = &CLETTER::B;
			Draw.push_back(&CLETTER::B);
		}
		if (name[i] == 'C') {
			//draw = &CLETTER::C;
			Draw.push_back(&CLETTER::C);
		}
		if (name[i] == 'D') {
			//draw = &CLETTER::D;
			Draw.push_back(&CLETTER::D);
		}
		if (name[i] == 'E') {
			//draw = &CLETTER::E;
			Draw.push_back(&CLETTER::E);
		}
		if (name[i] == 'F') {
			//draw = &CLETTER::F;
			Draw.push_back(&CLETTER::F);
		}
		if (name[i] == 'G') {
			//draw = &CLETTER::G;
			Draw.push_back(&CLETTER::G);
		}
		if (name[i] == 'H') {
			//draw = &CLETTER::H;
			Draw.push_back(&CLETTER::H);
		}
		if (name[i] == 'I' || name[i] == '1') {
			//draw = &CLETTER::I;
			Draw.push_back(&CLETTER::I);
			this->width = 4;
		}
		if (name[i] == 'J') {
			//draw = &CLETTER::J;
			Draw.push_back(&CLETTER::J);
		}
		if (name[i] == 'K') {
			//draw = &CLETTER::K;
			Draw.push_back(&CLETTER::K);
		}
		if (name[i] == 'L') {
			//draw = &CLETTER::L;
			Draw.push_back(&CLETTER::L);
		}
		if (name[i] == 'M') {
			//draw = &CLETTER::M;
			Draw.push_back(&CLETTER::M);
			width = 9;
		}
		if (name[i] == 'N') {
			//draw = &CLETTER::N;
			Draw.push_back(&CLETTER::N);
			width = 8;
		}
		if (name[i] == 'O') {
			//draw = &CLETTER::O;
			Draw.push_back(&CLETTER::O);
		}
		if (name[i] == 'P') {
			//draw = &CLETTER::P;
			Draw.push_back(&CLETTER::P);
		}
		if (name[i] == 'Q') {
			//draw = &CLETTER::Q;
			Draw.push_back(&CLETTER::Q);
			this->width = 8;
		}
		if (name[i] == 'R') {
			//draw = &CLETTER::R;
			Draw.push_back(&CLETTER::R);
		}
		if (name[i] == 'S') {
			//draw = &CLETTER::S;
			Draw.push_back(&CLETTER::S);
		}
		if (name[i] == 'T') {
			//draw = &CLETTER::T;
			Draw.push_back(&CLETTER::T);
			width = 8;
		}
		if (name[i] == 'U') {
			//draw = &CLETTER::U;
			Draw.push_back(&CLETTER::U);
		}
		if (name[i] == 'V') {
			//draw = &CLETTER::V;
			Draw.push_back(&CLETTER::V);
		}
		if (name[i] == 'W') {
			//draw = &CLETTER::W;
			Draw.push_back(&CLETTER::W);
			this->width = 9;
		}
		if (name[i] == 'X') {
			//draw = &CLETTER::X;
			Draw.push_back(&CLETTER::X);
		}
		if (name[i] == 'Y') {
			//draw = &CLETTER::Y;
			Draw.push_back(&CLETTER::Y);
			this->width = 8;
		}
		if (name[i] == 'Z') {
			//draw = &CLETTER::Z;
			Draw.push_back(&CLETTER::Z);
		}
		if (name[i] == ' ') {
			posSpace.push_back(i);

			//draw = &CLETTER::space;
			Draw.push_back(&CLETTER::space);
			this->width = (this->width + 1) / 2;
		}
		if (name[i] == '0') {
			//draw = &CLETTER::num0;
			Draw.push_back(&CLETTER::num0);
		}
		if (name[i] == '2') {
			//draw = &CLETTER::num2;
			Draw.push_back(&CLETTER::num2);
		}
		if (name[i] == '3') {
			//draw = &CLETTER::num3;
			Draw.push_back(&CLETTER::num3);
		}
		if (name[i] == '4') {
			//draw = &CLETTER::num4;
			Draw.push_back(&CLETTER::num4);
		}
		if (name[i] == '5') {
			//draw = &CLETTER::num5;
			Draw.push_back(&CLETTER::num5);
		}
		if (name[i] == '6') {
			//draw = &CLETTER::num6;
			Draw.push_back(&CLETTER::num6);
		}
		if (name[i] == '7') {
			//draw = &CLETTER::num7;
			Draw.push_back(&CLETTER::num7);
		}
		if (name[i] == '8') {
			//draw = &CLETTER::num8;
			Draw.push_back(&CLETTER::num8);
		}
		if (name[i] == '9') {
			//draw = &CLETTER::num9;
			Draw.push_back(&CLETTER::num9);
		}
		if (name[i] == ':') {
			//draw = &CLETTER::colon;
			Draw.push_back(&CLETTER::colon);
			this->width = 3;
		}
		if (name[i] == '.') {
			//draw = &CLETTER::fullstop;
			Draw.push_back(&CLETTER::fullstop);
			this->width = 3;
		}
		if (name[i] == '-') {
			//draw = &CLETTER::dash;
			Draw.push_back(&CLETTER::dash);
			this->width = 3;
		}

		if (name[i] >= 'A' && name[i] <= 'Z' || name[i] >= '0' && name[i] <= '9' || name[i] == ':' || name[i] == '.' || name[i] == ' ' || name[i] == '-') {
			posX.push_back(posXTemp);
			posXTemp += this->width + 1;

			//Draw.push_back(draw);

			this->width = 7;
		}

	}

	if (posX.size() > 0) {
		this->widthWord = posX[posX.size() - 1] - posX[0];
	}

}

void CLETTER::drawLetter()
{
	(this->*draw)(x, y, color[0], colorbg);
}

void CLETTER::drawWord()
{
	if (Draw.size() == color.size()) {
		if (posSpace.size()) {
			for (int i = 0; i < Draw.size(); i++) {
				for (int j = 0; j < posSpace.size(); j++) {
					if (i == posSpace[j]) {
						(this->*Draw[i])(posX[i], y, colorSpace, 0);
					}
					else {
						(this->*Draw[i])(posX[i], y, color[i], colorbg);
					}
				}
			}
		}
		else {
			if (Draw.size() == posX.size()) {
				for (int i = 0; i < Draw.size(); i++) {
					(this->*Draw[i])(posX[i], y, color[i], colorbg);
				}
			}
		}

	}
	else {
		if (posSpace.size()) {
			for (int i = 0; i < Draw.size(); i++) {
				for (int j = 0; j < posSpace.size(); j++) {
					if (i == posSpace[j]) {
						(this->*Draw[i])(posX[i], y, colorSpace, 0);
					}
					else {
						//void(CLETTER:: * draw)(int, int, int, int) = CLETTER::Draw[i];
						(this->*Draw[i])(posX[i], y, color[0], colorbg);
					}
				}
			}
		}
		else {
			if (Draw.size() == posX.size()) {
				for (int i = 0; i < Draw.size(); i++) {
					(this->*Draw[i])(posX[i], y, color[0], colorbg);
				}
			}

		}
	}

	Draw.clear();

}

void CLETTER::A(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = b * 16 + b;
}

void CLETTER::B(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::C(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::D(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 4; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = (pColor[(fromY)*nScreenWidth + (fromX + 6)] / 16) * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 5; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + b;
}

void CLETTER::E(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::F(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::G(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::H(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = b * 16 + b;
}

void CLETTER::I(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::J(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] / 16) * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::K(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = b * 16 + b;
}

void CLETTER::L(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::M(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 7)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 8)] = c * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + b;
	for (int i = 5; i <= 8; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::N(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 7)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = b * 16 + b;
}

void CLETTER::O(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::P(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	for (int i = 3; i <= 6; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = c * 16 + b;
	}

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = c * 16 + b;
	}
}

void CLETTER::Q(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::R(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = b * 16 + b;
}

void CLETTER::S(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::T(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 6; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 7)] = b * 16 + b;

	//row 2
	for (int i = 0; i <= 2; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	for (int i = 5; i <= 7; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = b * 16 + b;

	//row 4
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::U(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::V(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] / 16) * 16 + b;

	for (int i = 2; i <= 4; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + b;
}

void CLETTER::W(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 7)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 8)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + b;
	for (int i = 5; i <= 8; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::X(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + b;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = b * 16 + b;
}

void CLETTER::Y(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 7)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + b;

	//row 4
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::Z(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::space(int fromX, int fromY, int c, int width)
{
	int nScreenWidth = NSCREENWIDTH;

	this->width = width;

	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			pBuffer[(fromY + i) * nScreenWidth + (fromX + j)] = L'█';
			pColor[(fromY + i) * nScreenWidth + (fromX + j)] = c * 16 + c;
		}
	}
}

void CLETTER::num0(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num2(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num3(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num4(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 3; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num5(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num6(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num7(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;
	pBuffer[(fromY + 21) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 3; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num8(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::num9(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 6; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::colon(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = c * 16 + b;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::fullstop(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 2
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + i)] / 16) * 16 + b;

	}

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = b * 16 + b;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = b * 16 + b;

	//row 4
	for (int i = 0; i <= 3; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

void CLETTER::dash(int fromX, int fromY, int c, int b)
{
	int nScreenWidth = NSCREENWIDTH;

	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = b * 16 + b;
	for (int i = 1; i <= 4; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = c * 16 + b;
	}
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = b * 16 + b;

	for (int i = 0; i <= 5; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = b * 16 + b;
	}
}

CLETTER::~CLETTER()
{
	Draw.clear();
	posX.clear();
	posSpace.clear();
	color.clear();
}

int CLETTER::getWidthWord()
{
	return widthWord;
}


