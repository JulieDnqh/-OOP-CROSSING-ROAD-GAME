#pragma once
#include "CGRAPHIC.h"

class CLETTER
{

	void(CLETTER::* draw)(int, int, int, int);//mot chu cai
	vector<void(CLETTER::*) (int, int, int, int)>Draw;//chuoi

	vector<int> posX;
	vector<int> posSpace;

	int width;
	int widthSpace;
	int widthWord;
	int height;
	int x;
	int y;
	vector<int> color;
	int colorbg;
	int colorSpace;
public:
	CLETTER();

	int getWidh();
	int getWidthWord();
	int getHeight();
	int getX();

	void setX(int x);

	void setLetter(string name, int x, int y, vector<int>& color, int colorbg = 0, int colorSpace = 10);
	void setLetter(char name, int x, int y, int color = 1, int colorbg = 0);
	void setLetter(string name, int x, int y, int color = 1, int colorbg = 0, int colorSpace = 10);

	void drawLetter();
	void drawWord();

	//Alphabet
	void A(int fromX, int fromY, int c, int b);	//length = 7 pixels
	void B(int fromX, int fromY, int c, int b);	//length = 7 pixels
	void C(int fromX, int fromY, int c, int b);	//length = 7 pixels
	void D(int fromX, int fromY, int c, int b);	//length = 7 pixels
	void E(int fromX, int fromY, int c, int b);
	void F(int fromX, int fromY, int c, int b);
	void G(int fromX, int fromY, int c, int b);
	void H(int fromX, int fromY, int c, int b);
	void I(int fromX, int fromY, int c, int b);	//length = 4 pixels
	void J(int fromX, int fromY, int c, int b);
	void K(int fromX, int fromY, int c, int b);
	void L(int fromX, int fromY, int c, int b);
	void M(int fromX, int fromY, int c, int b); //length = 9 pixels
	void N(int fromX, int fromY, int c, int b); //length = 8 pixels
	void O(int fromX, int fromY, int c, int b);
	void P(int fromX, int fromY, int c, int b);
	void Q(int fromX, int fromY, int c, int b);	//length = 8 pixels
	void R(int fromX, int fromY, int c, int b);
	void S(int fromX, int fromY, int c, int b);
	void T(int fromX, int fromY, int c, int b);	//length = 8 pixels
	void U(int fromX, int fromY, int c, int b);
	void V(int fromX, int fromY, int c, int b);
	void W(int fromX, int fromY, int c, int b);	//length = 9 pixels
	void X(int fromX, int fromY, int c, int b);
	void Y(int fromX, int fromY, int c, int b);	//length = 8 pixels
	void Z(int fromX, int fromY, int c, int b);

	//draw space
	void space(int fromX, int fromY, int c, int width = 0);

	//Numbers
	void num0(int fromX, int fromY, int c, int b);
	void num2(int fromX, int fromY, int c, int b);
	void num3(int fromX, int fromY, int c, int b);
	void num4(int fromX, int fromY, int c, int b);
	void num5(int fromX, int fromY, int c, int b);
	void num6(int fromX, int fromY, int c, int b);
	void num7(int fromX, int fromY, int c, int b);
	void num8(int fromX, int fromY, int c, int b);
	void num9(int fromX, int fromY, int c, int b);

	//hai cham
	void colon(int fromX, int fromY, int c, int b);

	//dau cham
	void fullstop(int fromX, int fromY, int c, int b);

	//gach ngang
	void dash(int fromX, int fromY, int c, int b);

	~CLETTER();
};

