﻿#include "CMENU.h"
#include "CGAME.h"
#pragma comment(lib, "Winmm.lib")

void CMENU::setGame(CGAME* g)
{
	game = g;
}

CMENU::CMENU()
{
	isGameRun = false;
	isExit = false;
	curNSelect = 0;
	selectBoard = NULL;
	bgMusic = true;
	sound = true;
	bgroundMotion = true;
	ifstream f;
	game = NULL;
	f.open("fileNames.txt", ios::beg);
	fileDataList.resize(0);
	char c = f.get();
	while (c != EOF)
	{
		FileData* curFile = new FileData;
		getline(f, curFile->fileName);
		if (fileDataList.size() == 0 && c != '\n' && c != ' ')
			curFile->fileName = c + curFile->fileName;
		f >> curFile->mode;
		f >> curFile->numOfPlayers;
		f >> curFile->level;

		if (curFile->fileName.length() > 4) {
			for (int j = 0; j < 4; j++) {
				curFile->fileName.pop_back();
			}
		}

		fileDataList.push_back(curFile);
		c = f.get();
	}

	f.close();
	if (fileDataList.size() > 0)
	{
		if (fileDataList[fileDataList.size() - 1]->numOfPlayers != 0 && fileDataList[fileDataList.size() - 1]->numOfPlayers != 1)
			fileDataList.erase(fileDataList.begin() + fileDataList.size() - 1);
	}

	//load du lieu rank
	int size{};
	ifstream fIn{};
	fIn.open("fileRank.txt", ios::beg);
	if (fIn) {
		fIn >> size;
		rankDataList.resize(size);
		fIn.ignore();
		for (int i = 0; i < size; i++) {
			getline(fIn, rankDataList[i].name);
			//fIn >> rankDataList[i].name;
		}
		for (int i = 0; i < size; i++) {
			fIn >> rankDataList[i].score;
		}
		for (int i = 0; i < size; i++) {
			fIn >> rankDataList[i].kindCharacter;
		}
	}
	
	fIn.close();
}
CMENU::CMENU(CGAME* g):CMENU()
{
	game = g;

}
void CMENU::control()
{
	int userChoice = -1, mode = -1, chooseNumOfPlayers = -1, fileIndex = -1;
	pair<int, bool> chooseMainChar;
	chooseMainChar.first = -1;
	chooseMainChar.second = false;
	int preMode = 0, preNumOfPlayers = preMode, preFileIndex;
	pair<int, bool> preChooseMainChar;
	preChooseMainChar.first = 0;
	preChooseMainChar.second = false;
	bool restart = 0;
	int option = 0;

	if (bgMusic)
		PlaySound(L"main_music.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
	thread bgMotion(&CMENU::backgroundMotion, this);
	while (1)
	{
		menuBackground(option);
		setDrawSelectBoard(NULL);
		FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
		if (userChoice == -1)
			userChoice = menu(option);

		if (userChoice == 0)
		{
			newGame(userChoice, mode, preMode, chooseNumOfPlayers, preNumOfPlayers, chooseMainChar, preChooseMainChar, fileIndex, preFileIndex);
			option = 0;
			chooseMainChar.first = -1;
		}
		else if (userChoice == 1)
		{
			loadGame(userChoice, mode, chooseNumOfPlayers);
			option = 1;
			
		}
		else if (userChoice == 2)
		{
			rankPage();
			userChoice = -1;
			option = 2;
		}
		else if (userChoice == 3)
		{
			drawSky(0, 23);
			helpPage();
			userChoice = -1;
			option = 3;
		}
		else if (userChoice == 4)
		{
			drawSky(0, 23);
			aboutPage();
			userChoice = -1;
			option = 4;
		}
		else if (userChoice == 5)
		{
			drawSky(0, 23);
			settingPage();
			userChoice = -1;
			option = 5;
		}
		else if (userChoice == 6)
		{
			setDrawSelectBoard(&CMENU::drawConfirmExit);
			int Exit = confirmExit();
			if (Exit == 0)
			{
				if (sound)
				{
					playSound(7);
					Sleep(2000);
				}
				isExit = true;
				bgMotion.join();
				game->reset();
				graphic->showCur(1);
				graphic->showScrollbar(1);
				return;
			}
			userChoice = -1;
			mode = -1;
			chooseNumOfPlayers = -1;
			fileIndex = -1;
			option = 6;
		}
	}
	bgMotion.join();
	game->reset();
}


void CMENU::setDrawSelectBoard(void(CMENU::* selectBoard)(int nSelect))
{
	this->selectBoard = selectBoard;
}
void CMENU::drawSelectBoard(int nSelect)
{
	(this->*selectBoard)(nSelect);
}


void CMENU::menuBackground(int selected, int switchMenu)
{
	drawSky(0, 23);

	drawStar(132, 18);
	drawStar(75, 1);

	drawGrassLane(24);
	drawRoadLane(32);

	drawWaterLane(40);

	drawGrassLane(48);
	drawGrassLane(56);


	int c0 = 8;
	int c1 = c0;
	int c2 = c0;
	int c3 = c0;
	int c4 = c0;
	int c5 = c0;
	int c6 = c0;
	switch (selected)
	{
	case 0:
	{
		c0 = 7;
		break;
	}
	case 1:
	{
		c1 = 7;
		break;
	}
	case 2:
	{
		c2 = 7;
		break;
	}
	case 3:
	{
		c3 = 7;
		break;
	}
	case 4:
	{
		c4 = 7;
		break;
	}
	case 5:
	{
		c5 = 7;
		break;
	}
	case 6: {
		c6 = 7;
		break;
	}

	}
	drawPlayButton(18, 51, c0);
	drawLoadGameButton(48, 51, c1);
	drawRankButton(78, 51, c2);
	drawHelpButton(108, 51, c3);
	drawAboutButton(138, 51, c4);
	drawSettingButton(168, 51, c5);
	drawExitButton(198, 51, c6);
}
void CMENU::backgroundMotion()
{
	int x0 = 50, x1 = 100, x2 = 160, x3 = 210, x4 = 30, x5 = 100, x6 = 160, x7 = 220, x8 = 15, x9 = 75, x10 = 140, x11 = 160, x12 = 210, x13 = 230;
	int y0 = 34, y1 = 41, y2 = 2, y3 = 12;
	vector<int> color = { 4,13,7,5,8,10,4,13 };
	vector<int> color1 = { 13, 7, 5, 8 };
	CLETTER word;
	word.setLetter("CROSSING", 85, 5, color, 0);
	word.drawWord();
	while (1)
	{
		if (isExit == true)
			return;
		if (isGameRun == true)
			continue;
		drawCloud(x8, y2);
		drawCloud(x9, y3);
		drawCloud(x10, y2);
		drawCloud(x11, y3);
		drawRoadLane(32);
		drawWaterLane(40);

		if (bgroundMotion == true)
		{
			x0 -= 3; x1 -= 3; x2 -= 3; x3 -= 3;
			x4 += 3; x5 += 3; x6 += 3; x7 += 3;
			x8 -= 1; x9 -= 1; x10 -= 1; x11 -= 1; x12 -= 1; x13 -= 1;
		}
		drawSky(0, 23);

		if (x8 + 23 >= 0)
		{
			drawCloud(x8, y2);
		}
		else
		{
			x8 = NSCREENWIDTH;
			drawCloud(x8, y2);
		}

		if (x9 + 23 >= 0)
		{
			drawCloud(x9, y3);
		}
		else
		{
			x9 = NSCREENWIDTH;
			drawCloud(x9, y3);
		}

		if (x10 + 23 >= 0)
		{
			drawCloud(x10, y2);
		}
		else
		{
			x10 = NSCREENWIDTH;
			drawCloud(x10, y2);
		}

		if (x11 + 23 >= 0)
		{
			drawCloud(x11, y3);
		}
		else
		{
			x11 = NSCREENWIDTH;
			drawCloud(x11, y3);
		}

		if (x12 + 23 >= 0)
		{
			drawCloud(x12, y2);
		}
		else
		{
			x12 = NSCREENWIDTH;
			drawCloud(x12, y2);
		}

		if (x13 + 23 >= 0)
		{
			drawCloud(x13, y3);
		}
		else
		{
			x13 = NSCREENWIDTH;
			drawCloud(x13, y3);
		}

		drawTitleFrame(80, 3, 71, 9, 1);
		word.setLetter("CROSSING", 85, 5, color, 0);
		word.drawWord();

		drawTitleFrame(95, 13, 41, 9, 1);
		word.setLetter("ROAD", 100, 15, color1, 0);
		word.drawWord();
		drawStar(132, 18);
		drawStar(75, 1);

		if (x0 + 20 >= 0)
		{
			drawRegCarLeft(x0, y0, 4);
		}
		else
		{
			x0 = NSCREENWIDTH;
			drawRegCarLeft(x0, y0, 4);
		}
		if (x1 + 20 >= 0)
		{
			drawTruckLeft(x1, y0 - 1, 13, 8);
		}
		else
		{
			x1 = NSCREENWIDTH;
			drawTruckLeft(x1, y0 - 1, 13, 8);
		}
		if (x2 + 20 >= 0)
		{
			drawMarioLeft(x2 + 10, y0 - 1);
			drawRoadsterLeft(x2, y0, 5);
		}
		else
		{
			x2 = NSCREENWIDTH;
			drawRoadsterLeft(x2, y0, 5);
		}
		if (x3 + 20 >= 0)
		{
			drawPoliceLeft(x3, y0);
		}
		else
		{
			x3 = NSCREENWIDTH;
			drawPoliceLeft(x3, y0);
		}
		if (x4 < NSCREENWIDTH)
		{
			drawLiliPad(x4, y1);
			drawPikachuRight(x4 + 2, y1);
		}
		else
		{
			x4 = -12;

			drawLiliPad(x4, y1);

		}
		if (x5 < NSCREENWIDTH)
		{
			drawLiliPad(x5, y1);
			drawKirbyRight(x5 + 2, y1);
		}
		else
		{
			x5 = -12;
			drawLiliPad(x5, y1);

		}
		if (x6 < NSCREENWIDTH)
		{
			drawLiliPad(x6, y1);
		}
		else
		{
			x6 = -12;
			drawLiliPad(x6, y1);
		}
		if (x7 < NSCREENWIDTH)
		{
			drawLiliPad(x7, y1);
		}
		else
		{
			x7 = -12;
			drawLiliPad(x7, y1);
		}
		if (selectBoard != NULL)
		{
			drawSelectBoard(curNSelect);
		}
		graphic->display();
		Sleep(100);
	}

}
void CMENU::menuSelectBoard(int nSelect)
{
	int c0 = 8, c1 = c0, c2 = c0, c3 = c0, c4 = c0, c5 = c0, c6 = c0;
	if (nSelect == 0)
		c0 = 7;
	else if (nSelect == 1)
		c1 = 7;
	else if (nSelect == 2)
		c2 = 7;
	else if (nSelect == 3)
		c3 = 7;
	else if (nSelect == 4)
		c4 = 7;
	else if (nSelect == 5)
		c5 = 7;
	else if (nSelect == 6)
		c6 = 7;
	drawPlayButton(18, 51, c0);
	drawLoadGameButton(48, 51, c1);
	drawRankButton(78, 51, c2);
	drawHelpButton(108, 51, c3);
	drawAboutButton(138, 51, c4);
	drawSettingButton(168, 51, c5);
	drawExitButton(198, 51, c6);
}
int CMENU::menu(int firstOption)
{
	int nSelect = firstOption;
	curNSelect = nSelect;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'D' || move == 77)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 6)
				nSelect = 0;
		}
		if (move == 'A' || move == 75)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 6;
		}
		curNSelect = nSelect;
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return nSelect;
		}


		menuSelectBoard(nSelect);
		// Hiển thị
		graphic->display();
	}
}


int CMENU::selectMode(int firstOption)
{
	selectModeBoard(firstOption);
	graphic->display();
	int nSelect = firstOption;
	curNSelect = nSelect;
	setDrawSelectBoard(&CMENU::selectModeBoard);
	thread clickSound;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 2)
				nSelect = 0;
		}
		if (move == 'W' || move == 72)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 2;
		}
		curNSelect = nSelect;
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return nSelect;
		}
	}
}
void CMENU::selectModeBoard(int nSelect)
{
	int c0 = 8, c1 = c0, c2 = c0;
	if (nSelect == 0)
		c0 = 6;
	else if (nSelect == 1)
		c1 = 6;
	else if (nSelect == 2)
		c2 = 6;
	int width = 66, height = 9;
	int fromX = NSCREENWIDTH / 2 - 33, fromY = NSCREENHEIGHT / 2 - 9;

	drawTitleFrame(fromX, fromY, 66, 9, c0);
	CLETTER word;
	word.setLetter("CLASSIC", NSCREENWIDTH / 2 - 26, fromY + 2, 1, 0);
	word.drawWord();

	drawTitleFrame(fromX, fromY + 11, 66, 9, c1);
	word.setLetter("ENDLESS", NSCREENWIDTH / 2 - 27, fromY + 13, 1, 0);
	word.drawWord();

	drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 22, 41, 9, c2);
	word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 24, 1, 0);
	word.drawWord();
}
int CMENU::selectNumOfPlayers(int firstOption)
{
	selectNumPlayerBoard(firstOption);
	graphic->display();
	setDrawSelectBoard(&CMENU::selectNumPlayerBoard);
	int nSelect = firstOption;
	curNSelect = nSelect;
	thread clickSound;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 2)
				nSelect = 0;
		}
		if (move == 'W' || move == 72)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 2;
		}
		curNSelect = nSelect;
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return nSelect;
		}
	}
}
void CMENU::selectNumPlayerBoard(int nSelect)
{
	int c0 = 8, c1 = c0, c2 = c0;
	if (nSelect == 0)
		c0 = 6;
	else if (nSelect == 1)
		c1 = 6;
	else if (nSelect == 2)
		c2 = 6;
	int width = 66, height = 9;
	int fromX = NSCREENWIDTH / 2 - 38, fromY = NSCREENHEIGHT / 2 - 9;

	drawTitleFrame(fromX, fromY, 76, 9, c0);
	CLETTER word;
	word.setLetter("1 PLAYER", NSCREENWIDTH / 2 - 29, fromY + 2, 1, 0);
	word.drawWord();

	drawTitleFrame(fromX, fromY + 11, 76, 9, c1);
	word.setLetter("2 PLAYERS", NSCREENWIDTH / 2 - 34, fromY + 13, 1, 0);
	word.drawWord();

	drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 22, 41, 9, c2);
	word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 24, 1, 0);
	word.drawWord();
}
pair<int, bool>CMENU::selectMainChar(int firstSelect)
{
	menuBackground(0);
	int nSelect = firstSelect;
	curNSelect = nSelect;
	setDrawSelectBoard(&CMENU::selectMainBoard1);
	bool switches = false;

	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'S' || move == 80)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			switches = false;
			nSelect++;
			if (nSelect > 3)
				nSelect = 0;
		}
		if (move == 'W' || move == 72)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			switches = false;
			nSelect--;
			if (nSelect < 0)
				nSelect = 3;
		}
		curNSelect = nSelect;
		//tab de switch nhan vat
		if (move == 9 && game->getNumOfPlayers() == 2 && nSelect != 3) {
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			if (switches) {
				switches = false;
			}
			else {
				switches = true;
			}
		}
		if (switches == true)
			setDrawSelectBoard(&CMENU::selectMainBoard2);
		else setDrawSelectBoard(&CMENU::selectMainBoard1);

		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return { nSelect,switches };
		}
	}
}
void CMENU::drawMainCharPic(int selectMain, int fromX, int fromY)
{
	if (selectMain == 1) {
		drawPikachuRight(fromX, fromY);
	}
	else if (selectMain == 2) {
		drawKirbyRight(fromX, fromY);
	}
	else if (selectMain == 3) {
		drawMarioRight(fromX, fromY);
	}
}
void CMENU::selectMainBoard1(int nSelect)
{
	drawSky(0, 23);
	drawGrassLane(24);
	int fromX = NSCREENWIDTH / 2 - 38, fromY = NSCREENHEIGHT / 2 - 20;

	drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
	CLETTER word;
	word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
	word.drawWord();
	switch (nSelect)
	{
	case 0:
	{

		if (game->getNumOfPlayers() == 1) {
			drawTitleFrame(NSCREENWIDTH / 2 - 28 - 5, fromY, 2 * (28 + 5) - 3, 9, 13);
			word.setLetter("PIKACHU", NSCREENWIDTH / 2 - 28, fromY + 2, 1, 0);
			word.drawWord();
			drawTitleFrame(NSCREENWIDTH / 2 - 28 - 5 + 2 * (28 + 5) - 3 + 2, fromY, 20, 9, 13);
			drawMainCharPic(1, NSCREENWIDTH / 2 - 28 - 5 + 2 * (28 + 5) - 3 + 2 + 6, fromY + 2);

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 11, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("KIRBY", NSCREENWIDTH / 2 - 20, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 22, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("MARIO", NSCREENWIDTH / 2 - 20, fromY + 24, 1, 0);
			word.drawWord();

		}
		else {
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 13);
			word.setLetter("KIRBY VS PIKACHU", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
			word.drawWord();
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 - 20 - 2, fromY, 20, 9, 13);
			drawMainCharPic(2, NSCREENWIDTH / 2 - 60 - 5 - 20 - 2 + 6, fromY + 2);
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2, fromY, 20, 9, 13);
			drawMainCharPic(1, NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2 + 6, fromY + 2);

			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 8);
			word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
			word.drawWord();

		}

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	case 1:
	{

		if (game->getNumOfPlayers() == 1) {
			drawTitleFrame(NSCREENWIDTH / 2 - 28 - 5, fromY, 2 * (28 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU", NSCREENWIDTH / 2 - 28, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 11, 2 * (20 + 5) - 3, 9, 13);
			word.setLetter("KIRBY", NSCREENWIDTH / 2 - 20, fromY + 13, 1, 0);
			word.drawWord();
			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5 + 2 * (20 + 5) - 3 + 2, fromY + 11, 20, 9, 13);
			drawMainCharPic(2, NSCREENWIDTH / 2 - 20 - 5 + 2 * (20 + 5) - 3 + 2 + 6, fromY + 11 + 2);

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 22, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("MARIO", NSCREENWIDTH / 2 - 20, fromY + 24, 1, 0);
			word.drawWord();

		}
		else {
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 13);
			word.setLetter("MARIO VS PIKACHU", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
			word.drawWord();
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 - 20 - 2, fromY + 11, 20, 9, 13);
			drawMainCharPic(3, NSCREENWIDTH / 2 - 60 - 5 - 20 - 2 + 6, fromY + 11 + 2);
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2, fromY + 11, 20, 9, 13);
			drawMainCharPic(1, NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2 + 6, fromY + 11 + 2);

			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 8);
			word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
			word.drawWord();
		}

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	case 2:
	{

		if (game->getNumOfPlayers() == 1) {
			drawTitleFrame(NSCREENWIDTH / 2 - 28 - 5, fromY, 2 * (28 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU", NSCREENWIDTH / 2 - 28, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 11, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("KIRBY", NSCREENWIDTH / 2 - 20, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 22, 2 * (20 + 5) - 3, 9, 13);
			word.setLetter("MARIO", NSCREENWIDTH / 2 - 20, fromY + 24, 1, 0);
			word.drawWord();
			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5 + 2 * (20 + 5) - 3 + 2, fromY + 22, 20, 9, 13);
			drawMainCharPic(3, NSCREENWIDTH / 2 - 20 - 5 + 2 * (20 + 5) - 3 + 2 + 6, fromY + 22 + 2);

		}
		else {
			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 13);
			word.setLetter("MARIO VS KIRBY", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
			word.drawWord();
			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5 - 20 - 2, fromY + 22, 20, 9, 13);
			drawMainCharPic(3, NSCREENWIDTH / 2 - 52 - 5 - 20 - 2 + 6, fromY + 22 + 2);
			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5 + 2 * (52 + 5) - 3 + 2, fromY + 22, 20, 9, 13);
			drawMainCharPic(1, NSCREENWIDTH / 2 - 52 - 5 + 2 * (52 + 5) - 3 + 2 + 6, fromY + 22 + 2);

			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
			word.drawWord();
		}

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	case 3:
	{
		if (game->getNumOfPlayers() == 1) {
			drawTitleFrame(NSCREENWIDTH / 2 - 28 - 5, fromY, 2 * (28 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU", NSCREENWIDTH / 2 - 28, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 11, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("KIRBY", NSCREENWIDTH / 2 - 20, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 22, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("MARIO", NSCREENWIDTH / 2 - 20, fromY + 24, 1, 0);
			word.drawWord();

		}
		else {
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 8);
			word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
			word.drawWord();
		}

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 13);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	}
}
void CMENU::selectMainBoard2(int nSelect)
{
	drawSky(0, 23);
	drawGrassLane(24);
	int fromX = NSCREENWIDTH / 2 - 38, fromY = NSCREENHEIGHT / 2 - 20;


	drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
	CLETTER word;
	word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
	word.drawWord();
	switch (nSelect)
	{
	case 0:
	{
		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 13);
		word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
		word.drawWord();
		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 - 20 - 2, fromY, 20, 9, 13);
		drawMainCharPic(1, NSCREENWIDTH / 2 - 60 - 5 - 20 - 2 + 6, fromY + 2);
		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2, fromY, 20, 9, 13);
		drawMainCharPic(2, NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2 + 6, fromY + 2);

		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 8);
		word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
		word.drawWord();

		drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 8);
		word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
		word.drawWord();

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	case 1:
	{

		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 13);
		word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
		word.drawWord();
		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 - 20 - 2, fromY + 11, 20, 9, 13);
		drawMainCharPic(1, NSCREENWIDTH / 2 - 60 - 5 - 20 - 2 + 6, fromY + 11 + 2);
		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2, fromY + 11, 20, 9, 13);
		drawMainCharPic(3, NSCREENWIDTH / 2 - 60 - 5 + 2 * (60 + 5) - 3 + 2 + 6, fromY + 11 + 2);

		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 8);
		word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
		word.drawWord();

		drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 8);
		word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
		word.drawWord();

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	case 2:
	{
		drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 13);
		word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
		word.drawWord();
		drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5 - 20 - 2, fromY + 22, 20, 9, 13);
		drawMainCharPic(2, NSCREENWIDTH / 2 - 52 - 5 - 20 - 2 + 6, fromY + 22 + 2);
		drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5 + 2 * (52 + 5) - 3 + 2, fromY + 22, 20, 9, 13);
		drawMainCharPic(3, NSCREENWIDTH / 2 - 52 - 5 + 2 * (52 + 5) - 3 + 2 + 6, fromY + 22 + 2);

		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 8);
		word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
		word.drawWord();

		drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 8);
		word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
		word.drawWord();

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 8);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	case 3:
	{
		if (game->getNumOfPlayers() == 1) {
			drawTitleFrame(NSCREENWIDTH / 2 - 28 - 5, fromY, 2 * (28 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU", NSCREENWIDTH / 2 - 28, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 11, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("KIRBY", NSCREENWIDTH / 2 - 20, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 20 - 5, fromY + 22, 2 * (20 + 5) - 3, 9, 8);
			word.setLetter("MARIO", NSCREENWIDTH / 2 - 20, fromY + 24, 1, 0);
			word.drawWord();

		}
		else {
			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS KIRBY", NSCREENWIDTH / 2 - 60, fromY + 2, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 60 - 5, fromY + 11, 2 * (60 + 5) - 3, 9, 8);
			word.setLetter("PIKACHU VS MARIO", NSCREENWIDTH / 2 - 60, fromY + 13, 1, 0);
			word.drawWord();

			drawTitleFrame(NSCREENWIDTH / 2 - 52 - 5, fromY + 22, 2 * (52 + 5) - 3, 9, 8);
			word.setLetter("KIRBY VS MARIO", NSCREENWIDTH / 2 - 52, fromY + 24, 1, 0);
			word.drawWord();
		}

		drawTitleFrame(NSCREENWIDTH / 2 - 20, fromY + 33, 41, 9, 13);
		word.setLetter("BACK", NSCREENWIDTH / 2 - 15, fromY + 35, 1, 0);
		word.drawWord();
		break;
	}
	}
}
bool CMENU::enterName()
{
	setDrawSelectBoard(&CMENU::enterNameBoard);
	int nSelect = 0;
	curNSelect = nSelect;
	int maxNSelect = 2;
	if (game->getNumOfPlayers() == 1)
	{
		int maxNSelect = 2;
		thread clickSound;
		while (1)
		{
			int move{};
			if (nSelect == 0)
			{
				nSelect = enterNameForEach(0);
			}
			else
			{
				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				move = toupper(_getch());
				if (move == 77)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					if (nSelect != 0)
					{
						nSelect--;
						if (nSelect == 0)
							nSelect = maxNSelect;
					}
				}
				if (move == 75)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					if (nSelect == 1)
						nSelect = 2;
					else if (nSelect == 2)
						nSelect = 0;
				}

				if (move == 80)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					nSelect++;
					if (nSelect > maxNSelect)
						nSelect = 0;
				}
				if (move == 72)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					if (nSelect == 0)
						nSelect = 1;
					else if (nSelect == 1)
						nSelect = 0;
					else nSelect = 0;
				}
			}
			curNSelect = nSelect;
			if (move == 13 || move == 32)
			{

				if (nSelect == 1)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 0);
					}
					if (clickSound.joinable())
						clickSound.join();
					return 1;
				}
				else if (nSelect == 2)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 0);
					}
					if (clickSound.joinable())
						clickSound.join();
					return 0;
				}
				else
				{
					nSelect = 1;
					curNSelect = nSelect;
				}
			}
		}
		graphic->display();
	}
	else
	{
		int maxNSelect = 3;
		while (1)
		{
			thread clickSound;
			int move{};
			if (nSelect == 0 || nSelect == 1)
			{
				nSelect = enterNameForEach(nSelect);
			}
			else
			{
				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				move = toupper(_getch());

				if (move == 77)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					if (nSelect != 0 && nSelect != 1)
					{
						nSelect--;
						if (nSelect == 1)
							nSelect = maxNSelect;
					}
				}
				if (move == 75)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					if (nSelect == 2)
						nSelect = 3;
					else if (nSelect == 3)
						nSelect = 0;
				}

				if (move == 80)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					nSelect++;
					if (nSelect > maxNSelect)
						nSelect = 0;
				}
				if (move == 72)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 1);
					}
					if (nSelect == 0)
						nSelect = 2;
					else if (nSelect == 1)
						nSelect = 0;
					else nSelect = 0;
				}
			}
			curNSelect = nSelect;
			if (move == 13 || move == 32)
			{
				if (nSelect == 2)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 0);
					}
					if (clickSound.joinable())
						clickSound.join();
					return 1;
				}
				else if (nSelect == 3)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CMENU::playSound, this, 0);
					}
					if (clickSound.joinable())
						clickSound.join();
					return 0;
				}
				else
				{
					nSelect++;
				}
			}
			if (clickSound.joinable())
				clickSound.join();
		}
		graphic->display();

	}
	return 1;
}
int CMENU::enterNameForEach(int index)
{
	CLETTER letter{};
	int pos = game->getPlayerName(index).size();
	string name = game->getPlayerName(index);
	char ch{}; int x = 95, y;
	int i = game->getPlayerName(index).size() - 1;
	if (game->getNumOfPlayers() == 1)
	{
		y = 25;
	}
	else
	{
		if (index == 0)
			y = 18;
		else y = 31;
	}
	if (index == 1)
		y = 31;
	vector<CLETTER> Name;
	if (game->getPlayerName(index).size() > 0)
	{
		for (int i = 0; i < game->getPlayerName(index).size(); i++)
		{
			CLETTER l;
			l.setLetter(game->getPlayerName(index)[i], x, y);
			x += l.getWidh() + 1;
			Name.push_back(l);
		}
	}
	int color = 1;
	int colorbg = 0;
	//vien
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1) {

		graphic->gotoXY(x, y + 3);
		graphic->showCur(1);

		ch = _getch();

		//enter
		if (ch == 13) {
			if (sound)
				playSound(1);
			graphic->showCur(0);
			return index + 1;// name;
		}

		if (ch == 72)
		{

			if (index == 1)
			{
				if (sound)
					playSound(1);
				return 0;
			}
		}

		//right
		if (int(ch) == 77 && (pos < name.length())) {
			x += Name[pos].getWidh() + 1;
			graphic->gotoXY(x, y + 3);
			pos++;
		}

		//left
		if (int(ch) == 75 && (pos > 0)) {
			x -= Name[pos - 1].getWidh() + 1;
			graphic->gotoXY(x, y + 3);
			pos--;
		}

		//backspace - xoa trc do
		//delete - xoa sau do
		if (int(ch) == 8 && pos > 0) {

			x -= Name[pos - 1].getWidh() + 1;

			if (pos < name.length()) {

				graphic->clearScreen(15, 1, x, y, Name[Name.size() - 1].getX() + Name[Name.size() - 1].getWidh(), y + Name[pos - 1].getHeight());


				if (!name.empty() && !Name.empty()) {
					name.erase(pos - 1, 1);
					Name.erase(Name.begin() + pos - 1);
					game->setNameForPlayer(index, name);
				}

				int xTemp = x;
				for (int j = pos - 1; j < Name.size(); j++) {

					Name[j].setX(xTemp);
					Name[j].drawLetter();
					xTemp += Name[j].getWidh() + 1;
				}

			}
			else {
				graphic->clearScreen(15, 1, x, y, Name[Name.size() - 1].getX() + Name[Name.size() - 1].getWidh() + 1, y + Name[pos - 1].getWidh());

				if (!name.empty()) {
					name.erase(pos - 1, 1);
					game->setNameForPlayer(index, name);
				}
				if (Name.size() > 0) {
					Name.pop_back();
				}
			}

			i--;
			pos--;
			graphic->gotoXY(x, y + 3);
		}
		//space
		if (ch == 32 && i < 11) {

			if (Name.size() == 0)
			{
				letter.setLetter(ch, x, y, 10, 4);
			}
			else
			{
				letter.setLetter(ch, x, y, 10, (Name[Name.size() - 1].getWidh() + 1) / 2);
			}

			letter.drawLetter();

			name.push_back(ch);
			Name.push_back(letter);
			game->setNameForPlayer(index, game->getPlayerName(index) + ch);
			x += letter.getWidh() + 1;
			i++;
			pos++;
		}

		if ((ch >= 'a' && ch <= 'z' || ch >= '0' && ch <= '9') && (i < 11)) {
			ch = toupper(ch);


			if (pos == Name.size()) {
				letter.setLetter(ch, x, y, color, colorbg);

				name.push_back(ch);

				Name.push_back(letter);

				game->setNameForPlayer(index, game->getPlayerName(index) + ch);
			}
			else {
				letter.setLetter(ch, x, y, color, colorbg);

				string s(1, ch);
				name.insert(pos, s);

				Name.insert(Name.begin() + pos, letter);
				game->setNameForPlayer(index, name);
				graphic->clearScreen(15, 1, Name[pos].getX(), y, Name[Name.size() - 1].getX() + Name[Name.size() - 1].getWidh() + 1, y + Name[pos].getWidh());

				int xTemp = x + letter.getWidh() + 1;

				for (int j = pos + 1; j < Name.size(); j++) {
					Name[j].setX(xTemp);
					Name[j].drawLetter();
					xTemp += Name[j].getWidh() + 1;
				}
			}
			pos++;
			x += letter.getWidh() + 1;
			i++;
		}
		graphic->display();
	}
}
void CMENU::enterNameBoard(int nSelect)
{
	int firstX1 = 0, firstX2 = 0;
	int fromX = NSCREENWIDTH / 2 - 70, fromY = NSCREENHEIGHT / 2 - 25;
	drawTitleFrame(fromX, fromY, 140, 43, 15);

	vector<int> color = { 4,13,7,5,8,10,10,4,13,8 };
	CLETTER word;
	word.setLetter("ENTER NAME", NSCREENWIDTH / 2 - 33 - 8, 5, color, 0);
	word.drawWord();
	drawStar(71 - 8, 4);
	drawStar(158, 4);


	if (game->getNumOfPlayers() == 1)
	{
		word.setLetter("PLAYER", fromX + 41, fromY + 10, 1, 0);
		word.drawWord();
		word.setLetter("NAME: ", fromX + 6, fromY + 18, 1, 0);
		firstX1 = word.getWidthWord() + fromX + 10;
		word.drawWord();
		word.setLetter(game->getPlayerName(0), firstX1, fromY + 18, 8, 0);
		word.drawWord();
		firstX1 += word.getWidthWord();
	}


	if (game->getNumOfPlayers() == 2)
	{
		word.setLetter("PLAYER 1", fromX + 6, 13, 7, 0);
		word.drawWord();
		word.setLetter("NAME: ", fromX + 6, 18, 7, 0);

		firstX1 = word.getWidthWord() + fromX + 10;
		word.drawWord();
		word.setLetter(game->getPlayerName(0), firstX1, 18, 8, 0);
		word.drawWord();
		firstX1 += word.getWidthWord();

		word.setLetter("PLAYER 2", fromX + 6, 26, 7, 0);
		word.drawWord();
		word.setLetter("NAME: ", fromX + 6, 31, 7, 0);
		firstX2 = word.getWidthWord() + fromX + 10;
		word.drawWord();
		word.setLetter(game->getPlayerName(1), firstX2, 31, 8, 0);
		word.drawWord();
		firstX2 += word.getWidthWord();
	}

	word.setLetter("BACK", fromX + 16, 40, 1, 0);
	word.drawWord();
	word.setLetter("PLAY", fromX + 86, 40, 1, 0);
	word.drawWord();


	if (nSelect == 1)
	{
		if (game->getNumOfPlayers() != 2)
		{
			word.setLetter("PLAY", fromX + 86, 40, 7, 0);
			word.drawWord();
		}
	}
	else if (nSelect == 2)
	{
		if (game->getNumOfPlayers() == 2)
		{
			word.setLetter("PLAY", fromX + 86, 40, 7, 0);
			word.drawWord();
		}
		else
		{
			word.setLetter("BACK", fromX + 16, 40, 7, 0);
			word.drawWord();
		}
	}
	else if (nSelect == 3)
	{
		word.setLetter("BACK", fromX + 16, 40, 7, 0);
		word.drawWord();
	}
}
void CMENU::newGame(int& userChoice, int& mode, int& preMode, int& chooseNumOfPlayers, int& preNumOfPlayers, pair<int, bool>& selectMain, pair<int, bool>& preSelectMain, int& fileIndex, int& preFileIndex)
{
	if (mode == -1)
		mode = selectMode(preMode);
	if (mode != 2)
	{
		game->setMode(mode);
		if (chooseNumOfPlayers == -1)
			chooseNumOfPlayers = selectNumOfPlayers(preNumOfPlayers);
		if (chooseNumOfPlayers != 2)
		{
			game->setNumOfPlayers(chooseNumOfPlayers + 1);
			if (selectMain.first == -1)
			{
				selectMain = selectMainChar(preSelectMain.first);
			}
			if (selectMain.first != 3)
			{
				game->setMainChar(game->getNumOfPlayers(), selectMain.first + 1, selectMain.second);
				int play = enterName();
				if (play == 1)
				{
					isGameRun = true;
					selectBoard = NULL;
					bool restart = game->play();
					while (restart == true)
					{
						vector<string> nameTemp{};
						for (int i = 0; i < game->getNumOfPlayers(); i++) {
							nameTemp.push_back(game->getPlayerName(i));
						}
						game->reset();
						game->setMode(game->getMode());
						game->setNumOfPlayers(game->getNumOfPlayers());
						game->setMainChar(game->getNumOfPlayers(), selectMain.first + 1, selectMain.second);
						for (int i = 0; i < game->getNumOfPlayers(); i++) {
							game->setNameForPlayer(i, nameTemp[i]);
						}
						restart = game->play();
					}
					isGameRun = false;

					game->reset();
					userChoice = -1;
					mode = -1;
					chooseNumOfPlayers = -1;
					fileIndex = -1;
				}
				else
				{
					game->reset();
					preSelectMain.first = selectMain.first;
					selectMain.first = -1;
				}
			}
			else//back choose mainChar
			{
				game->reset();
				preNumOfPlayers = chooseNumOfPlayers;
				chooseNumOfPlayers = -1;
				selectMain.first = -1;
				preSelectMain.first = 0;
				preSelectMain.second = 0;
			}

		}
		else//back chooseNumOfPlayer
		{
			game->reset();
			preMode = mode;
			mode = -1;
			chooseNumOfPlayers = -1;
			preNumOfPlayers = 0;
		}

	}
	else//back mode
	{
		userChoice = -1;
		mode = -1;
		preMode = 0;
		preNumOfPlayers = 0;
	}
}


int CMENU::checkNameFile(string name, int index)
{
	if (name.size() <= 0)
		return -1;
	if (name[0] == ' ')
		return -1;
	for (int i = 0; i < fileDataList.size(); i++) {
		if (i!=index && name == fileDataList[i]->fileName) {
			return -2;
		}
	}
	return 0;
}
pair<int, int> CMENU::selectFileAndOption(int select, int indexFirstFile, int selectFile)
{

	int fromX = NSCREENWIDTH / 2 - 90, fromY = NSCREENHEIGHT / 2 - 25;

	if (fileDataList.size() > 0 && indexFirstFile >= 0 && indexFirstFile < fileDataList.size() && selectFile >= 0 && selectFile < fileDataList.size()) {

		this->indexFirstFile = indexFirstFile;
		int nSelectFile = selectFile;
		int nSelectButton = select;
		this->nSelectFile = nSelectFile;
		this->nSelectButton = nSelectButton;

		setDrawSelectBoard(&CMENU::selectBoardFile);
		selectBoardFile();

		graphic->display();

		int numOption{};
		thread clickSound;
		while (1) {

			if (indexFirstFile - 3 >= 0 && indexFirstFile + 3 < fileDataList.size()) {
				numOption = 5;
			}
			else if (indexFirstFile - 3 < 0 && indexFirstFile + 3 >= fileDataList.size()) {
				numOption = 3;
			}
			else {
				numOption = 4;
			}

			int move = toupper(_getch());

			if (move == 'S' || move == 80)
			{
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CMENU::playSound, this, 1);
				}
				nSelectFile++;
				this->nSelectFile = nSelectFile;
				if (nSelectFile > indexFirstFile + 2 || nSelectFile >= fileDataList.size()) {
					nSelectFile = indexFirstFile;
					this->nSelectFile = nSelectFile;
				}

			}
			if (move == 'W' || move == 72)
			{
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CMENU::playSound, this, 1);
				}
				nSelectFile--;
				this->nSelectFile = nSelectFile;
				if (nSelectFile < 0) {
					if (indexFirstFile + 2 >= fileDataList.size()) {
						nSelectFile = fileDataList.size() - 1;
						this->nSelectFile = nSelectFile;
					}
					else {
						nSelectFile = indexFirstFile + 2;
						this->nSelectFile = nSelectFile;
					}
				}
			}
			if (move == 'A' || move == 75) {
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CMENU::playSound, this, 1);
				}
				nSelectButton--;
				this->nSelectButton = nSelectButton;
				if (nSelectButton < 0) {
					nSelectButton = numOption;
					this->nSelectButton = nSelectButton;
				}
			}
			if (move == 'D' || move == 77) {
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CMENU::playSound, this, 1);
				}
				nSelectButton++;
				this->nSelectButton = nSelectButton;
				if (nSelectButton > numOption) {
					nSelectButton = 0;
					this->nSelectButton = nSelectButton;
				}
			}

			if (move == 13 || move == 32) {
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CMENU::playSound, this, 0);
				}
				if (nSelectButton == 0 && indexFirstFile == 0 || nSelectButton == 1 && indexFirstFile > 0 && indexFirstFile < fileDataList.size()) {
					if (clickSound.joinable())
						clickSound.join();
					return { -1,0 };
				}
				if (nSelectButton == 0 && indexFirstFile - 3 >= 0) {
					indexFirstFile -= 3;
					this->indexFirstFile = indexFirstFile;
					nSelectFile = indexFirstFile;
					this->nSelectFile = nSelectFile;
					if (indexFirstFile - 3 >= 0 && indexFirstFile + 3 < fileDataList.size()) {
						numOption = 5;
					}
					else if (indexFirstFile - 3 < 0 && indexFirstFile + 3 >= fileDataList.size()) {
						numOption = 3;
					}
					else {
						numOption = 4;
					}
					nSelectButton = numOption;
					this->nSelectButton = nSelectButton;
				}
				else if (nSelectButton == numOption && indexFirstFile + 3 < fileDataList.size()) {
					indexFirstFile += 3;
					this->indexFirstFile = indexFirstFile;
					nSelectFile = indexFirstFile;
					nSelectButton = 0;
					this->nSelectFile = nSelectFile;
					this->nSelectButton = nSelectButton;
				}
				else {
					if (indexFirstFile - 3 >= 0) {
						nSelectButton--;
						this->nSelectButton = nSelectButton;
					}
					if (nSelectFile >= 0 && nSelectFile < fileDataList.size()) {
						nSelectFile;
						nSelectButton;
						if (clickSound.joinable())
							clickSound.join();
						return { nSelectFile,nSelectButton };
					}
				}

			}

			setDrawSelectBoard(&CMENU::selectBoardFile);
			selectBoardFile();

			graphic->display();

		}
	}
	else {

		setDrawSelectBoard(&CMENU::drawBlankPage);
		drawBlankPage();
		graphic->display();
		thread clickSound;
		while (1) {
			int enter = _getch();


			if (enter == 13 || enter == 32) {
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CMENU::playSound, this, 0);
				}
				if (clickSound.joinable())
					clickSound.join();

				break;
			}
		}
	}

	return { -1,0 };
}
void CMENU::selectBoardFile(int nSelect)
{
	drawSky(0, 23);

	int fromX = NSCREENWIDTH / 2 - 90, fromY = NSCREENHEIGHT / 2 - 25;

	if (nSelectFile >= 0 && nSelectFile < fileDataList.size()) {
		//ve lai
		drawTitleFrame(fromX, fromY, 180, 50, 15);
		vector<int> color = { 4,13,7,5,8,10,4,13,8 };
		CLETTER word;
		word.setLetter("LOAD GAME", NSCREENWIDTH / 2 - 33, 5, color, 0);
		word.drawWord();

		drawStar(71, 4);
		drawStar(155, 4);

		int posYNum = 17;

		int i = indexFirstFile;
		for (; i < fileDataList.size(); i++) {
			if (i > indexFirstFile + 2) {
				break;
			}
			//set stt
			word.setLetter(to_string(i + 1), 36, posYNum, 1, 0);
			word.drawWord();

			//set ten
			string nameTemp{};
			for (int j = 0; j < fileDataList[i]->fileName.length(); j++) {
				if (j > 2) {
					nameTemp += "..";
					break;
				}
				if (fileDataList[i]->fileName[j] >= 'a' && fileDataList[i]->fileName[j] <= 'z' || fileDataList[i]->fileName[j] >= 'A' && fileDataList[i]->fileName[j] <= 'Z' || fileDataList[i]->fileName[j] >= '0' && fileDataList[i]->fileName[j] <= '9' || fileDataList[i]->fileName[j] == '.' || fileDataList[i]->fileName[j] == '-' || fileDataList[i]->fileName[j] == ' ') {
					nameTemp.push_back(toupper(fileDataList[i]->fileName[j]));
				}

			}
			word.setLetter(nameTemp, 66, posYNum, 1, 0);
			word.drawWord();//

			//set mode va so nguoi choi
			string modeAndNumP{};
			if (fileDataList[i]->mode == 0) {
				modeAndNumP += "C";
			}
			else {
				modeAndNumP += "E";
			}
			modeAndNumP += to_string(fileDataList[i]->numOfPlayers);
			word.setLetter(modeAndNumP, 111, posYNum, 1, 0);
			word.drawWord();

			//set level
			if (fileDataList[i]->mode == 0)
			{
				word.setLetter(to_string(fileDataList[i]->level + 1), 156, posYNum, 1, 0);
				word.drawWord();
			}
			else
			{
				word.setLetter("...", 156, posYNum, 1, 0);
				word.drawWord();

			}

			posYNum += 7;
		}

		//hien day du ten file
		int sizeName{};
		int numSpace{};
		string nameTemp{};
		for (int i = 0; i < fileDataList[nSelectFile]->fileName.length(); i++) {
			if (fileDataList[nSelectFile]->fileName[i] == ' ') {
				numSpace++;
			}
			nameTemp.push_back(toupper(fileDataList[nSelectFile]->fileName[i]));
		}
		sizeName = numSpace * 4 + (fileDataList[nSelectFile]->fileName.length() - numSpace) * 8;
		posYNum = 17 + (nSelectFile % 3) * 7;

		drawTitleFrame(66, posYNum - 1, sizeName + 9, 7, 6);
		word.setLetter(nameTemp, 66 + 5, posYNum, 1, 0);
		word.drawWord();

		word.setLetter("NO.", 36, 11, 10, 0);
		word.drawWord();
		word.setLetter("NAME", 66, 11, 13, 0);
		word.drawWord();
		word.setLetter("MODE", 111, 11, 5, 0);
		word.drawWord();
		word.setLetter("LEVEL", 156, 11, 8, 0);
		word.drawWord();
	}

	switch (nSelectButton)
	{
	case 0:
	{
		if (indexFirstFile - 3 >= 0) {
			drawHomeButton(72, 45, 8);
			drawBackButton(33, 45, 7);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}
		else {
			drawHomeButton(72, 45, 7);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}
		break;
	}
	case 1:
	{
		if (indexFirstFile - 3 >= 0) {
			drawHomeButton(72, 45, 7);
			drawBackButton(33, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}
		else {
			drawHomeButton(72, 45, 8);
			drawLoadGameButton(96, 45, 7);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}

		break;
	}
	case 2:
	{
		if (indexFirstFile - 3 >= 0) {
			drawHomeButton(72, 45, 8);
			drawBackButton(33, 45, 8);
			drawLoadGameButton(96, 45, 7);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}
		else {
			drawHomeButton(72, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 7);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}

		break;
	}
	case 3:
	{
		if (indexFirstFile - 3 >= 0) {
			drawHomeButton(72, 45, 8);
			drawBackButton(33, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 7);
			drawDeleteButton(143, 45, 8);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}
		else {
			drawHomeButton(72, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 7);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}

		break;
	}
	case 4:
	{
		if (indexFirstFile - 3 >= 0) {
			drawHomeButton(72, 45, 8);
			drawBackButton(33, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 7);
			if (indexFirstFile + 3 < fileDataList.size()) {
				drawPlayButton(184, 45, 8);
			}
		}
		else if (indexFirstFile + 3 < fileDataList.size()) {
			drawHomeButton(72, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			drawPlayButton(184, 45, 7);
		}

		break;
	}
	case 5:
	{
		if (indexFirstFile - 3 >= 0 && indexFirstFile + 3 < fileDataList.size()) {
			drawHomeButton(72, 45, 8);
			drawBackButton(33, 45, 8);
			drawLoadGameButton(96, 45, 8);
			drawRenameButton(119, 45, 8);
			drawDeleteButton(143, 45, 8);
			drawPlayButton(184, 45, 7);
		}
		break;
	}
	}
}
int CMENU::enterNameFile(int fromX, int fromY, int colorSpace, int fileIndex)
{
	CLETTER letter{};
	int pos = fileDataList[fileIndex]->fileName.size();
	string newfileName = fileDataList[fileIndex]->fileName;
	char ch{};
	int i = fileDataList[fileIndex]->fileName.size() - 1;
	CLETTER word;
	int x = 65 + fromX;
	int y = fromY + 8;
	vector<CLETTER> nfileName;
	if (fileDataList[fileIndex]->fileName.size() > 0)
	{
		for (int i = 0; i < fileDataList[fileIndex]->fileName.size(); i++)
		{
			CLETTER l;
			l.setLetter(fileDataList[fileIndex]->fileName[i], x, y);
			x += l.getWidh() + 1;
			nfileName.push_back(l);
		}
	}
	int color = 1;
	int colorbg = 0;
	//vien
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1) {

		graphic->gotoXY(x, y + 3);
		graphic->showCur(1);

		ch = _getch();

		//enter
		if (ch == 13) {
			if (sound)
				playSound(1);
			graphic->showCur(0);
			return -2;// name;
		}

		//right
		if (int(ch) == 77 && (pos < newfileName.length())) {
			x += nfileName[pos].getWidh() + 1;
			graphic->gotoXY(x, y + 3);
			pos++;
		}

		//left
		if (int(ch) == 75 && (pos > 0)) {
			x -= nfileName[pos - 1].getWidh() + 1;
			graphic->gotoXY(x, y + 3);
			pos--;
		}

		//backspace - xoa trc do
		//delete - xoa sau do
		if (int(ch) == 8 && pos > 0) {

			x -= nfileName[pos - 1].getWidh() + 1;

			if (pos < newfileName.length()) {

				graphic->clearScreen(15, 1, x, y, nfileName[nfileName.size() - 1].getX() + nfileName[nfileName.size() - 1].getWidh(), y + nfileName[pos - 1].getHeight());


				if (!newfileName.empty() && !nfileName.empty()) {
					newfileName.erase(pos - 1, 1);
					nfileName.erase(nfileName.begin() + pos - 1);
					//game->setNameForPlayer(index, name);
					fileDataList[fileIndex]->fileName = newfileName;
				}

				int xTemp = x;
				for (int j = pos - 1; j < nfileName.size(); j++) {

					nfileName[j].setX(xTemp);
					nfileName[j].drawLetter();
					xTemp += nfileName[j].getWidh() + 1;
				}

			}
			else {
				graphic->clearScreen(15, 1, x, y, nfileName[nfileName.size() - 1].getX() + nfileName[nfileName.size() - 1].getWidh() + 1, y + nfileName[pos - 1].getWidh());

				if (!newfileName.empty()) {
					newfileName.erase(pos - 1, 1);
					//game->setNameForPlayer(index, name);
					fileDataList[fileIndex]->fileName = newfileName;
				}
				if (nfileName.size() > 0) {
					nfileName.pop_back();
				}
			}

			i--;
			pos--;
			graphic->gotoXY(x, y + 3);
		}
		//space
		if (ch == 32 && i < 11) {

			if (nfileName.size() == 0)
			{
				letter.setLetter(ch, x, y, 10, 4);
			}
			else
			{
				letter.setLetter(ch, x, y, 10, (nfileName[nfileName.size() - 1].getWidh() + 1) / 2);
			}

			letter.drawLetter();

			newfileName.push_back(ch);
			nfileName.push_back(letter);
			fileDataList[fileIndex]->fileName += ch;
			x += letter.getWidh() + 1;
			i++;
			pos++;
		}

		if ((ch >= 'a' && ch <= 'z' || ch >= '0' && ch <= '9') && (i < 11)) {
			ch = toupper(ch);


			if (pos == nfileName.size()) {
				letter.setLetter(ch, x, y, color, colorbg);

				newfileName.push_back(ch);

				nfileName.push_back(letter);

				fileDataList[fileIndex]->fileName += ch;
			}
			else {
				letter.setLetter(ch, x, y, color, colorbg);

				string s(1, ch);
				newfileName.insert(pos, s);

				nfileName.insert(nfileName.begin() + pos, letter);
				fileDataList[fileIndex]->fileName = newfileName;
				graphic->clearScreen(15, 1, nfileName[pos].getX(), y, nfileName[nfileName.size() - 1].getX() + nfileName[nfileName.size() - 1].getWidh() + 1, y + nfileName[pos].getWidh());

				int xTemp = x + letter.getWidh() + 1;

				for (int j = pos + 1; j < nfileName.size(); j++) {
					nfileName[j].setX(xTemp);
					nfileName[j].drawLetter();
					xTemp += nfileName[j].getWidh() + 1;
				}
			}
			pos++;
			x += letter.getWidh() + 1;
			i++;
		}
		graphic->display();
	}
}
int CMENU::enterNameForNewFile(string& name, int fromX, int fromY)
{
	CLETTER letter{};
	int pos = name.size();
	char ch{};
	int i = name.size()-1;
	CLETTER word;
	int x = 65 + fromX;
	int y = fromY;
	vector<CLETTER> Name;
	if (name.size()> 0)
	{
		for (int i = 0; i < name.size(); i++)
		{
			CLETTER l;
			l.setLetter(name[i], x, y);
			l.drawLetter();
			x += l.getWidh() + 1;
			Name.push_back(l);
		}
	}
	graphic->display();
	
	int color = 1;
	int colorbg = 0;
	//vien
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1) {

		graphic->gotoXY(x, y + 3);
		graphic->showCur(1);

		ch = _getch();

		//enter
		if (ch == 13) {
			if (sound)
				playSound(1);
			graphic->showCur(0);
			return -2;// name;
		}

		//right
		if (int(ch) == 77 && (pos < name.length())) {
			x += Name[pos].getWidh() + 1;
			graphic->gotoXY(x, y + 3);
			pos++;
		}

		//left
		if (int(ch) == 75 && (pos > 0)) {
			x -= Name[pos - 1].getWidh() + 1;
			graphic->gotoXY(x, y + 3);
			pos--;
		}

		//backspace - xoa trc do
		//delete - xoa sau do
		if (int(ch) == 8 && pos > 0) {

			x -= Name[pos - 1].getWidh() + 1;

			if (pos < name.length()) {

				graphic->clearScreen(15, 1, x, y, Name[Name.size() - 1].getX() +Name[Name.size() - 1].getWidh(), y + Name[pos - 1].getHeight());


				if (!Name.empty() && !name.empty()) {
					name.erase(pos - 1, 1);
					Name.erase(Name.begin() + pos - 1);
					//game->setNameForPlayer(index, name);
					
				}

				int xTemp = x;
				for (int j = pos - 1; j < Name.size(); j++) {

					Name[j].setX(xTemp);
					Name[j].drawLetter();
					xTemp += Name[j].getWidh() + 1;
				}

			}
			else {
				graphic->clearScreen(15, 1, x, y, Name[Name.size() - 1].getX() + Name[Name.size() - 1].getWidh() + 1, y + Name[pos - 1].getWidh());

				if (!name.empty()) {
					name.erase(pos - 1, 1);
					//game->setNameForPlayer(index, name);
				}
				if (Name.size() > 0) {
					Name.pop_back();
				}
			}

			i--;
			pos--;
			graphic->gotoXY(x, y + 3);
		}
		//space
		if (ch == 32 && i < 11) {

			if (Name.size() == 0)
			{
				letter.setLetter(ch, x, y, 10, 4);
			}
			else
			{
				letter.setLetter(ch, x, y, 10, (Name[Name.size() - 1].getWidh() + 1) / 2);
			}

			letter.drawLetter();
			graphic->display();

			name.push_back(ch);
			Name.push_back(letter);
			x += letter.getWidh() + 1;
			i++;
			pos++;
		}

		if ((ch >= 'a' && ch <= 'z' || ch >= '0' && ch <= '9') && (i < 11)) {
			ch = toupper(ch);


			if (pos == Name.size()) {
				letter.setLetter(ch, x, y, color, colorbg);
				letter.drawLetter();
				name.push_back(ch);

				Name.push_back(letter);

			}
			else {
				letter.setLetter(ch, x, y, color, colorbg);

				string s(1, ch);
				name.insert(pos, s);

				Name.insert(Name.begin() + pos, letter);
				graphic->clearScreen(15, 1, Name[pos].getX(), y, Name[Name.size() - 1].getX() + Name[Name.size() - 1].getWidh() + 1, y + Name[pos].getWidh());

				int xTemp = x + letter.getWidh() + 1;

				for (int j = pos + 1; j < Name.size(); j++) {
					Name[j].setX(xTemp);
					Name[j].drawLetter();
					
					xTemp += Name[j].getWidh() + 1;
				}
			}
			graphic->display();
			pos++;
			x += letter.getWidh() + 1;
			i++;
		}
		graphic->display();
	}
}
bool CMENU::enterNewFileName(string& name)
{
	

	int fromX = NSCREENWIDTH / 2 - 70, fromY = NSCREENHEIGHT / 2 - 20;
	drawTitleFrame(fromX, fromY, 140, 35, 15);
	vector<int> color = { 4,13,7,5,8,10,10,4,13,8 };
	
	CLETTER word;

	word.setLetter("ENTER FILE", fromX + 32, fromY + 3, color, 0);
	word.drawWord();

	word.setLetter("NAME: ", fromX + 10, fromY + 10, 1, 0);
	word.drawWord();
	word.setLetter("BACK", fromX + 25, fromY + 25, 1, 0);
	word.drawWord();
	word.setLetter("SAVE", fromX + 85, fromY + 25, 1, 0);
	word.drawWord();

	int nSelect = 0;
	
	while (1)
	{
		int move{};
		if (nSelect == 0)
		{
			nSelect = enterNameForNewFile(name, fromX - 12, fromY + 10);
			//curNSelect = nSelect;
		}

		else
		{
			FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
			move = toupper(_getch());
			if (move == 77)
			{
				if (sound)
					playSound(1);
				if (nSelect != 0)
				{
					if (nSelect == -2)
						nSelect = 0;
					else if (nSelect == -1)
						nSelect = -2;
				}
			}
			if (move == 75)
			{
				if (sound)
					playSound(1);
				if (nSelect == -1)
					nSelect = -2;
				else if (nSelect == -2)
					nSelect = -1;
			}

			if (move == 80)
			{
				if (sound)
					playSound(1);
				if (nSelect == 0)
					nSelect = -2;
				else if (nSelect == -2)
					nSelect = -1;
				else if (nSelect == -1)
					nSelect = 0;
			}
			if (move == 72)
			{
				if (sound)
					playSound(1);
				if (nSelect == 0)
					nSelect = -2;
				else if (nSelect == -2)
					nSelect = 0;
				else if (nSelect == -1)
					nSelect = 0;
			}
			if (move == 13)
			{

				if (nSelect == -1)
				{
					return false;
				}
				else if (nSelect == -2)
				{
					if (checkNameFile(name) == -1)
					{
						word.setLetter("INVALID NAME", fromX + 24, fromY + 18, 13, 0);
						word.drawWord();
						graphic->display();
						Sleep(1000);
					}
					else if (checkNameFile(name)==-2)
					{
						word.setLetter("NAME EXISTS", fromX + 26, fromY + 18, 13, 0);
						word.drawWord();
						graphic->display();
						Sleep(1000);
					}
					return true;
				}
				else
				{
					if (sound)
						playSound(0);
					nSelect = -2;
					//curNSelect = nSelect;
				}
			}
			
		}
		switch (nSelect)
		{
		case -1:
		{
			word.setLetter("BACK", fromX + 25, fromY + 25, 7, 0);
			word.drawWord();
			word.setLetter("SAVE", fromX + 85, fromY + 25, 1, 0);
			word.drawWord();
			break;
		}
		case -2:
		{
			word.setLetter("BACK", fromX + 25, fromY + 25, 1, 0);
			word.drawWord();
			word.setLetter("SAVE", fromX + 85, fromY + 25, 7, 0);
			word.drawWord();
			break;
		}
		}
		graphic->display();
	}
	
	
}
void CMENU::enterFileNameBoard(int fileIndex)
{
	drawGrassLane(24);
	drawGrassLane(48);
	drawGrassLane(56);
	drawSky(0, 23);

	int firstX = 0;
	int fromX = NSCREENWIDTH / 2 - 85, fromY = NSCREENHEIGHT / 2 - 17;

	drawTitleFrame(fromX, fromY, 170, 35, 15);

	vector<int> color = { 4,13,7,5,8,10,10,4,13,8 };
	CLETTER word;
	word.setLetter("ENTER NAME", fromX + 50, 13, color, 0);
	word.drawWord();

	drawStar(fromX + 50 - 13, 12);
	drawStar(fromX + 50 - 15 + 2 * 38 + 22, 12);

	word.setLetter("BEFORE: ", fromX + 6, 23, 1, 0);
	word.drawWord();
	//
	graphic->getTmp(fromX + 65, 23, fromX + 160, 26);
	
	word.setLetter("AFTER: ", fromX + 6, 33, 1, 0);
	word.drawWord();
	firstX += fromX + 65;
	string newNameTemp{};
	for (int i = 0; i < fileDataList[nSelectFile]->fileName.length(); i++) {
		newNameTemp += toupper(fileDataList[nSelectFile]->fileName[i]);
	}
	word.setLetter(newNameTemp, firstX, 33);
	word.drawWord();


	int c0 = 8, c1 = 8;
	if (fileIndex == -1)
	{
		c0 = 7;
	}
	else if (fileIndex == -2)
	{
		c1 = 7;
	}
	word.setLetter("BACK", fromX + 24, 43, c0, 0);
	word.drawWord();
	word.setLetter("RENAME", fromX + 100, 43, c1, 0);
	word.drawWord();


	if (fileIndex == -2)
	{
		if (checkNameFile(fileDataList[nSelectFile]->fileName, nSelectFile) == -2)
		{
			word.setLetter("NAME EXISTS", NSCREENWIDTH / 2 - 23, fromY + 18, 13, 0);
			word.drawWord();
			//graphic->setTmp();
			graphic->display();
		}
		else if (checkNameFile(fileDataList[nSelectFile]->fileName, nSelectFile) == -1)
		{
			word.setLetter("INVALID NAME", NSCREENWIDTH / 2 - 25, fromY + 18, 13, 0);
			word.drawWord();
			//graphic->setTmp();
			graphic->display();
		}
	}


}
int CMENU::renameFile(int fileIndex)
{
	int err = -1;


	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));

	int fromX = NSCREENWIDTH / 2 - 85, fromY = 25;
	CLETTER word;
	int x = 65 + fromX;
	int y = fromY + 8;
	string oldName = fileDataList[nSelectFile]->fileName;
	drawTitleFrame(fromX, NSCREENHEIGHT / 2 - 17, 170, 35, 15);
	setDrawSelectBoard(NULL);
	word.setLetter(oldName, x, 23, 1, 0);
	word.drawWord();
	graphic->setTmp();
	int nSelect = fileIndex;
	curNSelect = nSelect;
	setDrawSelectBoard(&CMENU::enterFileNameBoard);

	fileDataList[fileIndex]->fileName = string{};

	do
	{

		while (1)
		{
			int move{};
			if (nSelect == fileIndex)
			{
				nSelect = enterNameFile(fromX, fromY, 15, fileIndex);
				curNSelect = nSelect;
			}

			else
			{
				FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
				move = toupper(_getch());
				if (move == 77)
				{
					if (sound)
						playSound(1);
					if (nSelect != fileIndex)
					{
						if (nSelect == -2)
							nSelect = fileIndex;
						else if (nSelect == -1)
							nSelect = -2;
					}
				}
				if (move == 75)
				{
					if (sound)
						playSound(1);
					if (nSelect == -1)
						nSelect = -2;
					else if (nSelect == -2)
						nSelect = -1;
				}

				if (move == 80)
				{
					if (sound)
						playSound(1);
					if (nSelect == fileIndex)
						nSelect = -2;
					else if (nSelect == -2)
						nSelect = -1;
					else if (nSelect == -1)
						nSelect = fileIndex;
				}
				if (move == 72)
				{
					if (sound)
						playSound(1);
					if (nSelect == fileIndex)
						nSelect = -2;
					else if (nSelect == -2)
						nSelect = fileIndex;
					else if (nSelect == -1)
						nSelect = fileIndex;
				}
				if (move == 13)
				{

					if (nSelect == -1)
					{

						break;
					}
					else if (nSelect == -2)
					{
						if (checkNameFile(fileDataList[nSelectFile]->fileName, nSelectFile) == -2)
						{
							Sleep(1000);
						}
						else if (checkNameFile(fileDataList[nSelectFile]->fileName, nSelectFile) == -1)
						{
							Sleep(1000);
						}
						
						break;
					}
					else
					{
						if (sound)
							playSound(0);
						nSelect = -2;
						curNSelect = nSelect;
					}

				}
				curNSelect = nSelect;
			}
		}
	} while (nSelect != -1 && checkNameFile(fileDataList[fileIndex]->fileName, fileIndex) != 0);


	if (nSelect == -1)
	{
		fileDataList[fileIndex]->fileName = oldName;
		return 0;
	}
	else
	{
		oldName += ".bin";
		int length = oldName.length() + 1;
		char name[30];
		strcpy_s(name, length, oldName.c_str());
		name[length] = '\0';

		string newName = fileDataList[fileIndex]->fileName + ".bin";
		int newLength = newName.length() + 1;
		char n_name[30];
		strcpy_s(n_name, newLength, newName.c_str());
		n_name[newLength] = '\0';
		err = rename(name, n_name);

		if (err == 0)
		{
			/*fileDataList[fileIndex]->fileName += ".bin";*/
			ofstream f;
			f.open("fileNames.txt", ios::beg | ios::trunc);
			for (int i = 0; i < fileDataList.size(); i++)
			{
				f << '\n';
				f << fileDataList[i]->fileName + ".bin" << '\n';
				f << fileDataList[i]->mode << '\n';
				f << fileDataList[i]->numOfPlayers << '\n';
				f << fileDataList[i]->level;

				/*if (fileDataList[i]->fileName.length() > 4) {
					for (int j = 0; j < 4; j++) {
						fileDataList[i]->fileName.pop_back();
					}
				}*/
			}
			f.close();
			return 0;
		}
		else
		{
			fileDataList[fileIndex]->fileName = oldName;
			return 0;
		}

	}
	graphic->showCur(0);
	return err;
}
int CMENU::deleteFile(int fileIndex)
{

	fileDataList[fileIndex]->fileName += ".bin";
	int length = fileDataList[fileIndex]->fileName.length() + 1;
	char name[30];
	strcpy_s(name, length, fileDataList[fileIndex]->fileName.c_str());
	name[length] = '\0';
	int err = remove(name);
	if (err == 0)
	{
		delete fileDataList[fileIndex];
		fileDataList.erase(fileDataList.begin() + fileIndex);
		ofstream f;
		f.open("fileNames.txt", ios::beg | ios::trunc);
		for (int i = 0; i < fileDataList.size(); i++)
		{
			fileDataList[i]->fileName += ".bin";
			f << '\n';
			f << fileDataList[i]->fileName << '\n';
			f << fileDataList[i]->mode << '\n';
			f << fileDataList[i]->numOfPlayers << '\n';
			f << fileDataList[i]->level;

			if (fileDataList[i]->fileName.length() > 4) {
				for (int j = 0; j < 4; j++) {
					fileDataList[i]->fileName.pop_back();
				}
			}

		}
		f.close();
	}


	return err;

}
void CMENU::fileHandle(int& fileIndex, int select, bool& restart)
{
	if (select == 1) {
		fileDataList[fileIndex]->fileName += ".bin";
		isGameRun = true;
		restart = game->loadGame(fileDataList[fileIndex]->fileName);
		if (fileDataList[fileIndex]->fileName.length() > 4) {
			for (int i = 0; i < 4; i++) {
				fileDataList[fileIndex]->fileName.pop_back();
			}
		}
	}
	else if (select == 2) {
		int err = renameFile(fileIndex);
	}
	else if (select == 3) {
		if (fileIndex == fileDataList.size() - 1) {
			fileIndex--;
			if (indexFirstFile - 3 >= 0) {
				indexFirstFile -= 3;
			}
			int err = deleteFile(fileIndex + 1);
		}
		else {
			int err = deleteFile(fileIndex);
		}

	}

	if (fileIndex >= 0 && fileIndex < fileDataList.size() && fileIndex / 3 != 0) {
		select++;
	}
}
void CMENU::drawBlankPage(int nSelect)
{
	int fromX = NSCREENWIDTH / 2 - 90, fromY = NSCREENHEIGHT / 2 - 25;

	//ve lai
	drawTitleFrame(fromX, fromY, 180, 50, 15);
	vector<int> color = { 4,13,7,5,8,10,4,13,8 };
	CLETTER word;
	word.setLetter("LOAD GAME", NSCREENWIDTH / 2 - 33, 5, color, 0);
	word.drawWord();

	drawStar(71, 4);
	drawStar(155, 4);

	drawHomeButton(106, 45, 7);
}
void CMENU::drawLoadPage(int nSelect)
{
	drawSky(0, 23);
	drawCloud(15, 2);
	drawCloud(48, 12);
	drawCloud(170, 2);
	drawCloud(200, 12);
	drawGrassLane(48);
	drawGrassLane(56);

	int fromX = NSCREENWIDTH / 2 - 90, fromY = NSCREENHEIGHT / 2 - 25;
	drawTitleFrame(fromX, fromY, 180, 50, 15);
	vector<int> color = { 4,13,7,5,8,10,4,13,8 };
	CLETTER word;
	word.setLetter("LOAD GAME", NSCREENWIDTH / 2 - 33, 5, color, 0);
	word.drawWord();

	drawStar(71, 4);
	drawStar(155, 4);

	word.setLetter("NO.", 36, 11, 10, 0);
	word.drawWord();
	word.setLetter("NAME", 66, 11, 13, 0);
	word.drawWord();
	word.setLetter("MODE", 111, 11, 5, 0);
	word.drawWord();
	word.setLetter("LEVEL", 156, 11, 8, 0);
	word.drawWord();

	if (fileDataList.size() > 0) {
		drawHomeButton(72, 45, 7);
		drawLoadGameButton(96, 45, 8);
		drawRenameButton(119, 45, 8);
		drawDeleteButton(143, 45, 8);
		if (fileDataList.size() > 3) {
			drawPlayButton(184, 45, 8);
		}

		int posYNum = 17;

		for (int i = 0; i < fileDataList.size(); i++) {
			if (i > 2) {
				break;
			}
			//set stt
			word.setLetter(to_string(i + 1), 36, posYNum, 1, 0);
			word.drawWord();

			//set ten
			string nameTemp{};
			for (int j = 0; j < fileDataList[i]->fileName.length(); j++) {
				if (j > 2) {
					nameTemp.push_back('.');
					nameTemp.push_back('.');
					break;
				}
				nameTemp.push_back(toupper(fileDataList[i]->fileName[j]));
			}
			word.setLetter(nameTemp, 66, posYNum, 1, 0);
			word.drawWord();

			//set mode va so nguoi choi
			string modeAndNumP{};
			if (fileDataList[i]->mode == 0) {
				modeAndNumP.push_back('C');
			}
			else {
				modeAndNumP.push_back('E');
			}
			modeAndNumP += to_string(fileDataList[i]->numOfPlayers);
			word.setLetter(modeAndNumP, 111, posYNum, 1, 0);
			word.drawWord();

			//set level
			word.setLetter(to_string(fileDataList[i]->level + 1), 156, posYNum, 1, 0);
			word.drawWord();

			posYNum += 7;
		}

		//hien day du ten file
		int sizeName{};
		int numSpace{};
		string nameTemp{};
		for (int i = 0; i < fileDataList[0]->fileName.length(); i++) {
			if (fileDataList[0]->fileName[i] == ' ') {
				numSpace++;
			}
			nameTemp.push_back(toupper(fileDataList[0]->fileName[i]));
		}
		sizeName = numSpace * 4 + (fileDataList[0]->fileName.length() - numSpace) * 8;
		posYNum = 17;
		drawTitleFrame(66, posYNum - 1, sizeName + 9, 7, 6);
		word.setLetter(nameTemp, 66 + 5, posYNum, 1, 0);
		word.drawWord();
	}
	else {
		drawHomeButton(106, 45, 7);
	}
}
void CMENU::loadGame(int& userChoice, int& mode, int& chooseNumOfPlayers)
{
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));

	setDrawSelectBoard(&CMENU::drawLoadPage);
	drawLoadPage();
	graphic->display();

	pair<int, int> chooseFile = { -1, 0 };//fileIndex - buttonIndex
	pair<int, int> preChooseFile = { 0, 0 };
	while (1) {
		//int a = ((preChooseFile.first == fileDataList.size() - 1 ? preChooseFile.first : preChooseFile.first + 1) / 3) * 3;
		if (chooseFile.first == -1)//fileIndex
			chooseFile = selectFileAndOption(preChooseFile.second, indexFirstFile, preChooseFile.first);
		if (chooseFile.first >= 0 && chooseFile.first < fileDataList.size() && chooseFile.second >= 1 && chooseFile.second <= 3)
		{
			bool restart = 0;
			fileHandle(chooseFile.first, chooseFile.second, restart);//nho chinh
			while (restart == true)
			{
				vector<string> nameTemp{};
				vector<int> kindCharTemp{};
				for (int i = 0; i < game->getNumOfPlayers(); i++) {
					nameTemp.push_back(game->getPlayerName(i));
					kindCharTemp.push_back(game->getPlayerKindChar(i));
				}
				game->reset();
				game->setMode(game->getMode());
				game->setNumOfPlayers(game->getNumOfPlayers());
				for (int i = 0; i < game->getNumOfPlayers(); i++) {
					game->setNameForPlayer(i, nameTemp[i]);
					game->setKindCharForPlayer(i, kindCharTemp[i]);
				}
				restart = game->play();
			}

			game->reset();
			isGameRun = false;

			if (chooseFile.first >= 0 && chooseFile.first < 3 && chooseFile.second == 1 || chooseFile.first >= 3 && chooseFile.first < fileDataList.size() && chooseFile.second == 2) {
				indexFirstFile = 0;
				nSelectFile = 0;
				nSelectButton = 0;
				userChoice = -1;

				break;
			}

			if (chooseFile.first != -1)
			{
				preChooseFile = { chooseFile.first, chooseFile.second };
				chooseFile.first = -1;
				chooseFile.second = 0;
			}

		}
		else
		{
			userChoice = -1;
			mode = -1;
			chooseNumOfPlayers = -1;

			indexFirstFile = 0;
			nSelectFile = 0;
			nSelectButton = 0;
			break;

		}
	}
}
void CMENU::addGameFile(FileData* fd)//them file game da save vao vector chua cac file va luu vao file ten cac file game
{

	ofstream f;
	f.open("fileNames.txt", ios::app);
	string name = fd->fileName;
	bool mode = fd->mode;
	int numOfPlayers = fd->numOfPlayers;
	int level = fd->level;
	vector<string> namePlayer = fd->namePlayer;
	vector<int> scorePlayer = fd->scorePlayer;
	vector<int> kindCharPlayer = fd->kindCharPlayer;
	f << '\n';
	f << name << '\n';
	f << mode << '\n';
	f << numOfPlayers << '\n';
	f << level;

	f.close();

	if (fd->fileName.length() > 4) {
		for (int i = 0; i < 4; i++) {
			fd->fileName.pop_back();
		}
	}

	fileDataList.push_back(fd);

	for (int i = 0; i < numOfPlayers; i++) {
		rankDataList.push_back({ namePlayer[i], scorePlayer[i], kindCharPlayer[i] });
	}
	sort(rankDataList.begin(), rankDataList.end(), sortNameByScore);
	ofstream fOut{};
	fOut.open("fileRank.txt", ios::trunc);
	if (fOut) {
		fOut << rankDataList.size() << endl;
		for (int i = 0; i < rankDataList.size(); i++) {
			fOut << rankDataList[i].name << endl;
		}
		for (int i = 0; i < rankDataList.size(); i++) {
			fOut << rankDataList[i].score << endl;
		}
		for (int i = 0; i < rankDataList.size(); i++) {
			fOut << rankDataList[i].kindCharacter << endl;
		}
	}
	fOut.close();
}
vector<string> CMENU::getVectorFileName()
{
	vector<string> fileName{};
	for (int i = 0; i < fileDataList.size(); i++) {
		fileName.push_back(fileDataList[i]->fileName);
	}
	return fileName;
}


bool CMENU::checkNameRank(string name)
{
	for (int i = 0; i < rankDataList.size(); i++) {
		if (name == rankDataList[i].name) {
			return true;
		}
	}
	return false;
}
void CMENU::addFileRank(string name, int score, int kindMainChar)
{
	bool flag = false;
	for (int i = 0; i < rankDataList.size(); i++) {
		if (rankDataList[i].name == name) {
			rankDataList[i].score = score;
			rankDataList[i].kindCharacter = kindMainChar;
			flag = true;
			break;
		}
	}
	if (!flag) {
		rankDataList.push_back({ name, score , kindMainChar });
	}

	sort(rankDataList.begin(), rankDataList.end(), sortNameByScore);

	ofstream fOut{};
	fOut.open("fileRank.txt", ios::trunc);
	if (fOut) {
		fOut << rankDataList.size() << endl;
		for (int i = 0; i < rankDataList.size(); i++) {
			fOut << rankDataList[i].name << endl;
		}
		for (int i = 0; i < rankDataList.size(); i++) {
			fOut << rankDataList[i].score << endl;
		}
		for (int i = 0; i < rankDataList.size(); i++) {
			fOut << rankDataList[i].kindCharacter << endl;
		}
	}
	fOut.close();
}
void CMENU::drawRankPage(int nSelect)
{
	int fromX = NSCREENWIDTH / 2 - 60, fromY = NSCREENHEIGHT / 2 - 18;
	drawTitleFrame(fromX, fromY, 120, 42, 15);
	vector<int> color = { 4,13,7,5,8,10,4 };
	CLETTER word;
	word.setLetter("RANKING", fromX + 16 + 18, fromY - 2, color, 0);
	word.drawWord();
	drawStar(fromX + 4 + 18, fromY - 2);
	drawStar(fromX + 72 + 18, fromY - 2);

	int fromXmedal = fromX + 7, fromYmedal = fromY + 15;
	drawMedalPlatform(fromXmedal, fromYmedal);

	vector<pair<int, int>> posName = { {fromXmedal + 35 + 2, fromYmedal - 5}, {fromXmedal + 3, fromYmedal - 2}, {fromXmedal + 71 + 3, fromYmedal} };
	//vector<pair<int, int>> posChar = { {fromXmedal + 35 + 6 + 8, fromYmedal - 5}, {fromXmedal + 6, fromYmedal - 2}, {fromXmedal + 71 + 6, fromYmedal} };
	if (rankDataList.size() > 0) {
		//set ten
		string nameTemp{};
		if (rankDataList.size() >= 3) {
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < rankDataList[i].name.length(); j++) {
					if (j > 2) {
						nameTemp.push_back('.');
						nameTemp.push_back('.');
						break;
					}
					nameTemp.push_back(toupper(rankDataList[i].name[j]));
				}

				if (rankDataList[i].name.length() > 3) {
					word.setLetter(nameTemp, posName[i].first, posName[i].second, 1, 0);
				}
				else {

					int numSpace{};
					for (int i = 0; i < nameTemp.size(); i++) {
						if (nameTemp[i] == ' ') {
							numSpace++;
						}
					}
					int sizeName = numSpace * 4 + (nameTemp.length() - numSpace) * 8;
					word.setLetter(nameTemp, posName[i].first + 35 / 2 - sizeName / 2, posName[i].second, 1, 0);
				}
				word.drawWord();

				drawMainCharPic(rankDataList[i].kindCharacter, posName[i].first + 12, posName[i].second - 5);
				nameTemp.clear();
			}
		}
		else {
			for (int i = 0; i < rankDataList.size(); i++) {
				for (int j = 0; j < rankDataList[i].name.length(); j++) {
					if (j > 2) {
						nameTemp.push_back('.');
						nameTemp.push_back('.');
						break;
					}
					nameTemp.push_back(toupper(rankDataList[i].name[j]));
				}
				//posName[i].first;
				//nameTemp;
				word.setLetter(nameTemp, posName[i].first, posName[i].second, 1, 0);
				word.drawWord();
				drawMainCharPic(rankDataList[i].kindCharacter, posName[i].first + 12, posName[i].second - 5);
				nameTemp.clear();
			}
		}

	}

	drawHomeButton(fromXmedal + 35 + 9, fromY + 30, 7);
}
void CMENU::rankPage()
{
	setDrawSelectBoard(&CMENU::drawRankPage);
	curNSelect = 0;
	drawRankPage();
	graphic->display();

	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1)
	{
		int move = toupper(_getch());
		if (move == 13 || move == 32)
			return;
	}
}


void CMENU::drawHelpPage(int nSelect)
{
	drawSky(0, 23);
	drawCloud(15, 2);
	drawCloud(48, 12);
	drawCloud(170, 2);
	drawCloud(200, 12);
	//menuBackground(3);
	int fromX = NSCREENWIDTH / 2 - 90, fromY = NSCREENHEIGHT / 2 - 25;

	drawTitleFrame(fromX, fromY, 180, 50, 15);

	vector<int> color = { 4,13,7,5 };
	CLETTER word;
	word.setLetter("HELP", NSCREENWIDTH / 2 - 16, 5, color, 0);
	word.drawWord();
	drawStar(fromX + 62, 4);
	drawStar(fromX + 107, 4);

	switch (nSelect)
	{
	case 0:
	{
		word.setLetter("MOVING KEYS:", NSCREENWIDTH / 2 - 48, 11, 8, 0, 15);
		word.drawWord();
		word.setLetter("A - LEFT ARROW", fromX + 35, 17, 1, 0, 15);
		word.drawWord();
		word.setLetter("W - UP ARROW", fromX + 35, 23, 1, 0, 15);
		word.drawWord();
		word.setLetter("S - DOWN ARROW", fromX + 35, 29, 1, 0, 15);
		word.drawWord();
		word.setLetter("D - RIGHT ARROW", fromX + 35, 35, 1, 0, 15);
		word.drawWord();

		drawHomeButton(NSCREENWIDTH / 2 - 8, 45, 7);
		drawPlayButton(184, 45, 8);
		break;
	}
	case 1:
	{
		word.setLetter("MOVING KEYS:", NSCREENWIDTH / 2 - 48, 11, 8, 0, 15);
		word.drawWord();
		word.setLetter("A - LEFT ARROW", fromX + 35, 17, 1, 0, 15);
		word.drawWord();
		word.setLetter("W - UP ARROW", fromX + 35, 23, 1, 0, 15);
		word.drawWord();
		word.setLetter("S - DOWN ARROW", fromX + 35, 29, 1, 0, 15);
		word.drawWord();
		word.setLetter("D - RIGHT ARROW", fromX + 35, 35, 1, 0, 15);
		word.drawWord();

		drawHomeButton(NSCREENWIDTH / 2 - 8, 45, 8);
		drawPlayButton(184, 45, 7);
		break;
	}
	case 2:
	{
		word.setLetter("COLLECT", 65, 11, 8, 0, 15);
		word.drawWord();
		drawOrange(127, 11);
		word.setLetter("TO:", 139, 11, 8, 0, 15);
		word.drawWord();
		word.setLetter("RIVER: STOP LILIPADS", fromX + 10, 20, 1, 0, 15);
		word.drawWord();
		word.setLetter("ROAD: REMOVE VEHICLES", fromX + 10, 26, 1, 0, 15);
		word.drawWord();
		word.setLetter("GRASS: PLUS 1 POINT", fromX + 10, 32, 1, 0, 15);
		word.drawWord();

		drawBackButton(33, 45, 7);
		drawHomeButton(NSCREENWIDTH / 2 - 8, 45, 8);
		break;
	}
	case 3:
	{
		word.setLetter("COLLECT", 65, 11, 8, 0);
		word.drawWord();
		drawOrange(127, 11);
		word.setLetter("TO:", 139, 11, 8, 0);
		word.drawWord();
		word.setLetter("RIVER: STOP LILIPADS", fromX + 10, 20, 1, 0);
		word.drawWord();
		word.setLetter("ROAD: REMOVE VEHICLES", fromX + 10, 26, 1, 0);
		word.drawWord();
		word.setLetter("GRASS: PLUS 1 POINT", fromX + 10, 32, 1, 0);
		word.drawWord();

		drawBackButton(33, 45, 8);
		drawHomeButton(NSCREENWIDTH / 2 - 8, 45, 7);
		break;
	}
	}
}
void CMENU::helpPage()
{

	setDrawSelectBoard(&CMENU::drawHelpPage);
	drawHelpPage();
	graphic->display();
	int nSelect = 0;
	curNSelect = nSelect;
	int nSlelectPage{};
	thread clickSound;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	while (1)
	{
		int move = toupper(_getch());

		if (move == 'A' || move == 75) {
			if (clickSound.joinable())
				clickSound.join();
			clickSound = thread(&CMENU::playSound, this, 1);
			nSelect--;
			if (nSelect < 0) {
				nSelect = 1;
			}
		}

		if (move == 'D' || move == 77) {
			if (clickSound.joinable())
				clickSound.join();
			clickSound = thread(&CMENU::playSound, this, 1);
			nSelect++;
			if (nSelect > 1) {
				nSelect = 0;
			}
		}

		nSelect;

		if (move == 13 || move == 32) {
			if (clickSound.joinable())
				clickSound.join();
			clickSound = thread(&CMENU::playSound, this, 0);
			if (nSelect == 0 && nSlelectPage == 0 || nSelect == 1 && nSlelectPage == 1) {
				curNSelect = 0;
				if (clickSound.joinable())
					clickSound.join();
				return;
			}
			if (nSlelectPage && nSelect == 0) {
				nSlelectPage = 0;
				nSelect = 1;
			}
			else if (nSlelectPage == 0 && nSelect == 1) {
				nSlelectPage = 1;
				nSelect = 0;
			}
		}

		if (nSlelectPage == 1) {
			drawHelpPage(nSelect + 2);
			curNSelect = nSelect + 2;
		}
		else if (nSlelectPage == 0) {
			drawHelpPage(nSelect);
			curNSelect = nSelect;

		}

		setDrawSelectBoard(&CMENU::drawHelpPage);

		graphic->display();

	}
}


void CMENU::drawAboutPage(int nSelect)
{
	drawSky(0, 23);
	drawCloud(15, 2);
	drawCloud(48, 12);
	drawCloud(170, 2);
	drawCloud(200, 12);
	int fromX = NSCREENWIDTH / 2 - 100, fromY = NSCREENHEIGHT / 2 - 27;

	drawTitleFrame(fromX, fromY, 200, 55, 15);

	vector<int> color = { 4,13,7,5,8 };
	CLETTER word;
	word.setLetter("ABOUT", NSCREENWIDTH / 2 - 20, 3, color, 0, 15);
	word.drawWord();
	drawStar(84, 2);
	drawStar(138, 2);

	word.setLetter("GROUP 6 - 22CLC01", NSCREENWIDTH / 2 - 61, 10, 12, 0, 15);
	word.drawWord();
	word.setLetter("DINH NGUYEN QUYNH HUONG", NSCREENWIDTH / 2 - 92, 16, 1, 0, 15);
	word.drawWord();
	word.setLetter("NGUYEN NGOC PHUONG UYEN", NSCREENWIDTH / 2 - 92, 22, 1, 0, 15);
	word.drawWord();
	word.setLetter("VO LE VIET TU", NSCREENWIDTH / 2 - 52, 28, 1, 0, 15);
	word.drawWord();

	word.setLetter("LECTURER:", NSCREENWIDTH / 2 - 32, 36, 12, 0, 15);
	word.drawWord();
	word.setLetter("TRUONG TOAN THINH", NSCREENWIDTH / 2 - 68, 42, 1, 0, 15);
	word.drawWord();

	drawHomeButton(NSCREENWIDTH / 2 - 8, 48, 7);
}
void CMENU::aboutPage()
{
	setDrawSelectBoard(&CMENU::drawAboutPage);
	drawAboutPage();
	graphic->display();
	int nSelect = 0;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return;
		}
	}
}


void CMENU::playSound(int id)
{
	mciSendString(L"close wav", NULL, 0, NULL);
	mciSendString(arrSound[id], NULL, 0, NULL);
	mciSendString(L"play wav", NULL, 0, NULL);
}
void CMENU::drawSettingPage(int nSelect)
{
	drawSky(0, 23);
	drawCloud(15, 2);
	drawCloud(48, 12);
	drawCloud(170, 2);
	drawCloud(200, 12);
	int fromX = NSCREENWIDTH / 2 - 57, fromY = NSCREENHEIGHT / 2 - 25;
	drawTitleFrame(fromX, fromY, 117, 50, 15);

	vector<int> color = { 4,13,7,5,8,10,4 };
	CLETTER word;
	word.setLetter("SETTING", NSCREENWIDTH / 2 - 28, 5, color, 0);
	word.drawWord();
	drawStar(NSCREENWIDTH / 2 - 28 - 12, 4);
	drawStar(NSCREENWIDTH / 2 - 28 + 56 + 1, 4);
	int c0 = 1, c1 = c0, c2 = c0, c3 = 8;
	int b0 = 8, b1 = b0, b2 = b1;

	switch (nSelect)
	{
	case 0:
	{
		c0 = 7;
		b0 = 7;
		break;
	}
	case 1:
	{
		c1 = 7;
		b1 = 7;
		break;
	}
	case 2:
	{
		c2 = 7;
		b2 = 7;
		break;
	}
	case 3:
	{
		c3 = 7;
		break;
	}
	}
	word.setLetter("SOUND:", fromX + 20, fromY + 8, c0, 0);
	word.drawWord();
	if (sound)
		drawTickButton(fromX + 20 + 60, fromY + 5, b0);
	else drawCrossButton(fromX + 20 + 60, fromY + 5, b0);

	word.setLetter("MUSIC:", fromX + 20, fromY + 18, c1, 0);
	word.drawWord();
	if (bgMusic)
		drawTickButton(fromX + 20 + 60, fromY + 18 - 3, b1);
	else
		drawCrossButton(fromX + 20 + 60, fromY + 18 - 3, b1);

	word.setLetter("MOTION:", fromX + 20, fromY + 28, c2, 0);
	word.drawWord();
	if (bgroundMotion)
		drawTickButton(fromX + 20 + 60, fromY + 28 - 3, b2);
	else drawCrossButton(fromX + 20 + 60, fromY + 28 - 3, b2);

	drawHomeButton(NSCREENWIDTH / 2 - 8, 44, c3);
}
void CMENU::settingPage()
{
	drawSettingPage();
	int nSelect = 0;
	curNSelect = nSelect;
	setDrawSelectBoard(&CMENU::drawSettingPage);
	graphic->display();

	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());
		if (move == 'S' || move == 80)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 3)
				nSelect = 0;
		}
		if (move == 'W' || move == 72)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 3;
		}
		curNSelect = nSelect;
		drawSettingPage(nSelect);
		graphic->display();
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			if (nSelect == 3)
				return;
			else if (nSelect == 0)
			{
				sound = !sound;
			}
			else if (nSelect == 1)
			{
				bgMusic = !bgMusic;
				if (bgMusic == true)
				{
					PlaySound(L"main_music.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
				}
				else
				{
					PlaySound(nullptr, nullptr, 0);
				}
			}
			else if (nSelect == 2)
			{
				bgroundMotion = !bgroundMotion;
				//drawSettingPage(nSelect);
			}
			drawSettingPage(nSelect);
			graphic->display();
		}
	}
}


void CMENU::drawConfirmExit(int nSelect)
{
	int c0 = 1, c1 = 1;
	if (nSelect == 0)
		c0 = 7;
	else if (nSelect == 1)
		c1 = 7;
	int fromX = NSCREENWIDTH / 2 - 40, fromY = NSCREENHEIGHT / 2 - 13;
	drawTitleFrame(fromX, fromY, 80, 26, 15);
	drawExitButton(NSCREENWIDTH / 2 - 8, NSCREENHEIGHT / 2 - 6, 8);
	CLETTER word;
	word.setLetter("YES", fromX + 11, fromY + 18, c0, 0);
	word.drawWord();
	word.setLetter("NO", fromX + 53, fromY + 18, c1, 0);
	word.drawWord();
}
bool CMENU::confirmExit()
{
	curNSelect = 1;
	drawConfirmExit(1);
	graphic->display();
	int nSelect = 1;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());
		if (move == 'D' || move == 77)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 1)
				nSelect = 0;
		}
		if (move == 'A' || move == 75)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 1;
		}
		curNSelect = nSelect;
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return (nSelect);
		}

		drawConfirmExit(nSelect);
		graphic->display();

	}
}


bool CMENU::askForRestart()
{
	int fromX = NSCREENWIDTH / 2 - 40, fromY = NSCREENHEIGHT / 2 - 15;
	drawTitleFrame(fromX, fromY, 85, 25, 15);
	vector<int> color = { 4,13,7,5,8,10,4 };
	CLETTER word;
	word.setLetter("RESTART", fromX + 15, fromY + 2, color, 0);
	word.drawWord();
	drawTickButton(fromX + 20, fromY + 12, 7);
	drawCrossButton(fromX + 50, fromY + 12, 8);
	graphic->display();
	int nSelect = 0;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());
		if (move == 'D' || move == 77)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 1)
				nSelect = 0;
		}
		if (move == 'A' || move == 75)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 1;
		}
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return (nSelect == 0);
		}

		switch (nSelect)
		{
		case 0:
		{
			drawTickButton(fromX + 20, fromY + 12, 7);
			drawCrossButton(fromX + 50, fromY + 12, 8);
			break;
		}
		case 1:
			drawTickButton(fromX + 20, fromY + 12, 8);
			drawCrossButton(fromX + 50, fromY + 12, 7);
			break;
		}
		graphic->display();

	}

}
void CMENU::drawAskForResume(int nSelect)
{

	int c0 = 1, c1 = 1;
	if (nSelect == 0)
	{
		c0 = 7;
	}
	else
	{
		c1 = 7;
	}
	int fromX = NSCREENWIDTH / 2 - 40, fromY = NSCREENHEIGHT / 2 - 13;
	drawTitleFrame(fromX, fromY, 80, 26, 15);
	drawPlayButton(NSCREENWIDTH / 2 - 8, NSCREENHEIGHT / 2 - 6, 8);
	CLETTER word;
	word.setLetter("YES", fromX + 11, fromY + 18, c0, 0);
	word.drawWord();
	word.setLetter("NO", fromX + 53, fromY + 18, c1, 0);
	word.drawWord();
}
bool CMENU::askForResume()
{
	drawAskForResume(0);
	graphic->display();
	int nSelect = 0;
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
	thread clickSound;
	while (1)
	{
		int move = toupper(_getch());
		if (move == 'D' || move == 77)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect++;
			if (nSelect > 1)
				nSelect = 0;
		}
		if (move == 'A' || move == 75)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 1);
			}
			nSelect--;
			if (nSelect < 0)
				nSelect = 1;

		}
		if (move == 13 || move == 32)
		{
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CMENU::playSound, this, 0);
			}
			if (clickSound.joinable())
				clickSound.join();
			return (nSelect == 0);
		}

		drawAskForResume(nSelect);
		graphic->display();

	}

}


void CMENU::drawButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
	pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 2)] = 1 * 16 + 0;
	for (int i = 3; i <= 12; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = c * 16 + 0;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 13)] = 1 * 16 + 0;
	pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 14)] = (pColor[(fromY)*nScreenWidth + (fromX + 14)] / 16) * 16 + 0;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = c * 16 + 1;
	for (int i = 2; i <= 13; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = c * 16 + 0;
	}
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = c * 16 + 1;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 0 * 16 + 0;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + 1;
	for (int i = 2; i <= 13; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = c * 16 + 0;
	}
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + 1;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = 0 * 16 + 0;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + 1;
	for (int i = 2; i <= 13; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = c * 16 + 0;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 1;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 0;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = c * 16 + 1;
	for (int i = 2; i <= 13; i++) {
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 4) * nScreenWidth + (fromX + i)] = c * 16 + 0;
	}
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = c * 16 + 1;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 0;

	//row 6
	pBuffer[(fromY + 5) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 1)] = c * 16 + 1;
	for (int i = 2; i <= 13; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = c * 16 + 0;
	}
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 14)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 14)] = c * 16 + 1;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 15)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 15)] = 0 * 16 + 0;

	//row 7
	pBuffer[(fromY + 6) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 6) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 1)] = c * 16 + 1;
	for (int i = 2; i <= 13; i++) {
		pBuffer[(fromY + 6) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 6) * nScreenWidth + (fromX + i)] = 1 * 16 + c;
	}
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 14)] = L' ';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 15)] = L' ';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 15)] = 0 * 16 + 0;

	//row 8
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 7) * nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
	for (int i = 3; i <= 13; i++) {
		pBuffer[(fromY + 7) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 7) * nScreenWidth + (fromX + i)] = 1 * 16 + 0;
	}
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 14)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 7) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
}
void CMENU::drawPlayButton(int fromX, int fromY, int c)
{
	drawButton(fromX, fromY, c);
	int nScreenWidth = NSCREENWIDTH;
	//Element
	//row 2
	int e = 4;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = c * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = c * 16 + e;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = e * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = e * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + e;

	//row 4
	for (int i = 5; i <= 10; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = e * 16 + 0;
	}

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = e * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = e * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = e * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = c * 16 + e;

	//row 6
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = c * 16 + e;
}
void CMENU::drawLoadGameButton(int fromX, int fromY, int c)
{
	drawButton(fromX, fromY, c);
	int nScreenWidth = NSCREENWIDTH;
	//Element
	int e = 4;
	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = c * 16 + e;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] / 16) * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	for (int i = 5; i <= 10; i++) {
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + i)] / 16) * 16 + e;
	}
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = e * 16 + e;

	//row 6
	for (int i = 4; i <= 11; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + i)] / 16) * 16 + e;
	}
}
void CMENU::drawRankButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;

	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//col 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] / 16) * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] / 16) * 16 + e;

	//col 4
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] / 16) * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + e;

	//col 5
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + e;

	//col 6
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] / 16) * 16 + e;


	//col 7
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = e * 16 + e;

	//col 8
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + e;
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + i) * nScreenWidth + (fromX + 7)] = L'█';
		pColor[(fromY + i) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	}

	//col 9
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] / 16) * 16 + e;
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + i) * nScreenWidth + (fromX + 8)] = L'█';
		pColor[(fromY + i) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	}

	//col 10
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] = e * 16 + e;

	//col 11
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;

	//col 12
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] / 16) * 16 + e;

	//col 13
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] / 16) * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] / 16) * 16 + e;

	//col 14
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] / 16) * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] / 16) * 16 + e;
}
void CMENU::drawHelpButton(int fromX, int fromY, int c)
{
	drawButton(fromX, fromY, c);
	int nScreenWidth = NSCREENWIDTH;
	//Element
	int e = 4;
	//row 2
	for (int i = 6; i <= 9; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = c * 16 + e;
	}

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = e * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + e;

	//row 5
	for (int i = 6; i <= 8; i++) {
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 4) * nScreenWidth + (fromX + i)] = c * 16 + e;
	}

	//row 6
	for (int i = 6; i <= 8; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = e * 16 + e;
	}
}
void CMENU::drawAboutButton(int fromX, int fromY, int c)
{
	drawButton(fromX, fromY, c);
	int nScreenWidth = NSCREENWIDTH;
	//Element
	int e = 4;
	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = c * 16 + e;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = c * 16 + e;

	//row 6
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = c * 16 + e;
}
void CMENU::drawSettingButton(int fromX, int fromY, int c)
{
	drawButton(fromX, fromY, c);
	int nScreenWidth = NSCREENWIDTH;
	//Element
	int e = 4;
	//col 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = e * 16 + e;

	//col 5
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = c * 16 + e;

	//col 6
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = c * 16 + e;

	//col 7
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = e * 16 + e;

	//col 8
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = e * 16 + e;

	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = e * 16 + e;

	//col 9
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = e * 16 + e;

	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = e * 16 + e;

	//col 10
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = e * 16 + e;

	//col 11
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = c * 16 + e;

	//col 12
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 11)] = c * 16 + e;

	//col 13
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = e * 16 + e;
}
void CMENU::drawExitButton(int fromX, int fromY, int c)
{
	drawButton(fromX, fromY, c);
	int nScreenWidth = NSCREENWIDTH;
	//Element
	int e = 4;

	//row 2
	for (int i = 6; i <= 11; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = c * 16 + e;
	}

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = e * 16 + e;

	//row 4
	for (int i = 3; i <= 8; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = e * 16 + e;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = e * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] / 16) * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = e * 16 + e;

	//row 6
	for (int i = 6; i <= 11; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = c * 16 + e;
	}
}
void CMENU::drawHomeButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;

	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] / 16) * 16 + e;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + e;
	for (int i = 5; i <= 10; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = e * 16 + e;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] / 16) * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = e * 16 + e;
}
void CMENU::drawRenameButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;

	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//row 2
	for (int i = 3; i <= 11; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + i)] / 16) * 16 + e;
	}

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] / 16) * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	for (int i = 6; i <= 9; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + i)] / 16) * 16 + e;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] / 16) * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = e * 16 + e;

	//row 6
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	for (int i = 5; i <= 10; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + i)] / 16) * 16 + e;
	}
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 11)] = e * 16 + e;
}
void CMENU::drawDeleteButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;

	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] / 16) * 16 + e;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	for (int i = 5; i <= 10; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = c * 16 + e;
	}
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = e * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = e * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = e * 16 + e;

	//row 6
	for (int i = 6; i <= 9; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + i)] / 16) * 16 + e;
	}
}
void CMENU::drawBackButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;

	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//col 6
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = e * 16 + e;

	//col 7
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] / 16) * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + e;

	//col 8
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = e * 16 + e;

	//col 9
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] / 16) * 16 + e;

	//col 10
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] / 16) * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] / 16) * 16 + e;

	//col 11
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;
	for (int i = 2; i <= 4; i++) {
		pBuffer[(fromY + i) * nScreenWidth + (fromX + 10)] = L' ';
		pColor[(fromY + i) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	}
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] / 16) * 16 + e;
}
void CMENU::drawTickButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + e;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + e;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = c * 16 + e;
	for (int i = 5; i <= 8; i++) {
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 4) * nScreenWidth + (fromX + i)] = e * 16 + e;
	}
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = c * 16 + e;

	//row 6
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = c * 16 + e;
}
void CMENU::drawCrossButton(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	drawButton(fromX, fromY, c);
	//Element
	int e = 4;
	//col 4
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = c * 16 + e;

	//col 5
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = e * 16 + e;

	//col 6
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = c * 16 + e;

	//col 7
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = e * 16 + e;

	//col 8
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = c * 16 + e;

	//col 9
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = c * 16 + e;

	//col 10
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = e * 16 + e;

	//col 11
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = c * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = e * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = c * 16 + e;

	//col 12
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = e * 16 + e;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + e;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 11)] = L' ';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 11)] = e * 16 + e;

	//col 13
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = c * 16 + e;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 12)] = c * 16 + e;
}

void CMENU::drawTitleFrame(int fromX, int fromY, int width, int height, int color)
{
	int nScreenWidth = NSCREENWIDTH;
	pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
	for (int i = 2; i <= width - 2 - 1; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = color * 16 + 0;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + width - 1 - 1)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + width - 1 - 1)] = (pColor[(fromY)*nScreenWidth + (fromX + width - 1 - 1)] / 16) * 16 + 0;

	//Canh trai
	for (int i = 1; i <= height - 2 - 1; i++) {
		pBuffer[(fromY + i) * nScreenWidth + (fromX)] = L'█';
		pColor[(fromY + i) * nScreenWidth + (fromX)] = color * 16 + 0;
	}

	//Canh duoi
	pBuffer[(fromY + height - 1 - 1) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + height - 1 - 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + height - 1 - 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
	for (int i = 2; i <= width - 2 - 1; i++) {
		pBuffer[(fromY + height - 1 - 1) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + height - 1 - 1) * nScreenWidth + (fromX + i)] = color * 16 + 0;
	}
	pBuffer[(fromY + height - 1 - 1) * nScreenWidth + (fromX + width - 1 - 1)] = L'▀';
	pColor[(fromY + height - 1 - 1) * nScreenWidth + (fromX + width - 1 - 1)] = (pColor[(fromY + height - 1 - 1) * nScreenWidth + (fromX + width - 1 - 1)] / 16) * 16 + 0;

	//Canh phai
	for (int i = 1; i <= height - 2 - 1; i++) {
		pBuffer[(fromY + i) * nScreenWidth + (fromX + width - 1)] = L'█';
		pColor[(fromY + i) * nScreenWidth + (fromX + width - 1)] = color * 16 + 0;
	}

	//Do mau
	for (int i = 1; i <= width - 1 - 1; i++)
	{
		for (int j = 1; j <= height - 3; j++)
		{
			pBuffer[(fromY + j) * nScreenWidth + (fromX + i)] = L' ';
			pColor[(fromY + j) * nScreenWidth + (fromX + i)] = color * 16 + color;
		}
	}

}
void CMENU::drawMedalPlatform(int fromX, int fromY)
{
	CLETTER word;
	int nScreenWidth = NSCREENWIDTH;

	int a = 7, b = 14, c = 13;
	//Rank1
	for (int i = 35; i <= 35 + 35; i++) {
		for (int j = 0; j <= 12; j++) {
			pBuffer[(fromY + j) * nScreenWidth + (fromX + i)] = L' ';
			pColor[(fromY + j) * nScreenWidth + (fromX + i)] = a * 16 + a;
		}
	}
	word.setLetter('1', fromX + 51, fromY + 4, 1);
	word.drawLetter();

	//rank2
	for (int i = 0; i <= 34; i++) {
		for (int j = 3; j <= 12; j++) {
			pBuffer[(fromY + j) * nScreenWidth + (fromX + i)] = L' ';
			pColor[(fromY + j) * nScreenWidth + (fromX + i)] = b * 16 + b;
		}
	}
	word.setLetter('2', fromX + 14, fromY + 6, 1);
	word.drawLetter();

	//rank3
	for (int i = 71; i <= 35 + 35 + 35; i++) {
		for (int j = 5; j <= 12; j++) {
			pBuffer[(fromY + j) * nScreenWidth + (fromX + i)] = L' ';
			pColor[(fromY + j) * nScreenWidth + (fromX + i)] = c * 16 + c;
		}
	}
	word.setLetter('2', fromX + 85, fromY + 7, 1);
	word.drawLetter();
}

void CMENU::drawRoad(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	//row 1
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = 2 * 16 + 1;
	}

	//row 2
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = 2 * 16 + 2;
	}

	//row 3
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = 2 * 16 + 2;
	}

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 2 * 16 + 2;
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = 2 * 16 + 1;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 2 * 16 + 2;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = 2 * 16 + 2;
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 4) * nScreenWidth + (fromX + i)] = 2 * 16 + 1;
	}
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 2 * 16 + 2;

	//row 6
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY + 5) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 5) * nScreenWidth + (fromX + i)] = 2 * 16 + 2;
	}

	//row 7
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY + 6) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 6) * nScreenWidth + (fromX + i)] = 2 * 16 + 2;
	}

	//row 8
	for (int i = 0; i <= 7; i++) {
		pBuffer[(fromY + 7) * nScreenWidth + (fromX + i)] = L'▀';
		pColor[(fromY + 7) * nScreenWidth + (fromX + i)] = 2 * 16 + 1;
	}


}
void CMENU::drawRoadLane(int fromY)
{
	for (int i = 0; i < NSCREENWIDTH; i = i + 8) {
		drawRoad(i, fromY);
	}
}
void CMENU::drawGrass(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	pBuffer[(fromY)*nScreenWidth + (fromX)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX)] = (pColor[(fromY)*nScreenWidth + (fromX)] / 16) * 16 + 11;

	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + 11;

	pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + 11;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] / 16) * 16 + 11;

	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + 11;

	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + 11;

	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = (pColor[(fromY)*nScreenWidth + (fromX + 6)] / 16) * 16 + 11;
}
void CMENU::drawGrassLane(int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	for (int i = 0; i < nScreenWidth; i++)
	{
		for (int j = fromY; j <= fromY + 7; j++)
		{
			pBuffer[j * nScreenWidth + i] = L' ';
			pColor[j * nScreenWidth + i] = 10 * 16 + 10;
		}
	}
	for (int i = 25; i < 232; i = i + 30) {
		drawGrass(i, fromY + 2);
	}
	for (int i = 10; i < 232; i = i + 30) {
		drawGrass(i, fromY + 5);
	}
}
void CMENU::drawWaterLane(int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	for (int i = 0; i < nScreenWidth; i++)
	{
		for (int j = fromY; j <= fromY + 7; j++)
		{
			pBuffer[j * nScreenWidth + i] = L' ';
			pColor[j * nScreenWidth + i] = 5 * 16 + 5;
		}
	}
	for (int i = 2; i < nScreenWidth; i = i + 32) {
		pBuffer[(fromY + 2) * nScreenWidth + i] = L'▀';
		pColor[(fromY + 2) * nScreenWidth + i] = 5 * 16 + 1;
		pBuffer[(fromY + 2) * nScreenWidth + (i + 1)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (i + 1)] = 5 * 16 + 1;
		pBuffer[(fromY + 2) * nScreenWidth + (i + 2)] = L'▀';
		pColor[(fromY + 2) * nScreenWidth + (i + 2)] = 5 * 16 + 1;
	}
	for (int i = 20; i < nScreenWidth; i = i + 32) {
		pBuffer[(fromY + 5) * nScreenWidth + (i - 1)] = L'▄';
		pColor[(fromY + 5) * nScreenWidth + (i - 1)] = 5 * 16 + 1;
		pBuffer[(fromY + 5) * nScreenWidth + i] = L'▀';
		pColor[(fromY + 5) * nScreenWidth + i] = 5 * 16 + 1;
		pBuffer[(fromY + 5) * nScreenWidth + (i + 1)] = L'▄';
		pColor[(fromY + 5) * nScreenWidth + (i + 1)] = 5 * 16 + 1;

	}
}
void CMENU::drawSky(int fromY, int toY)
{
	if (fromY < 0)
		fromY = 0;
	if (toY >= NSCREENHEIGHT)
		toY = NSCREENHEIGHT - 1;
	for (int i = fromY; i <= toY; i++)
		for (int j = 0; j < NSCREENWIDTH; j++)
		{
			pBuffer[i * NSCREENWIDTH + j] = L' ';
			pColor[i * NSCREENWIDTH + j] = 5 * 16 + 5;
		}
}

void CMENU::drawLiliPad(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = (pColor[(fromY)*nScreenWidth + (fromX + 2)] / 16) * 16 + 11;
		}
		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + 11;
		}

		for (int i = fromX + 4; i <= fromX + 8; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY)*nScreenWidth + (i)] = L'▀';
				pColor[(fromY)*nScreenWidth + (i)] = 12 * 16 + 11;
			}
		}

		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = (pColor[(fromY)*nScreenWidth + (fromX + 9)] / 16) * 16 + 11;
		}
		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = (pColor[(fromY)*nScreenWidth + (fromX + 10)] / 16) * 16 + 11;
		}
	}
	//row 2
	if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
	{
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 11 * 16 + 11;
		}
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 12 * 16 + 12;
		}
		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 12 * 16 + 10;
		}

		for (int i = fromX + 4; i <= fromX + 9; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 1) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 1) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}
		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 10 * 16 + 11;
		}
		if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] / 16) * 16 + 11;
		}

	}
	//row 3
	if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = 11 * 16 + 11;
		}
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 10 * 16 + 12;
		}
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 10 * 16 + 10;
		}

		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 10 * 16 + 10;
		}

		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
		}

		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
		}

		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;
		}

		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
		}

		if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = 10 * 16 + 11;
		}

		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = 11 * 16 + 11;
		}

		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] / 16) * 16 + 11;
		}

		if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] / 16) * 16 + 11;
		}
	}
	//row 4
	if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 11 * 16 + 11;
		}

		for (int i = fromX + 1; i <= fromX + 4; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 3) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 3) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}

		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
		}

		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 10 * 16 + 11;
		}

		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 10 * 16 + 11;
		}


		for (int i = fromX + 8; i <= fromX + 11; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 3) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 3) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}

		if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
		}
	}
	//row5
	if (fromY + 4 >= 0 && fromY + 4 < NSCREENWIDTH)
	{
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = 11 * 16 + 11;
		}


		for (int i = fromX + 2; i <= fromX + 8; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 4) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 4) * nScreenWidth + (i)] = 10 * 16 + 10;
			}
		}

		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
		}

		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = 10 * 16 + 12;
		}

		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = 12 * 16 + 12;
		}

		if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
		}
	}
	//row 6
	if (fromY + 5 >= 0 && fromY < NSCREENHEIGHT)
	{
		if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] / 16) * 16 + 11;
		}


		if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] / 16) * 16 + 11;
		}

		if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 10 * 16 + 11;
		}


		if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 10 * 16 + 11;
		}


		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = 12 * 16 + 11;
		}


		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = 12 * 16 + 11;
		}


		if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = 12 * 16 + 11;
		}


		if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] / 16) * 16 + 11;
		}

		if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] / 16) * 16 + 11;
		}
	}
}
void CMENU::drawOrange(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;

	//row 1
	for (int i = 1; i <= 5; i++) {
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = (pColor[(fromY)*nScreenWidth + (fromX + i)] / 16) * 16 + 13;
	}

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX)] = 3 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 13 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 13 * 16 + 11;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 11 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 13 * 16 + 11;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 13 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 13 * 16 + 13;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = 3 * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 13 * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 13 * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 13 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 13 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 13 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 13 * 16 + 13;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 3;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 3 * 16 + 13;
	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = 13 * 16 + 3;
	}
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 13;
}
void CMENU::drawCloud(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;

	//col 1
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH && fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
	{
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + 14;
	}

	//col 2
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH && fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
	{

		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'█';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 14;
	}

	//col 3
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] / 16) * 16 + 14;
		}
	}

	//col 4
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'█';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] / 16) * 16 + 14;
	}

	//col 5
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 1 * 16 + 14;
	}

	//col 6
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 1 * 16 + 14;
	}

	//col 7
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 14;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 1 * 16 + 14;
	}

	//col 8
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = 14 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = 1 * 16 + 14;
	}

	//col 9
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = 14 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'█';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + 14;
	}

	//col 10
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] / 16) * 16 + 14;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = 14 * 16 + 14;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'█';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = 14 * 16 + 14;
	}

	//col 11
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = 14 * 16 + 14;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = 14 * 16 + 14;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = 1 * 16 + 14;
	}

	//col 12
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] / 16) * 16 + 14;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = 14 * 16 + 14;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = 14 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = 1 * 16 + 14;
	}

	//col 13
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 14 * 16 + 14;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = 14 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = 1 * 16 + 14;
	}

	//col 14
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = 1 * 16 + 14;
	}

	//col 15
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 1 * 16 + 14;
	}

	//col 16
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + 1;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 1 * 16 + 14;
	}

	//col 17
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] / 16) * 16 + 1;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = 1 * 16 + 14;
	}

	//col 18
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] / 16) * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = 1 * 16 + 14;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'█';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = 14 * 16 + 14;
	}

	//col 19
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 14 * 16 + 14;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'█';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = 14 * 16 + 14;
	}

	//col 20
	if (fromX + 20 >= 0 && fromX + 20 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 20)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 20)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 20)] = L' ';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 20)] = 14 * 16 + 2;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 20)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 20)] = 1 * 16 + 14;
	}

	//col 21
	if (fromX + 21 >= 0 && fromX + 21 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + 21)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + 21)] = 1 * 16 + 1;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 21)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 21)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 21)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 21)] = 1 * 16 + 14;
	}

	//col 22
	if (fromX + 22 >= 0 && fromX + 22 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 22)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 22)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 22)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 22)] = 1 * 16 + 14;
	}

	//col 23
	if (fromX + 23 >= 0 && fromX + 23 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + 23)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + 23)] = 1 * 16 + 1;
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 23)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 23)] = 1 * 16 + 14;
	}

	//col 24
	if (fromX + 24 >= 0 && fromX + 24 < NSCREENWIDTH)
	{
		pBuffer[(fromY + 4) * nScreenWidth + (fromX + 24)] = L'▄';
		pColor[(fromY + 4) * nScreenWidth + (fromX + 24)] = 1 * 16 + 14;
	}
}
void CMENU::drawStar(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	//row 1
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + 0;
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = (pColor[(fromY)*nScreenWidth + (fromX + 5)] / 16) * 16 + 0;

	//row 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = (pColor[(fromY)*nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 1 * 16 + 0;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 7 * 16 + 1;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 7 * 16 + 1;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 7 * 16 + 0;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + 0;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY)*nScreenWidth + (fromX + 8)] / 16) * 16 + 0;

	//row 3
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = 0 * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 1 * 16 + 0;

	for (int i = 2; i <= 5; i++) {
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L' ';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = 7 * 16 + 0;
	}

	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 7 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = 15 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = 7 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = 0 * 16 + 15;

	//row 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 0 * 16 + 0;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 1 * 16 + 0;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 7 * 16 + 0;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 7 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 15 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 7 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 7 * 16 + 0;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = 0 * 16 + 0;

	//row 5
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = 1 * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 7 * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] / 16) * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 7 * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 7 * 16 + 0;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + 0;
}

void CMENU::drawRegCarLeft(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = c * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 14
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 13)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 14)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 16
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 15)] = (pColor[(fromY)*nScreenWidth + (fromX + 15)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 20
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}
}
void CMENU::drawRoadsterLeft(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = (pColor[(fromY)*nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] / 16) * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = 0 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 14
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 16
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 0 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 18)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 20
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}
}
void CMENU::drawTruckLeft(int fromX, int fromY, int head, int body)
{
	int nScreenWidth = NSCREENWIDTH;

	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 7;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = 0 * 16 + head;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] / 16) * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = head * 16 + head;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = head * 16 + head;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = head * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = head * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = head * 16 + head;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = 0 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + head;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 0 * 16 + 14;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 0 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] / 16) * 16 + 0;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		for (int i = fromY; i <= fromY + 4; i++) {
			if (i >= 0 && i < NSCREENHEIGHT)
				pBuffer[(i)*nScreenWidth + (fromX + 7)] = L' ';
			pColor[(i)*nScreenWidth + (fromX + 7)] = head * 16 + head;
		}
	}

	//body part
	for (int i = fromX + 8; i <= fromX + 20; i++) {
		if (i >= 0 && i < NSCREENWIDTH)
		{
			for (int j = fromY; j <= fromY + 4; j++) {
				if (j >= 0 && j < NSCREENHEIGHT)
				{
					pBuffer[(j)*nScreenWidth + (i)] = L' ';
					pColor[(j)*nScreenWidth + (i)] = body * 16 + body;
				}
			}
		}
	}

	//second wheel
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = 0 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] / 16) * 16 + 0;
		}
	}

	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 17)] = 0 * 16 + 14;
		}
	}

	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = 0 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] / 16) * 16 + 0;
		}
	}

	//back light
	if (fromX + 20 >= 0 && fromX + 20 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 20)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 20)] = 4 * 16 + 4;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 20)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 20)] = 0 * 16 + 0;
		}
	}
}
void CMENU::drawPoliceLeft(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	int c = 14;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{

		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY - 1 >= 0 && fromY - 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY - 1) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY - 1) * nScreenWidth + (fromX + 10)] = (pColor[(fromY - 1) * nScreenWidth + (fromX + 10)] / 16) * 16 + 5;
		}
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY - 1 >= 0 && fromY - 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY - 1) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY - 1) * nScreenWidth + (fromX + 11)] = (pColor[(fromY - 1) * nScreenWidth + (fromX + 11)] / 16) * 16 + 4;
		}
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = c * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 14
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 13)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 14)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 16
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 15)] = (pColor[(fromY)*nScreenWidth + (fromX + 15)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 20
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}
}

void CMENU::drawPikachuRight(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + 7;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 7 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] / 16) * 16 + 7;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 6 * 16 + 0;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 6 * 16 + 6;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + 7;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 6 * 16 + 6;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 6 * 16 + 4;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 7 * 16 + 7;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 6 * 16 + 0;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 6 * 16 + 3;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 6 * 16 + 6;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 7 * 16 + 3;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 6 * 16 + 6;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 6 * 16 + 7;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = 7 * 16 + 0;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 7 * 16 + 0;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + 7;
		}
	}
}
void CMENU::drawKirbyRight(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 4;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 4 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] / 16) * 16 + 4;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 8 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 8 * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 8 * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] / 16) * 16 + 4;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 1 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 8 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 8 * 16 + 8;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 4;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 8 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 8 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 4;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 8 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 8 * 16 + 8;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 9;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = (pColor[(fromY)*nScreenWidth + (fromX + 6)] / 16) * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 8 * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 8 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 9;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 9;
		}
	}
}
void CMENU::drawMarioRight(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 1;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] / 16) * 16 + 4;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 3 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] / 16) * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 3 * 16 + 5;
		}

	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 15 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 6 * 16 + 3;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 5;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 3 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 5;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 0 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 5;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 15 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 6 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 3 * 16 + 5;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 1;
		}
	}
}
void CMENU::drawMarioLeft(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 1;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = 1 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 15 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 6 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 3 * 16 + 5;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 0 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] / 16) * 16 + 5;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 3 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 5;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 15 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 6 * 16 + 3;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 5;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 3 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] / 16) * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 3 * 16 + 5;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] / 16) * 16 + 4;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 1;
		}
	}
}
CMENU::~CMENU()
{
	for (int i = 0; i < fileDataList.size(); i++)
	{
		if (fileDataList[i] != NULL)
		{
			delete fileDataList[i];
			fileDataList[i] = NULL;
		}
	}
}




































