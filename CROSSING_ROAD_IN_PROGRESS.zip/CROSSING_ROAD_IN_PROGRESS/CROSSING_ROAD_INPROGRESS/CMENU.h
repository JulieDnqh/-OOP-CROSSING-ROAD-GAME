#pragma once
#include <fstream>
#include <string>
#include <vector>
#include <cstdio>
#include "CGRAPHIC.h"
#include "CLETTER.h"
#include <cstdio>
#include <thread>
#include <utility>
#include <algorithm>

using namespace std;

class CGAME;
struct FileData
{
	string fileName;
	bool mode;
	int numOfPlayers;
	int level;

	vector<string> namePlayer;
	vector<int> scorePlayer;
	vector<int>kindCharPlayer;
};
struct RankData
{
	string name;
	int score;
	int kindCharacter;
};

class CMENU
{
	vector<FileData*> fileDataList;
	vector <RankData> rankDataList;
	CGAME* game;
	void (CMENU::* selectBoard)(int nSelect);
	friend class CGAME;

	bool isGameRun;
	bool isExit;
	int curNSelect;

	int indexFirstFile;
	int nSelectFile;
	int nSelectButton;

	bool bgMusic;
	bool sound;
	bool bgroundMotion;
	const wchar_t* const arrSound[10] = { L"open button_sound.wav type mpegvideo alias wav",
									L"open typing_sound.wav type mpegvideo alias wav",
									L"open levelup_sound.wav type mpegvideo alias wav",
									L"open bonus_sound.wav type mpegvideo alias wav",
									L"open hitbyacar_sound.wav type mpegvideo alias wav",
									L"open fallriver_sound.wav type mpegvideo alias wav",
									L"open gameover_sound.wav type mpegvideo alias wav",
									L"open outro_sound.wav type mpegvideo alias wav",
									L"open charmoving_sound.wav type mpegvideo alias wav"
									};

	
	

	CMENU();
	CMENU(CGAME* g);
	void setGame(CGAME* g);
	void control();//nhan input tu nguoi choi va hien thi cac trang phu hop, va nhan input de khoi tao tro choi


	void setDrawSelectBoard(void(CMENU::* selectBoard)(int nSelect));
	void drawSelectBoard(int nSelect);

	//Cac ham lien quan den giao dien trang chu va xu ly input nguoi choi o trang chu
	void menuBackground(int selected, int switchMenu = 1);
	void backgroundMotion();
	void menuSelectBoard(int nSelect);
	int menu(int firstOption);

	//Cac ham lien quan den giao dien trang new game va nhan input tu nguoi choi de setup game
	int selectMode(int firstOption);
	void selectModeBoard(int nSelect);
	int selectNumOfPlayers(int firstOption);
	void selectNumPlayerBoard(int nSelect);
	pair<int, bool>selectMainChar(int firstSelect);
	void drawMainCharPic(int selectMain, int fromX, int fromY);
	void selectMainBoard1(int nSelect);
	void selectMainBoard2(int nSelect);
	bool enterName();
	int enterNameForEach(int index);
	void enterNameBoard(int nSelectBoard);
	void newGame(int& userChoice, int& mode, int& preMode, int& chooseNumOfPlayers, int& preNumOfPlayers, pair<int, bool>& selectMain, pair<int, bool>& preSelectMain, int& fileIndex, int& preFileIndex);
	
	//Cac ham lien quan den load game va xu ly file, va cung cap giao dien cho trang load game
	int checkNameFile(string name, int index = -1);
	pair<int, int> selectFileAndOption(int select, int indexFirstFile, int selectFile);
	void selectBoardFile(int nSelect = 0);
	int enterNameFile(int fromX, int fromY, int colorSpace, int fileIndex);
	int enterNameForNewFile(string& name, int fromX, int fromY);
	bool enterNewFileName(string& name);
	void enterFileNameBoard(int fileIndex);
	int renameFile(int fileIndex);
	int deleteFile(int fileIndex);
	void fileHandle(int& fileIndex, int select, bool& restart);
	void drawBlankPage(int nSelect = 0);
	void drawLoadPage(int nSelect = 0);
	void loadGame(int& userChoice, int& mode, int& chooseNumOfPlayers);
	void addGameFile(FileData* fd);
	vector<string> getVectorFileName();
	
	//Cac ham lien quan den xep hang nguoi choi theo diem so va luu du lieu file rank
	bool checkNameRank(string name);
	void addFileRank(string name, int score, int kindMainChar);
	void drawRankPage(int nSelect = 0);
	void rankPage();
	
	//help page
	void drawHelpPage(int nSelect = 0);
	void helpPage();

	//about page
	void drawAboutPage(int nSelect = 0);
	void aboutPage();

	//play sound va setting page
	void playSound(int id);
	void drawSettingPage(int nSelect = 0);
	void settingPage();

	//Exit page
	bool confirmExit();
	void drawConfirmExit(int nSelect);
	
	
	bool askForRestart();
	void drawAskForResume(int nSelect);
	bool askForResume();
	
	//Cac ham ve cac thanh phan co trong giao dien
	void drawButton(int fromX, int fromY, int c);
	void drawPlayButton(int fromX, int fromY, int c);
	void drawLoadGameButton(int fromX, int fromY, int c);
	void drawRankButton(int fromX, int fromY, int c);
	void drawHelpButton(int fromX, int fromY, int c);
	void drawAboutButton(int fromX, int fromY, int c);
	void drawSettingButton(int fromX, int fromY, int c);
	void drawExitButton(int fromX, int fromY, int c);
	void drawHomeButton(int fromX, int fromY, int c);
	void drawRenameButton(int fromX, int fromY, int c);
	void drawDeleteButton(int fromX, int fromY, int c);
	void drawBackButton(int fromX, int fromY, int c);
	void drawTickButton(int fromX, int fromY, int c);
	void drawCrossButton(int fromX, int fromY, int c);
	
	void drawTitleFrame(int fromX, int fromY, int width, int height, int color);
	void drawMedalPlatform(int fromX, int fromY);

	void drawRoad(int fromX, int fromY);
	void drawRoadLane(int fromY);
	void drawGrass(int fromX, int fromY);
	void drawGrassLane(int fromY);
	void drawWaterLane(int fromY);
	void drawSky(int fromY, int toY);
	
	void drawLiliPad(int fromX, int fromY);
	void drawOrange(int fromX, int fromY);
	void drawCloud(int fromX, int fromY);
	void drawStar(int fromX, int fromY);
	
	void drawRegCarLeft(int fromX, int fromY, int c);
	void drawRoadsterLeft(int fromX, int fromY, int c);
	void drawTruckLeft(int fromX, int fromY, int head, int body);
	void drawPoliceLeft(int fromX, int fromY);
	
	void drawPikachuRight(int fromX, int fromY);
	void drawKirbyRight(int fromX, int fromY);
	void drawMarioRight(int fromX, int fromY);
	void drawMarioLeft(int fromX, int fromY);
	
	~CMENU();	
	
public:


};

