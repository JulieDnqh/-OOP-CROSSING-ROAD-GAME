#include "COBJECT.h"


COBJECT& COBJECT::operator=(const COBJECT& object)
{
    if (this != &object) {
        *this = object;
    }
    return *this;
}

int COBJECT::getWidth()
{
    return width;
}

int COBJECT::getHeight()
{
    return height;
}

int COBJECT::getObjectKind()
{
    return objectKind;
}

short COBJECT::getX()
{
    return pos.X;
}

short COBJECT::getY()
{
    return pos.Y;
}

COORD COBJECT::getPos()
{
    return pos;
}


void COBJECT::setX(short x)
{
    pos.X = x;
}

void COBJECT::setY(short y)
{
    pos.Y = y;
}



void COBJECT::setWidth(int width)
{
    if (width > 0) {
        this->width = width;
    }
}

void COBJECT::setHeight(int height)
{
    if (height > 0) {
        this->height = height;
    }
}

void COBJECT::setSize(int width, int height)
{
    setWidth(width);
    setHeight(height);
}



void COBJECT::setCoord(COORD point)
{
    if (point.X < NSCREENWIDTH && point.Y < NSCREENHEIGHT) {
        pos = point;
    }
}




