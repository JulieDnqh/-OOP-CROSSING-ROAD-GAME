#pragma once
#include <fstream>
#ifndef _COBJECT_H
#define _COBJECT_H
#include "CGRAPHIC.h"

#define WIDTH_MARIO 8
#define HEIGHT_MARIO 4

#define WIDTH_KIR 8 
#define HEIGHT_KIR 4

#define WIDTH_PIKACHU 8
#define HEIGHT_PIKACHU 4

using namespace std;
class COBJECT
{
protected:
	int width, height;
	//0 la player, 1 vehicle, 2 la bouy, 3 la item
	int objectKind;
	COORD pos;
public:
	//co can constructor hay ko?

	COBJECT& operator=(const COBJECT& object);

	//sua lai
	int getWidth();
	int getHeight();
	int getObjectKind();
	short getX();
	short getY();
	COORD getPos();
	void setX(short x);
	virtual void setY(short y);

	void setWidth(int width);
	void setHeight(int height);
	void setSize(int width, int height);
	

	//void setObjectKind(int kind);

	virtual void setCoord(COORD point);

	virtual void draw() = 0;
	virtual void saveObject(ofstream& f) = 0;
	virtual ~COBJECT() {};
	//virtual COBJECT* loadObject(ifstream& f);
	//ham phat tieng keu cua con vat
	//virtual void tell();


};

#endif // !_CANIMAL_H



