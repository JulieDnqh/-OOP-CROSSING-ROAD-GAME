﻿#include "CPLAYER.h"

//static const vector<char> key = { 'W', 'A', 'S', 'D', 32, 'U', 27, 38, 37, 40, 39, 13, 'U', 27 };
static bool bKey[14];

void CPLAYER::setKey()
{
	if (index == 0)
		key = { 'W', 'A', 'S', 'D', 32, 'U', 27, 38, 37, 40, 39, 13, 'U', 27 };
	else if (index == 1)
		key = { 'W', 'A', 'S', 'D', 32, 'U', 27 };
	else
		key = { 38, 37, 40, 39, 13, 'U', 27 };
}

CPLAYER::CPLAYER()
{
	index = 0;
	jumpUnit = 5;
	height = HEIGHT_PIKACHU;
	width = WIDTH_PIKACHU;
	score = 0;
	name = string{};
	kindCharacter = 1;
	COORD startPoint{};
	startPoint.X = NSCREENWIDTH / 2 -  WIDTH_PIKACHU/2;
	startPoint.Y = NSCREENHEIGHT / 2 + 15;
	pos = startPoint;
	objectKind = 0;
	//setDrawMain(&CPLAYER::drawRight);
	setDrawMain(&CPLAYER::drawPikachuRight);
	setDrawRight(&CPLAYER::drawPikachuRight);
	setDrawLeft(&CPLAYER::drawPikachuLeft);
	setKey();

}

CPLAYER::CPLAYER(int index, int x)
{
	this->index = index;
	jumpUnit = 5;
	height = HEIGHT_PIKACHU;
	width = WIDTH_PIKACHU;
	COORD startPoint{};
	startPoint.X = x;
	startPoint.Y = NSCREENHEIGHT / 2 + 15;
	pos = startPoint;
	objectKind = 0;
	score = 0;
	name = string{};
	kindCharacter = 1;
	setDrawMain(&CPLAYER::drawPikachuRight);
	setDrawRight(&CPLAYER::drawPikachuRight);
	setDrawLeft(&CPLAYER::drawPikachuLeft);
	setKey();

}

void CPLAYER::setIndex(int index)
{
	if (index > 2)
		index = 2;
	if (index < 0)
		index = 0;
	this->index = index;
	setKey();

}

void CPLAYER::setY(short y)
{
	if (y + height - 1 < NSCREENHEIGHT)
		pos.Y = y;
}
void CPLAYER::setJumpUnit(int jump)
{
	jumpUnit = jump;
}
int CPLAYER::getJumpUnit()
{
	return jumpUnit;
}
int CPLAYER::getScore()
{
	return score;
}
string CPLAYER::getName()
{
	return name;
}
int CPLAYER::getKindChar()
{
	return kindCharacter;
}

void CPLAYER::drawRight()
{
	(this->*drawR)();
}

void CPLAYER::drawLeft()
{
	(this->*drawL)();
	
}
void CPLAYER::drawDead()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X - height * 2 + width, fromY = pos.Y + height - width/2 + 2;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY) * nScreenWidth + (fromX)] = (pColor[(fromY)*nScreenWidth + (fromX)]/16) * 16 + 0;
		}
		if(fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + 0;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3)*nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 0;
		}
	}


	//col 2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 6 * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 2)]/16) * 16 + 6;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 6 * 16 + 6;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 6 * 16 + 7;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] / 16) * 16 + 6;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 0 * 16 + 6;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 6 * 16 + 0;
		}
	}

	
	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY) * nScreenWidth + (fromX + 4)] = 7 * 16 + 7;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] / 16) * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 6 * 16 + 6;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 6 * 16 + 7;
		}
	}
	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = (pColor[(fromY)*nScreenWidth + (fromX + 5)]/16) * 16 + 7;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 0 * 16 + 6;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 6 * 16 + 6;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 7;
		}
	}
	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = pColor[(fromY)*nScreenWidth + (fromX + 6)] * 16/16 + 7;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 6 * 16 + 7;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 6;
		}
	}
	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 6 * 16 + 7;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] =  9* 16 + 9;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 6;
		}
	}
}
void CPLAYER::drawDeadInRiver()
{
	if (&CPLAYER::drawLeft == drawMain)
	{
		drawLeft();
	}
	else 
	{
		drawRight();
	}
	int j = pos.Y + height - 1;
	if (j >= 0 && j < NSCREENHEIGHT)
		for (int i = 0; i < width; i++)
		{
			if (pos.X + i >= 0 && pos.X + i < NSCREENWIDTH)
			{

				pBuffer[j * NSCREENWIDTH + pos.X + i] = L'█';
				pColor[j * NSCREENWIDTH + pos.X + i] = 5 * 16 + 5;
			}
		}

}
void CPLAYER::setDrawMain(void(CPLAYER::* draw)())
{
	drawMain = draw;
}
void CPLAYER::setKindChar(int kindCharacter)
{
	this->kindCharacter = kindCharacter;
	switch (kindCharacter)
	{
	case 1:
	{
		setDrawLeft(&CPLAYER::drawPikachuLeft);
		setDrawRight(&CPLAYER::drawPikachuRight);

		break;
	}
	case 2:
	{
		setDrawLeft(&CPLAYER::drawKirbyLeft);
		setDrawRight(&CPLAYER::drawKirbyRight);

		break;
	}
	case 3:
	{
		setDrawLeft(&CPLAYER::drawMarioLeft);
		setDrawRight(&CPLAYER::drawMarioRight);

		break;
	}
	}
	setDrawMain(drawR);
}
void CPLAYER::saveObject(ofstream &f)
{
	

	f.write((char*)&width, sizeof(width));
	f.write((char*)&height, sizeof(height));
	f.write((char*)&pos.X, sizeof(pos.X));
	f.write((char*)&pos.Y, sizeof(pos.Y));
	f.write((char*)&jumpUnit, sizeof(jumpUnit));
	f.write((char*)&index, sizeof(index));
	f.write((char*)&kindCharacter, sizeof(kindCharacter));
	f.write((char*)&this->score, sizeof(score));

	//luu ten
	int len = this->name.length();
	f.write(reinterpret_cast<const char*>(&len), sizeof(int));
	const char* nameTemp = this->name.c_str();
	f.write(nameTemp, len);

	name = this->name;
	score = this->score;

	

}
void CPLAYER::loadPlayer(ifstream& f)
{
	f.read((char*)&width, sizeof(width));
	f.read((char*)&height, sizeof(height));
	f.read((char*)&pos.X, sizeof(pos.X));
	f.read((char*)&pos.Y, sizeof(pos.Y));
	f.read((char*)&jumpUnit, sizeof(jumpUnit));
	f.read((char*)&index, sizeof(index));
	setIndex(index);
	f.read((char*)&kindCharacter, sizeof(kindCharacter));
	f.read((char*)&score, sizeof(score));

	setKindChar(kindCharacter);
	//load ten
	int len{};
	f.read(reinterpret_cast<char*>(&len), sizeof(int));

	char* nameTemp = new char[len + 1];
	f.read(nameTemp, len);
	nameTemp[len] = '\0';

	name.resize(len);
	for (int i = 0; i < name.size(); i++) {
		name[i] = nameTemp[i];
	}
}
void CPLAYER::setName(string name)
{
	this->name = name;
}

void CPLAYER::draw()
{
	(this->*drawMain)();
}
void CPLAYER::movingSound()
{
	mciSendString(L"close wav", NULL, 0, NULL);	//need to close first
	mciSendString(L"open button_sound.wav type mpegvideo alias wav", NULL, 0, NULL);
	mciSendString(L"play wav", NULL, 0, NULL);
}
bool CPLAYER::move(int gameMode, bool sound)
{
	int width = getWidth(), height = getHeight();

	for (int i = 0; i < key.size(); i++) {
		if (bKey[i] = GetAsyncKeyState(key[i]) < 0)
		{
			while (bKey[i])
			{
				bKey[i] = GetAsyncKeyState(key[i]) < 0;
			}
			bKey[i] = true;
		}
	}
	thread clickSound;
	if (index == 0)
	{
		//up
		if (bKey[0] || bKey[7]) {
			if (clickSound.joinable())
				clickSound.join();
			if (sound)
			{
				clickSound = thread(&CPLAYER::movingSound, this);
			}
			
			setY(pos.Y - jumpUnit);
			draw();
			if (clickSound.joinable())
				clickSound.join();
			return true;
		}

		//left
		if (bKey[1] || bKey[8]) {
			if (pos.X - jumpUnit * 2 + width - 1 >= 0)
			{
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CPLAYER::movingSound, this);
				}
				setDrawMain(drawL);
				setX(pos.X - jumpUnit * 2);
				draw();
				if (clickSound.joinable())
					clickSound.join();
				return true;
			}
		}

		//down 
		if (gameMode == 0) //mode basic moi duoc di lui
		{
			if (bKey[2] || bKey[9]) {
				if (pos.Y + jumpUnit < NSCREENHEIGHT)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CPLAYER::movingSound, this);
					}
					setY(pos.Y + jumpUnit);
					draw();
					if (clickSound.joinable())
						clickSound.join();
					return true;
				}
			}
		}

		//right
		if (bKey[3] || bKey[10]) {
			if (pos.X + jumpUnit * 2 < NSCREENWIDTH)
			{
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CPLAYER::movingSound, this);
				}
				setDrawMain(drawR);
				setX(pos.X + jumpUnit * 2);
				draw();
				if (clickSound.joinable())
					clickSound.join();
				return true;
			}
		}
	}
	else
	{
	//	//up
		if (bKey[0]) {

			/*if (pos.Y - jumpUnit + height - 1 >= 0)
			* 
			{*/ if (clickSound.joinable())
				clickSound.join();
				if (sound)
				{
					clickSound = thread(&CPLAYER::movingSound, this);
				}
				setY(pos.Y - jumpUnit);
				draw();
				if (clickSound.joinable())
					clickSound.join();
				return true;
			//}
		}

		//left
		if (bKey[1]) {
			if (pos.X - jumpUnit * 2 + width - 1 >= 0)
			{
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CPLAYER::movingSound, this);
				}
				setDrawMain(&CPLAYER::drawLeft);
				setX(pos.X - jumpUnit * 2);
				draw();
				if (clickSound.joinable())
					clickSound.join();
				return true;
			}
		}

		//down 
		if (gameMode == 0)
		{
			if (bKey[2]) {
				if (pos.Y + jumpUnit < NSCREENHEIGHT)
				{
					if (clickSound.joinable())
						clickSound.join();
					if (sound)
					{
						clickSound = thread(&CPLAYER::movingSound, this);
					}
					setY(pos.Y + jumpUnit);
					draw();
					if (clickSound.joinable())
						clickSound.join();
					return true;
				}
			}
		}

		//right
		if (bKey[3]) {
			if (pos.X + jumpUnit * 2 < NSCREENWIDTH)
			{
				if (clickSound.joinable())
					clickSound.join();
				if (sound)
				{
					clickSound = thread(&CPLAYER::movingSound, this);
				}
				setDrawMain(&CPLAYER::drawRight);
				setX(pos.X + jumpUnit * 2);
				draw();
				if (clickSound.joinable())
					clickSound.join();
				return true;
			}
		}
	}
	return false;
}

void CPLAYER::plusScore(int plusScore)
{
	this->score += plusScore;
}

void CPLAYER::setDrawRight(void (CPLAYER::* drawR)())
{
	this->drawR = drawR;
}
void CPLAYER::setDrawLeft(void (CPLAYER::* drawL)())
{
	this->drawL = drawL;
}
void CPLAYER::drawPikachuRight()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X, fromY = pos.Y;

	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 0;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] / 16) * 16 + 7;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 7 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] / 16) * 16 + 7;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 6 * 16 + 0;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 6 * 16 + 6;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + 7;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 6 * 16 + 6;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 6 * 16 + 4;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 7 * 16 + 7;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 6 * 16 + 0;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 6 * 16 + 3;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 6 * 16 + 6;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 7 * 16 + 3;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 6 * 16 + 6;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 6 * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 6 * 16 + 7;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = 7 * 16 + 0;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 7 * 16 + 0;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + 7;
		}
	}
}
void CPLAYER::drawPikachuLeft()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X, fromY = pos.Y;
	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + 7;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + 7;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{

		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = (pColor[(fromY)*nScreenWidth + (fromX + 6)] / 16) * 16 + 0;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + 7;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 7 * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 7;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 6 * 16 + 0;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 6 * 16 + 6;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + 7;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 6 * 16 + 6;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 6 * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 7 * 16 + 7;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 6 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 6 * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 6 * 16 + 3;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 6 * 16 + 6;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 6 * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 7 * 16 + 3;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 6 * 16 + 6;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 6 * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 6 * 16 + 7;
		}
	}

	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
	}
}
void CPLAYER::drawKirbyRight()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X, fromY = pos.Y;
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 4;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 4 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] / 16) * 16 + 4;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 8 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 8 * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 8 * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] / 16) * 16 + 4;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 1 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 8 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 8 * 16 + 8;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 4;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 8 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 8 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 4;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 8 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 8 * 16 + 8;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 9;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = (pColor[(fromY)*nScreenWidth + (fromX + 6)] / 16) * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 8 * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 8 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 9;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 9;
		}
	}
}
void CPLAYER::drawKirbyLeft()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X, fromY = pos.Y;
	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] / 16) * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 4;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = (pColor[(fromY)*nScreenWidth + (fromX + 6)] / 16) * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 4 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] / 16) * 16 + 4;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 8 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 8 * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 8 * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 4;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 1 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 8 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 8 * 16 + 8;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 4;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 8 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 8 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 4;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 1 * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 8 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 8 * 16 + 8;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] / 16) * 16 + 9;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = (pColor[(fromY)*nScreenWidth + (fromX + 1)] / 16) * 16 + 8;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 8 * 16 + 4;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 8 * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] / 16) * 16 + 9;
		}
	}

	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = 8 * 16 + 8;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 9;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 9;
		}
	}
}
void CPLAYER::drawMarioRight()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X, fromY = pos.Y;
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 1;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] / 16) * 16 + 4;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 3 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] / 16) * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 3 * 16 + 5;
		}

	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 15 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 6 * 16 + 3;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 5;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 3 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 5;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 0 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] / 16) * 16 + 5;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 15 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 6 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 3 * 16 + 5;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 1;
		}
	}
}
void CPLAYER::drawMarioLeft()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromX = pos.X, fromY = pos.Y;
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX)] = (pColor[(fromY + 1) * nScreenWidth + (fromX)] / 16) * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = (pColor[(fromY + 3) * nScreenWidth + (fromX)] / 16) * 16 + 1;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 1)] = 1 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 15 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 6 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 3 * 16 + 5;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 2)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 2)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 0 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] / 16) * 16 + 5;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 3 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 5 * 16 + 15;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] / 16) * 16 + 5;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH) {
		if (fromY >= 0 && fromY < NSCREENHEIGHT) {
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 4 * 16 + 4;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 15 * 16 + 15;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 6 * 16 + 3;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] / 16) * 16 + 5;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH) {
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'█';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 3 * 16 + 3;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] / 16) * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 3 * 16 + 5;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH) {
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT) {
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] / 16) * 16 + 4;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH) {
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT) {
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] / 16) * 16 + 1;
		}
	}
}

CPLAYER::~CPLAYER()
{
	//delete (CPLAYER::*drawMain)();
}
