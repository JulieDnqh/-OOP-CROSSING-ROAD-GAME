﻿#pragma once
#include <thread>
#include "COBJECT.h"
class CPLAYER :public COBJECT
{
	int jumpUnit;
	int index;

	string name;
	int score;
	
	int kindCharacter;
	void (CPLAYER::* drawMain)();
	void (CPLAYER::* drawR)();
	void (CPLAYER::* drawL)();
	vector<char> key;

	void setKey();
	void drawLeft();

	void setDrawRight(void (CPLAYER::* drawR)());
	void setDrawLeft(void (CPLAYER::* drawL)());
	void drawPikachuRight();
	void drawPikachuLeft();
	void drawKirbyRight();
	void drawKirbyLeft();
	void drawMarioRight();
	void drawMarioLeft();
	void movingSound();
public:
	CPLAYER();
	CPLAYER(int index, int x);

	void drawRight();
	void drawDead();
	void drawDeadInRiver();

	void setIndex(int index);
	void setY(short y);
	void setJumpUnit(int jump);


	int getJumpUnit();
	int getScore();
	string getName();
	int getKindChar();

	void draw();
	bool move(int gameMode, bool sound);
	void plusScore(int plusScore);

	void setDrawMain(void (CPLAYER::* draw)());
	void setKindChar(int kindCharacter);

	void saveObject(ofstream &f);
	void loadPlayer(ifstream& f);

	void setName(string name);
	

	~CPLAYER();

};

