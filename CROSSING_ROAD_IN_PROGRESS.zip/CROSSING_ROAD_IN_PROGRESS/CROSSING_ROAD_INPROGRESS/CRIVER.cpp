﻿#include "CRIVER.h"

CRIVER::CRIVER()
{
	kind = 2;
	pos = 0;
	width = 8;
	numOfObs = 0;
	distanceBetObs = 50;
	motionSpeed = 3;
}

CRIVER::CRIVER(int y)
{
	kind = 2;
	pos = y;
	width = 8;
	firstObsPos = 5;
	distanceBetObs = 50;
	motionSpeed = 3;
}

CRIVER::CRIVER(int y, int numObs)
{
	kind = 2;
	pos = y;
	width = 8;
	numOfObs = numObs;
	firstObsPos = 5;
	distanceBetObs = NSCREENWIDTH / numOfObs;
	motionSpeed = 3;
}

CRIVER::CRIVER(int y, int numObs, int distance)
{
	kind = 2;
	pos = y;
	width = 8;
	numOfObs = numObs;
	firstObsPos = 5;
	this->distanceBetObs = distanceBetObs;
	motionSpeed = 3;
}

int CRIVER::checkCollision(CPLAYER* player)
{
	
	if (player->getY() + player->getHeight() - 1 > pos + width - 1)
		return -1;
	int check = 0;
	COBJECT* bouy = findMain(player->getPos(), player->getWidth(), player->getHeight());
	if (bouy != NULL)
	{
		check = -1;
		int newY = pos - player->getHeight() + player->getJumpUnit();
		if (newY + player->getHeight() - 1 > bouy->getY() + bouy->getWidth() - 1)
			newY = bouy->getY() + bouy->getWidth() - player->getHeight();
		player->setY(newY);
		if (runObs == true)
		{
				player->setX(bouy->getX() + bouy->getWidth() / 2 - player[0].getWidth() / 2 + motionSpeed);
		}
		else
		{
				player->setX(bouy->getX() + bouy->getWidth() / 2 - player[0].getWidth() / 2);
		}

	}
	
	if (check !=-1)
	{
		if (player->getY() + player->getHeight() - 1 < pos + width)
		{
			player->setDrawMain(&CPLAYER::drawDeadInRiver);
		}
	}
	
	
	return check;
}
COBJECT* CRIVER::findMain(COORD playerPos, int playerWidth, int playerHeight)
{
	COORD point1, point2, point3, point4;
	point1.X = playerPos.X;
	point1.Y = playerPos.Y;
	point2.X = point1.X + short(playerWidth) - 1;
	point2.Y = point1.Y;
	point3.X = point2.X;
	point3.Y = point1.Y + short(playerHeight) - 1;
	point4.X = point1.X;
	point4.Y = point3.Y;
	for (int i = 0; i < obstacle.size(); i++)
	{
		int x1 = obstacle[i]->getX(), x2 = x1 + obstacle[i]->getWidth() - 1;
		int y1 = obstacle[i]->getY(), y2 = y1 + obstacle[i]->getHeight() - 1;
		if (point1.X >= x1 && point1.X <= x2 && point1.Y >= y1 && point1.Y <= y2)
		{
			return obstacle[i];
		}
		else if (point2.X >= x1 && point2.X <= x2 && point2.Y >= y1 && point2.Y <= y2)
		{
			return obstacle[i];
		}
		else if (point3.X >= x1 && point3.X <= x2 && point3.Y >= y1 && point3.Y <= y2)
		{
			return obstacle[i];
		}
		else if (point4.X >= x1 && point4.X <= x2 && point4.Y >= y1 && point4.Y <= y2)
		{
			return obstacle[i];
		}
	}
	return nullptr;
}
void CRIVER::draw()
{
	int nScreenWidth = NSCREENWIDTH;
	int fromY = pos;

	for (int i = 0; i < nScreenWidth; i++)
	{
		for (int j = fromY; j <= fromY + 7; j++)
		{
			if (j >= 0 && j < NSCREENHEIGHT)
			{
				pBuffer[j * nScreenWidth + i] = L' ';
				pColor[j * nScreenWidth + i] = 5 * 16 + 5;
			}
		}
	}
	if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
	{
		for (int i = 2; i < nScreenWidth; i = i + 32) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 2) * nScreenWidth + i] = L'▀';
				pColor[(fromY + 2) * nScreenWidth + i] = 5 * 16 + 1;
			}
			if (i + 1 >= 0 && i + 1 < NSCREENWIDTH)
			{
				pBuffer[(fromY + 2) * nScreenWidth + (i + 1)] = L'▄';
				pColor[(fromY + 2) * nScreenWidth + (i + 1)] = 5 * 16 + 1;
			}

			if (i + 2 >= 0 && i + 2 < NSCREENWIDTH)
			{
				pBuffer[(fromY + 2) * nScreenWidth + (i + 2)] = L'▀';
				pColor[(fromY + 2) * nScreenWidth + (i + 2)] = 5 * 16 + 1;
			}
		}
	}

	if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
	{
		for (int i = 20; i < nScreenWidth; i = i + 32) {
			if (i - 1 >= 0 && i - 1 < NSCREENWIDTH)
			{
				pBuffer[(fromY + 5) * nScreenWidth + (i - 1)] = L'▄';
				pColor[(fromY + 5) * nScreenWidth + (i - 1)] = 5 * 16 + 1;
			}
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 5) * nScreenWidth + i] = L'▀';
				pColor[(fromY + 5) * nScreenWidth + i] = 5 * 16 + 1;
			}
			if (i + 1 >= 0 && i + 1 < NSCREENWIDTH)
			{
				pBuffer[(fromY + 5) * nScreenWidth + (i + 1)] = L'▄';
				pColor[(fromY + 5) * nScreenWidth + (i + 1)] = 5 * 16 + 1;
			}

		}
	}
	for (int i = 0; i < obstacle.size(); i++)
	{
		obstacle[i]->draw();
	}

	for (int i = 0; i < item.size(); i++) {
		item[i]->draw();
	}
	
}
