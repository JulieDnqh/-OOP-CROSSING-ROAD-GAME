#pragma once
#include "CLANE.h"
class CRIVER:public CLANE
{
	//void setShape();
public:
	CRIVER();
	CRIVER(int y);
	CRIVER(int y, int numObs);
	CRIVER(int y, int numObs, int distance);
	int checkCollision(CPLAYER* player);
	COBJECT* findMain(COORD playerPos, int playerWidth, int playerHeight);
	void draw();
};

