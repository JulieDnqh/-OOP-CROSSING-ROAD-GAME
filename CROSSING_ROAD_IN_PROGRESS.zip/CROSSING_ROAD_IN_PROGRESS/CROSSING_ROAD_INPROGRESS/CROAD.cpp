﻿#include "CROAD.h"

void CROAD::setPattern(int fromX, int fromY)
{
	int nScreenWidth = NSCREENWIDTH;
	//row 1
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		for (int i = fromX; i <= fromX + 7; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY)*nScreenWidth + (i)] = L'▄';
				pColor[(fromY)*nScreenWidth + (i)] = 2 * 16 + 1;
			}
		}
	}

	//row 2
	if (fromY + 1>= 0 && fromY + 1 < NSCREENHEIGHT)
	{
		for (int i = fromX; i <= fromX + 7; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 1) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 1) * nScreenWidth + (i)] = 2 * 16 + 2;
			}
		}
	}

	//row 3
	if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
	{
		for (int i = fromX; i <= fromX + 7; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 2) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 2) * nScreenWidth + (i)] = 2 * 16 + 2;
			}
		}
	}

	//row 4
	if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 2 * 16 + 2;
		}
		if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 2 * 16 + 2;
		}

		for (int i = fromX + 2; i <= fromX + 5; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 3) * nScreenWidth + (i)] = L'▄';
				pColor[(fromY + 3) * nScreenWidth + (i)] = 2 * 16 + 1;
			}
		}

		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 2 * 16 + 2;
		}
		if (fromX  + 7>= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 2 * 16 + 2;
		}
	}

	//row 5
	if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
	{
		if (fromX >= 0 && fromX < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = 2 * 16 + 2;
		}
		if (fromX + 1>= 0 && fromX + 1 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = 2 * 16 + 2;
		}


		for (int i = fromX + 2; i <=fromX + 5; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 4) * nScreenWidth + (i)] = L'▀';
				pColor[(fromY + 4) * nScreenWidth + (i)] = 2 * 16 + 1;
			}
		}

		if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 2 * 16 + 2;
		}
		if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 2 * 16 + 2;
		}
	}
	//row 6
	if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
	{
		for (int i = fromX; i <=fromX + 7; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 5) * nScreenWidth + (i)] = L' ';
				pColor[(fromY + 5) * nScreenWidth + (i)] = 2 * 16 + 2;
			}
		}
	}

	//row 7
	if (fromY + 6 >= 0 && fromY + 6 < NSCREENHEIGHT)
	{
		for (int i = fromX; i <= fromX + 7; i++) {
			pBuffer[(fromY + 6) * nScreenWidth + (i)] = L' ';
			pColor[(fromY + 6) * nScreenWidth + (i)] = 2 * 16 + 2;
		}
	}

	//row 8
	if (fromY + 7 >= 0 && fromY + 7 < NSCREENHEIGHT)
	{
		for (int i = fromX; i <= fromX + 7; i++) {
			if (i >= 0 && i < NSCREENWIDTH)
			{
				pBuffer[(fromY + 7) * nScreenWidth + (i)] = L'▀';
				pColor[(fromY + 7) * nScreenWidth + (i)] = 2 * 16 + 1;
			}
		}
	}
}


void CROAD::drawTrafficLight(int color)
{
	int fromY = pos;
	int fromX;
	int nScreenWidth = NSCREENWIDTH;
	if (direction == 0)
	{
		fromX = NSCREENWIDTH - 9;
	}
	else
	{
		fromX = 2;
	}

		//row 1
	if (fromY >= 0 && fromY < NSCREENHEIGHT)
	{
		for (int i = 0; i <= 6; i++) {
			if (fromX + i >= 0 && fromX + i < NSCREENWIDTH)
			{
				pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'▄';
				pColor[(fromY)*nScreenWidth + (fromX + i)] = (pColor[(fromY)*nScreenWidth + (fromX + i)] / 16) * 16 + 0;
			}
		}
	}

	//row 2

	if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
	{
		
		pBuffer[(fromY + 1) * nScreenWidth + (fromX)] = L' ';
		pColor[(fromY + 1) * nScreenWidth + (fromX)] = 0 * 16 + 0;
		
		
		if (color == 4) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 0 * 16 + 4;
		}
		else {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = 0 * 16 + 14;

		}
	
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 0 * 16 + 0;

		if (color == 7) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 0 * 16 + 7;
		}
		else {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 0 * 16 + 0;
		if (color == 11) {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 0 * 16 + 11;
		}
		else {
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 0 * 16 + 14;
		}
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
		pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 0 * 16 + 0;
	}
}

void CROAD::trafficLightTurnRed()
{
	drawTrafficLight(4);
}

CROAD::CROAD()
{
	kind = 1;
	pos = 0;
	width = 8;
	numOfObs = 0;
	distanceBetObs = 50;
	motionSpeed = 3;
	waitTime = 0;
}

CROAD::CROAD(int y)
{
	kind = 1;
	pos = y;
	width = 8;
	firstObsPos = 5;
	distanceBetObs = 50;
	motionSpeed = 3;
	waitTime = 0;
}
CROAD::CROAD(int y, int numObs)
{
	kind = 1;
	pos = y;
	width = 8;
	numOfObs = numObs;
	firstObsPos = 5;
	distanceBetObs = NSCREENWIDTH / numOfObs;
	motionSpeed = 3;
	waitTime = 0;
}

CROAD::CROAD(int y, int numObs, int distanceBetObs)
{
	kind = 1;
	pos = y;
	width = 8;
	numOfObs = numObs;
	firstObsPos = 5;
	this->distanceBetObs = distanceBetObs;
	motionSpeed = 3;
	waitTime = 0;
}


void CROAD::draw()
{
	for (int i = 0; i < NSCREENWIDTH; i += 8) {
		setPattern(i, pos);
	}

	for (int i = 0; i < item.size(); i++) {
		item[i]->draw();
	}
	
	for (int i = 0; i < obstacle.size(); i++)
	{
		if (obstacle[i] != NULL)
		{
			obstacle[i]->draw();
		}
	}

	if (waitTime == 0)
		drawTrafficLight(11);
	else
	{
		trafficLightTurnRed();
	}

}

void CROAD::generateTraffictLight(int trafficLightCoef)
{
	
	int  redLight = (rand() % trafficLightCoef);
	if (redLight == 0)
	{
		waitTime = 16;
	}
}

void CROAD::decreaseWaitTime()
{
	if (waitTime > 0)
		waitTime--;
}

int CROAD::getWaitTime()
{
	return waitTime;
}

void CROAD::saveLane(ofstream& f)
{
	f.write((char*)&kind, sizeof(kind));
	f.write((char*)&pos, sizeof(pos));
	f.write((char*)&width, sizeof(width));
	f.write((char*)&firstObsPos, sizeof(firstObsPos));
	f.write((char*)&distanceBetObs, sizeof(distanceBetObs));
	f.write((char*)&motionSpeed, sizeof(motionSpeed));
	f.write((char*)&direction, sizeof(direction));
	f.write((char*)&waitTime, sizeof(waitTime));
	f.write((char*)&numOfObs, sizeof(numOfObs));
	for (int i = 0; i < numOfObs; i++)
	{
		obstacle[i]->saveObject(f);
	}
}
void CROAD::loadLane(ifstream& f)
{
	f.read((char*)&pos, sizeof(pos));
	f.read((char*)&width, sizeof(width));
	f.read((char*)&firstObsPos, sizeof(firstObsPos));
	f.read((char*)&distanceBetObs, sizeof(distanceBetObs));
	f.read((char*)&motionSpeed, sizeof(motionSpeed));
	f.read((char*)&direction, sizeof(direction));
	f.read((char*)&waitTime, sizeof(waitTime));
	f.read((char*)&numOfObs, sizeof(numOfObs));
	for (int i = 0; i < numOfObs; i++)
	{
		int objKind;
		f.read((char*)&objKind, sizeof(objKind));
		//cout << "objKind = " << objKind<< '\n';
		if (objKind == 1)
		{
			COBJECT* obj = new CVEHICLE;
			CVEHICLE* vehicle = dynamic_cast<CVEHICLE*>(obj);
			vehicle->loadVehicle(f, direction);
			this->obstacle.push_back(obj);
		}
		else if (objKind == 2)
		{

			COBJECT* obj = new CBOUY;
			CBOUY* bouy = dynamic_cast<CBOUY*>(obj);
			bouy->loadBouy(f);
			this->obstacle.push_back(obj);
		}
	}
}

void CROAD::setVehicleAttribute(int index, int vehicleKind, int color, int y)
{
	if (index >= 0 && index < obstacle.size())
	{
		CVEHICLE* car = dynamic_cast<CVEHICLE*>(obstacle[index]);
		car->setVehicleKind(vehicleKind, direction);
		car->setColor(color);
		car->setY(y);
	}
}
CROAD:: ~CROAD()
{
	for (int i = 0; i < obstacle.size(); i++)
	{
		if (obstacle[i] != NULL)
		{
			delete obstacle[i];
			obstacle[i] = NULL;
		}
	}
}
