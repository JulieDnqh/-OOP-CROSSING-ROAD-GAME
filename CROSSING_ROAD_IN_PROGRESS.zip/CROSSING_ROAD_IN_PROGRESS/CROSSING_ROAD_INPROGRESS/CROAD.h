#pragma once
#include "CLANE.h"
class CROAD :public CLANE
{
	int waitTime;
	void setPattern(int fromX, int fromY);
	void drawTrafficLight(int color);
	void trafficLightTurnRed();
public:
	CROAD();
	CROAD(int y);
	CROAD(int y, int numObs);
	CROAD(int y, int numObs, int distanceBetObs);
	void draw();
	void generateTraffictLight(int trafficLightCoef);
	void decreaseWaitTime();
	int getWaitTime();
	void saveLane(ofstream& f);
	void loadLane(ifstream& f);
	void setVehicleAttribute(int index, int vehicleKind, int color, int y);
	virtual ~CROAD();
};

