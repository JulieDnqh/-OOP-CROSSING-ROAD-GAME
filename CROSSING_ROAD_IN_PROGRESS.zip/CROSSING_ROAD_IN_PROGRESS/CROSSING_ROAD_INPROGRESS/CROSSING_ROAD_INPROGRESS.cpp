// CROSSING_ROAD_INPROGRESS.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "CGAME.h"

int main()
{
    srand(time(0));
    graphic->configure();
    graphic->setColor(colorBoard[1]);
    CGAME game;
    game.startApp();
    PostMessage(GetConsoleWindow(), WM_CLOSE, 0, 0);
    return 0;
}

