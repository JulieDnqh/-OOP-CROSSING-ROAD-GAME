﻿#include "CVEHICLE.h"

int CVEHICLE::carColor[7] = { 4,4,5,8,11,8,13 };
COORD CVEHICLE::width_height[4] = { {WIDTH_CAR, HEIGHT_CAR}, {WIDTH_CAR, HEIGHT_CAR}, {WIDTH_TRUCK, HEIGHT_TRUCK}, {WIDTH_CAR,HEIGHT_CAR } };


void CVEHICLE::setDraw(void(*drawVehicle)(int fromX, int fromY, int c))
{
	this->drawVehicle = drawVehicle;
}
CVEHICLE::CVEHICLE()
{
	pos.X = 0;
	pos.Y = 0;
	int c = rand() % 7;
	color = carColor[c];
	objectKind = 1;
	setVehicleKind(0,0);
}

void CVEHICLE::setVehicleKind(int kind, bool direction)
{
	this->vehicleKind = kind;
	
	setWidth(width_height[vehicleKind].X);
	setHeight(width_height[vehicleKind].Y);
	
	switch (kind)
	{
	case 0:
	{
		if (direction == 0)
			setDraw(CVEHICLE::drawRegCarRight);
		else setDraw(CVEHICLE::drawRegCarLeft);
		break;
	}
	case 1:
	{
		if (direction == 0)
			setDraw(CVEHICLE::drawRoadsterRight);
		else setDraw(CVEHICLE::drawRoadsterLeft);
		break;
	}
	case 2:
	{
		if (direction == 0)
			setDraw(CVEHICLE::drawTruckRight);
		else setDraw(CVEHICLE::drawTruckLeft);
		break;
	}
	case 3:
	{
		if (direction == 0)
			setDraw(CVEHICLE::drawPoliceRight);
		else setDraw(CVEHICLE::drawPoliceLeft);
		color = 14;
	}
	default:
		break;
	}
}

void CVEHICLE::setColorByIndex(int index)
{
	this->color = carColor[index];
}
void CVEHICLE::setColor(int color)
{
	this->color = color;
}
void CVEHICLE::setNewRandomColor()
{
	int c;
	do
	{
		c = rand() % 7;
	} while (carColor[c] == color);
	setColorByIndex(c);
}

int CVEHICLE::getVehicleKind()
{
	return vehicleKind;
}

void CVEHICLE::draw()
{
	(*drawVehicle)(pos.X, pos.Y, color);
}
void CVEHICLE::saveObject(ofstream& f)
{
	/*int objectKind
	int width
	int height
	int color;
	int vehicleKind;*/
	f.write((char*)&objectKind, sizeof(objectKind));
	f.write((char*)&pos.X, sizeof(pos.X));
	f.write((char*)&pos.Y, sizeof(pos.Y));
	f.write((char*)&width, sizeof(width));
	f.write((char*)&height, sizeof(height));
	f.write((char*)&color, sizeof(color));
	f.write((char*)&vehicleKind, sizeof(vehicleKind));

}
void CVEHICLE::loadVehicle(ifstream& f, bool direction)
{
	
	f.read((char*)&pos.X, sizeof(pos.X));
	f.read((char*)&pos.Y, sizeof(pos.Y));
	f.read((char*)&width, sizeof(width));
	f.read((char*)&height, sizeof(height));
	f.read((char*)&color, sizeof(color));
	f.read((char*)&vehicleKind, sizeof(vehicleKind));
	this->setVehicleKind(vehicleKind, direction);
}

void CVEHICLE::drawRegCarRight(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	
	//col 1
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] / 16) * 16 + 7;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 7 * 16 + 0;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}


	//col 2
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}


	//col 3
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + c;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}


	//col 4
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}
	//col 5
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + c;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] / 16) * 16 + c;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + c;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = (pColor[(fromY)*nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 1;
		}

		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}

		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}

		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}
	//col 10
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}


	//col 11
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = c * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}
	//col 14
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}
	//col 16
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}
	//col 18
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}

	}
	//col 20
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}
}
void CVEHICLE::drawRoadsterRight(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	//col 1
	if (fromX + 19 >= 0 && fromX + 19 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 18 >= 0 && fromX + 18 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 17 >= 0 && fromX + 17 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}
	//col 4
	if (fromX + 16 >= 0 && fromX + 16 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}
	//col 5
	if (fromX + 15 >= 0 && fromX + 15 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}
	//col 6
	if (fromX + 14 >= 0 && fromX + 14 < nScreenWidth)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 13 >= 0 && fromX + 13 < nScreenWidth)
	{
		if (fromY + 1 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}
	//col 8
	if (fromX + 12 >= 0 && fromX + 12 < nScreenWidth)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = (pColor[(fromY)*nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] / 16) * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 11 >= 0 && fromX + 11 < nScreenWidth)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = (pColor[(fromY)*nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] / 16) * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}
	//col 10

	if (fromX + 10 >= 0 && fromX + 10 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 9 >= 0 && fromX + 9 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 8 >= 0 && fromX + 8 < nScreenWidth)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 0 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}
	//col 13
	if (fromX + 7 >= 0 && fromX + 7 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}
	//col 14
	if (fromX + 6 >= 0 && fromX + 6 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}
	//col 15
	if (fromX + 5 >= 0 && fromX + 5 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}
	//col 16
	if (fromX + 4 >= 0 && fromX + 4 < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}
	//col 17
	if (fromX + 3 >= 0 && fromX + 3 < nScreenWidth)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 0 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}
	//col 18
	if (fromX + 2 >= 0 && fromX + 2 < nScreenWidth)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}
	//col 19
	if (fromX + 1 >= 0 && fromX + 1 < nScreenWidth)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}
	//col 20
	if (fromX >= 0 && fromX < nScreenWidth)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}
}
void CVEHICLE::drawTruckRight(int fromX, int fromY, int c)
{

	int nScreenWidth = NSCREENWIDTH;
	int head = c;
	int body;
	if (head == 13)
		body = 8;
	else
	{
		if (head == 8)
			body = 13;
		else if (head == 4)
		{
			body = 11;
		}
		else body = 8;
	}

	//col1
	if (fromX + 20 >= 0 && fromX + 20 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 20)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 20)] = 7 * 16 + 7;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 20)] = L'▄';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 20)] = 0 * 16 + head;
		}
	}

	//col2
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] / 16) * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = head * 16 + head;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = head * 16 + head;
		}
	}
	//col3
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 18)] = head * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = head * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = head * 16 + head;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = 0 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] / 16) * 16 + 0;
		}
	}

	//col4
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 17)] = (pColor[(fromY)*nScreenWidth + (fromX + 17)] / 16) * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 17)] = 0 * 16 + 14;
		}
	}

	//col5
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 16)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}
	//col6
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 15)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}
	//col7
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 14)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = 0 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col8
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		for (int i = 0; i <= 4; i++) {
			if (fromY + i >= 0 && fromY +i < NSCREENHEIGHT)
			{
				pBuffer[(fromY + i) * nScreenWidth + (fromX + 13)] = L' ';
				pColor[(fromY + i) * nScreenWidth + (fromX + 13)] = head * 16 + head;
			}
		}
	}

	//body part
	for (int i = 0; i <= 12; i++) {
		if (fromX + i >= 0 && fromX + i < NSCREENWIDTH)
		{
			for (int j = 0; j <= 4; j++) {
				if (fromY + j >= 0 && fromY + j < NSCREENHEIGHT)
				{
					pBuffer[(fromY + j) * nScreenWidth + (fromX + i)] = L' ';
					pColor[(fromY + j) * nScreenWidth + (fromX + i)] = body * 16 + body;
				}
			}
		}
	}

	//second wheel
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = 0 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 0 * 16 + 14;
		}
	}
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 0 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] / 16) * 16 + 0;
		}
	}

	//back light
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 4 * 16 + 4;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = 0 * 16 + 0;
		}
	}
}
void CVEHICLE::drawPoliceRight(int fromX, int fromY, int c)
{
	c = 14;
	int nScreenWidth = NSCREENWIDTH;
	//col 1
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}
	//col 5
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = (pColor[(fromY)*nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}
	//col 9
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}
	//col 11
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY - 1 >= 0 && fromY - 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY - 1) * nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY - 1) * nScreenWidth + (fromX + 9)] = (pColor[(fromY - 1) * nScreenWidth + (fromX + 9)] / 16) * 16 + 5;
		}
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY - 1 >= 0 && fromY - 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY - 1) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY - 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY - 1) * nScreenWidth + (fromX + 8)] / 16) * 16 + 4;
		}
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = c * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}
	//col 14
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}
	//col 15
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}
	//col 16
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = (pColor[(fromY)*nScreenWidth + (fromX + 4)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}
	//col 17
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}
	//col 19
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}
	//col 20
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}
}


void CVEHICLE::drawRegCarLeft(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 1>= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = c * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 14
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 13)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 14)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 16
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 15)] = (pColor[(fromY)*nScreenWidth + (fromX + 15)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3  < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 20
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}

}
void CVEHICLE::drawRoadsterLeft(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] / 16) * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = (pColor[(fromY)*nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] / 16) * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = 0 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 14
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 16
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 0 * 16 + 0;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 18)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 20
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}

}


void CVEHICLE::drawTruckLeft(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	int head = c;
	int body;
	if (head == 13)
		body = 8;
	else
	{
		if (head == 8)
			body = 13;
		else if (head == 4)
		{
			body = 11;
		}
		else body = 8;
	}
	//col1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 7;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = 0 * 16 + head;
		}
	}

	//col2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] / 16) * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = head * 16 + head;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = head * 16 + head;
		}
	}

	//col3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = head * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = head * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = head * 16 + head;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = 0 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 3)] = (pColor[(fromY)*nScreenWidth + (fromX + 3)] / 16) * 16 + head;
		}

		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 4)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 14 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 0 * 16 + 14;
		}
	}

	//col7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + head;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + head;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 1 * 16 + head;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = head * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 0 * 16 + head;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] / 16) * 16 + 0;
		}
	}

	//col8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{
		for (int i = fromY; i <= fromY + 4; i++) {
			if (i >= 0 && i < NSCREENHEIGHT)
			{
				pBuffer[(i)*nScreenWidth + (fromX + 7)] = L' ';
				pColor[(i)*nScreenWidth + (fromX + 7)] = head * 16 + head;
			}
		}
	}

	//body part
	for (int i = fromX + 8; i <= fromX + 20; i++) {
		if (i >= 0 && i < NSCREENWIDTH)
		{
			for (int j = fromY; j <= fromY + 4; j++) {
				if (j >= 0 && j < NSCREENHEIGHT)
				{
					pBuffer[(j) * nScreenWidth + (i)] = L' ';
					pColor[(j) * nScreenWidth + (i)] = body * 16 + body;
				}
			}
		}
	}

	//second wheel
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = 0 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] / 16) * 16 + 0;
		}
	}

	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 17)] = 0 * 16 + 14;
		}
	}

	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = body * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 14 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = 0 * 16 + 0;
		}
		if (fromY + 5 >= 0 && fromY + 5 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 5) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 5) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] / 16) * 16 + 0;
		}
	}

	//back light
	if (fromX + 20 >= 0 && fromX + 20 < NSCREENWIDTH)
	{
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 20)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 20)] = 4 * 16 + 4;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 20)] = L' ';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 20)] = 0 * 16 + 0;
		}
	}
}
void CVEHICLE::drawPoliceLeft(int fromX, int fromY, int c)
{
	int nScreenWidth = NSCREENWIDTH;
	c = 14;
	//col 1
	if (fromX >= 0 && fromX < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX)] = (pColor[(fromY + 2) * nScreenWidth + (fromX)] / 16) * 16 + 7;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX)] = 7 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX)] = (pColor[(fromY + 4) * nScreenWidth + (fromX)] / 16) * 16 + c;
		}
	}

	//col 2
	if (fromX + 1 >= 0 && fromX + 1 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] / 16) * 16 + c;
		}
	}

	//col 3
	if (fromX + 2 >= 0 && fromX + 2 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] / 16) * 16 + 0;
		}
	}

	//col 4
	if (fromX + 3 >= 0 && fromX + 3 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 0 * 16 + 14;
		}
	}

	//col 5
	if (fromX + 4 >= 0 && fromX + 4 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 0 * 16 + 14;
		}
	}

	//col 6
	if (fromX + 5 >= 0 && fromX + 5 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] / 16) * 16 + 0;
		}
	}

	//col 7
	if (fromX + 6 >= 0 && fromX + 6 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] / 16) * 16 + c;
		}
	}

	//col 8
	if (fromX + 7 >= 0 && fromX + 7 < NSCREENWIDTH)
	{

		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 7)] = (pColor[(fromY)*nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] / 16) * 16 + c;
		}
	}

	//col 9
	if (fromX + 8 >= 0 && fromX + 8 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 8)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] / 16) * 16 + c;
		}
	}

	//col 10
	if (fromX + 9 >= 0 && fromX + 9 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] / 16) * 16 + c;
		}
	}

	//col 11
	if (fromX + 10 >= 0 && fromX + 10 < NSCREENWIDTH)
	{
		if (fromY - 1 >= 0 && fromY - 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY - 1) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY - 1) * nScreenWidth + (fromX + 10)] = (pColor[(fromY - 1) * nScreenWidth + (fromX + 10)] / 16) * 16 + 5;
		}
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] / 16) * 16 + c;
		}
	}

	//col 12
	if (fromX + 11 >= 0 && fromX + 11 < NSCREENWIDTH)
	{
		if (fromY - 1 >= 0 && fromY - 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY - 1) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY - 1) * nScreenWidth + (fromX + 11)] = (pColor[(fromY - 1) * nScreenWidth + (fromX + 11)] / 16) * 16 + 4;
		}
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY)*nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = c * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] / 16) * 16 + c;
		}
	}

	//col 13
	if (fromX + 12 >= 0 && fromX + 12 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 12)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] / 16) * 16 + c;
		}
	}

	//col 14
	if (fromX + 13 >= 0 && fromX + 13 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 13)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] / 16) * 16 + c;
		}
	}

	//col 15
	if (fromX + 14 >= 0 && fromX + 14 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY)*nScreenWidth + (fromX + 14)] = 1 * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] / 16) * 16 + 0;
		}
	}

	//col 16
	if (fromX + 15 >= 0 && fromX + 15 < NSCREENWIDTH)
	{
		if (fromY >= 0 && fromY < NSCREENHEIGHT)
		{
			pBuffer[(fromY)*nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY)*nScreenWidth + (fromX + 15)] = (pColor[(fromY)*nScreenWidth + (fromX + 15)] / 16) * 16 + c;
		}
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L' ';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 1 * 16 + 1;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 0 * 16 + 14;
		}
	}

	//col 17
	if (fromX + 16 >= 0 && fromX + 16 < NSCREENWIDTH)
	{
		if (fromY + 1 >= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 0 * 16 + 14;
		}
	}

	//col 18
	if (fromX + 17 >= 0 && fromX + 17 < NSCREENWIDTH)
	{
		if (fromY + 1>= 0 && fromY + 1 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] / 16) * 16 + c;
		}
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = c * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] / 16) * 16 + 0;
		}
	}

	//col 19
	if (fromX + 18 >= 0 && fromX + 18 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = c * 16 + 5;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L' ';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = c * 16 + c;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] / 16) * 16 + c;
		}
	}

	//col 20
	if (fromX + 19 >= 0 && fromX + 19 < NSCREENWIDTH)
	{
		if (fromY + 2 >= 0 && fromY + 2 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = c * 16 + 4;
		}
		if (fromY + 3 >= 0 && fromY + 3 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▄';
			pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 4 * 16 + 0;
		}
		if (fromY + 4 >= 0 && fromY + 4 < NSCREENHEIGHT)
		{
			pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'▀';
			pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] / 16) * 16 + c;
		}
	}

}
