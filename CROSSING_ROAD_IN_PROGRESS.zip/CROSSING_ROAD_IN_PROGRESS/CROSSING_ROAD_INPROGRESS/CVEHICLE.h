﻿#pragma once
#include "COBJECT.h"
#define HEIGHT_CAR 5
#define WIDTH_CAR 20
#define HEIGHT_TRUCK 6
#define WIDTH_TRUCK 21
class CVEHICLE:public COBJECT
{
	int color;
	int vehicleKind;//0 la xe binh thuong, 1 la xe mui tran
	void (*drawVehicle)(int fromX, int fromY, int c);
	void setDraw(void (*drawVehicle)(int fromX, int fromY, int c));
	
	static void drawRegCarRight(int fromX, int fromY, int c);
	static void drawRoadsterRight(int fromX, int fromY, int c);
	static void drawTruckRight(int fromX, int fromY, int c);
	static void drawPoliceRight(int fromX, int fromY, int c = 14);
	static void drawRegCarLeft(int fromX, int fromY, int c);
	static void drawRoadsterLeft(int fromX, int fromY, int c);
	static void drawTruckLeft(int fromX, int fromY, int c);
	static void drawPoliceLeft(int fromX, int fromY, int c = 14);
	static int carColor[7]; 
	static COORD width_height[4];
public:
	
	CVEHICLE();
	void setVehicleKind(int kind, bool direction);
	void setColorByIndex(int index);
	void setColor(int color);
	
	void setNewRandomColor();
	int getVehicleKind();

	void draw();
	void saveObject(ofstream& f);
	void loadVehicle(ifstream& f, bool direction);
};





//static void drawRoadsterRight(int fromX, int fromY, int c);






